import { Component, OnInit } from '@angular/core';
import { ZoneService } from '../services/zone.service';
import { TaxAssessmentFormComponent } from '../tax-assessment-form/tax-assessment-form.component';

@Component({
  selector: 'app-zonal-wise-report',
  templateUrl: './zonal-wise-report.component.html',
  styleUrls: ['./zonal-wise-report.component.css']
})
export class ZonalWiseReportComponent implements OnInit {

  years: Object;
  selectedYear: number;
  data: Object;
  constructor(private zoneService:ZoneService) { }

  ngOnInit() {
    this.zoneService.getYears().subscribe(
      (years) => this.years = years
    );
  }

  getTaxData(event: any) {
    this.selectedYear = parseInt(event.target.value);
    this.zoneService.getAnnualTaxPaidDetails(this.selectedYear).subscribe(
      (annualDetail) => {
        this.data = annualDetail;
      }
    );

  }

}
