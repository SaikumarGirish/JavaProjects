import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZonalWiseReportComponent } from './zonal-wise-report.component';

describe('ZonalWiseReportComponent', () => {
  let component: ZonalWiseReportComponent;
  let fixture: ComponentFixture<ZonalWiseReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZonalWiseReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZonalWiseReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
