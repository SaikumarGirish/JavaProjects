import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { TaxAssessmentFormComponent } from './tax-assessment-form/tax-assessment-form.component';
import { ZonalWiseReportComponent } from './zonal-wise-report/zonal-wise-report.component';
import { ErrorDisplayComponent } from './error-display/error-display.component';
import { ZoneService } from './services/zone.service';
import {HttpClientModule} from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { DescriptionService } from './services/description.service';
import {TaxService} from './services/tax.service';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    TaxAssessmentFormComponent,
    ZonalWiseReportComponent,
    ErrorDisplayComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpModule,
    FormsModule
  ],
  providers: [ZoneService,DescriptionService,TaxService],
  bootstrap: [AppComponent]
})
export class AppModule { }
