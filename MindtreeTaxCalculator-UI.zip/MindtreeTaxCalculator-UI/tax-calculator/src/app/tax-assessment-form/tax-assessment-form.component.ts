import { Component, OnInit } from '@angular/core';
import { ZoneService } from '../services/zone.service';
import { DescriptionService } from '../services/description.service';
import { TaxService } from '../services/tax.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tax-assessment-form',
  templateUrl: './tax-assessment-form.component.html',
  styleUrls: ['./tax-assessment-form.component.css']
})
export class TaxAssessmentFormComponent implements OnInit {

  taxCalculation = {
    yearOfAssessment: 0,
    builtArea: 0,
    descId: 0,
    zoneId: 0,
    constructedYear: 0,
    status: ''
  };

  taxDetail = {
    yearOfAssessment: 0,
    name: '',
    email: '',
    address: '',
    buildingOwnerStatus: '',
    buildConstructYear: 0,
    area: 0,
    taxPaid: 0,
    zone: {
      id: 0,
      name: ''
    },
    description: {
      id: 0,
      name: ''
    }
  };
  zones: Object;
  descs: Object;
  public taxAmount: Object;
  public taxId: Object;
  taxValue: string;
  taxWithSymbol: string;
  descValue: any = "-------------------- select description --------------------";
  zoneValue: any = "------------ select zone ------------";
  statusValue: any = "----- select building status -----";
  yearofAssessment: number;
  name: string;
  email: string;
  address: string;
  cnstdYear: number;
  area: number;
  zoneId: number;
  zoneName: string;
  mysel: any;
  constructor(public zoneService: ZoneService, public descService: DescriptionService, public taxService: TaxService, public router: Router) { }

  ngOnInit() {
    this.zoneService.getZones().subscribe(
      (zone) => {
        this.zones = zone;
      }
    );
    this.descService.getDescriptions().subscribe(
      (desc) => {
        this.descs = desc;
      }
    );
  }
  calculateTax() {
    this.taxCalculation.yearOfAssessment = this.yearofAssessment;
    this.taxCalculation.builtArea = this.area;
    this.taxCalculation.descId = this.descValue;
    this.taxCalculation.zoneId = this.zoneValue;
    this.taxCalculation.constructedYear = this.cnstdYear;
    this.taxCalculation.status = this.statusValue.toUpperCase();
    this.taxService.calculateTax(this.taxCalculation).subscribe(
      (taxObject) => {
        this.taxAmount = taxObject;
        this.taxValue = "₹ " + this.taxAmount;
      }
    );
  }
  payTax() {
    this.taxDetail.address = this.address;
    this.taxDetail.area = this.area;
    this.taxDetail.buildConstructYear = this.cnstdYear;
    this.taxDetail.buildingOwnerStatus = this.statusValue.toUpperCase();
    this.taxDetail.email = this.email;
    this.taxDetail.name = this.name;
    this.taxDetail.taxPaid = parseFloat(this.taxAmount.toString());
    this.taxDetail.yearOfAssessment = this.yearofAssessment;
    this.taxDetail.zone.id = this.zoneValue;
    this.taxDetail.zone.name = this.zones[this.zoneValue - 1].name;
    this.taxDetail.description.id = this.descValue;
    this.taxDetail.description.name = this.descs[this.descValue - 1].name;
    this.taxService.saveTax(this.taxDetail).subscribe(
      (taxId) => {
        this.taxId = taxId;
          alert("Tax details are saved successfully with id: " + this.taxId);
          this.router.navigate(['/homePage']);
        }
    );
  }

}
