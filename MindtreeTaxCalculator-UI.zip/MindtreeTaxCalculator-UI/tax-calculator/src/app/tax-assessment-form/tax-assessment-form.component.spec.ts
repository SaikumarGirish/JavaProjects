import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxAssessmentFormComponent } from './tax-assessment-form.component';

describe('TaxAssessmentFormComponent', () => {
  let component: TaxAssessmentFormComponent;
  let fixture: ComponentFixture<TaxAssessmentFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxAssessmentFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxAssessmentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
