import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ZoneService {

  constructor(public httpClient: HttpClient) { }

  public readonly URL = "http://localhost:8080/tax-ui/v1.0";

  zones : any;

  public getZones() {
    return this.httpClient.get(this.URL+"/getzones");
  }

  public getYears() {
    return this.httpClient.get(this.URL+"/getdistinctpaidtaxyears");
  }

  public getAnnualTaxPaidDetails(year: number) {
    return this.httpClient.get(this.URL+"/getpaidtaxdetails/"+year);
  }

}
