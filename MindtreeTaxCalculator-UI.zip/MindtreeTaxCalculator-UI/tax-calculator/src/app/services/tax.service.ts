import { Injectable } from '@angular/core';
import { ZoneService } from './zone.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TaxService {
  taxValue: any;
  calculatedValue: any;
  taxId: any;
  constructor(public zoneService: ZoneService, public httpClient: HttpClient) { }

  public calculateTax(taxCalculation) {
    return this.httpClient.post(this.zoneService.URL + "/calculatetax", taxCalculation);
  }

  public saveTax(taxDetail) {
    return this.httpClient.post(this.zoneService.URL+"/savetaxdetails",taxDetail);
  }
}
