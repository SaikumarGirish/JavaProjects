import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ZoneService } from './zone.service';

@Injectable({
  providedIn: 'root'
})
export class DescriptionService {

  constructor(public httpClient: HttpClient,public zoneService:ZoneService) { }

  public getDescriptions() {
    return this.httpClient.get(this.zoneService.URL+"/getdescriptions");
  }
}
