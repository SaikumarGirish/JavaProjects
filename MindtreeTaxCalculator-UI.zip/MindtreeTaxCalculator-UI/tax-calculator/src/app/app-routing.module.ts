import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { TaxAssessmentFormComponent } from './tax-assessment-form/tax-assessment-form.component';
import { ZonalWiseReportComponent } from './zonal-wise-report/zonal-wise-report.component';
import { ErrorDisplayComponent } from './error-display/error-display.component';


const routes: Routes = [
  { path: '', redirectTo: 'homePage', pathMatch: 'full' },
  {
    path: 'homePage',
    component: HomePageComponent
  },
  {
    path: 'taxCalculationForm',
    component: TaxAssessmentFormComponent
  },
  {
    path: 'zonalWiseReport',
    component: ZonalWiseReportComponent
  },
  {
    path: 'error',
    component: ErrorDisplayComponent
  },
  { path: '**', redirectTo: 'error', pathMatch: 'full' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})
export class AppRoutingModule { }
