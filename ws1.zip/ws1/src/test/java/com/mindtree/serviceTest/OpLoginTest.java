package com.mindtree.serviceTest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.service.impl.LoginServiceImpl;

public class OpLoginTest {
	private LoginServiceImpl loginServiceImpl;
	private Administrator admin;
	@Before
	public void init(){
		loginServiceImpl = new LoginServiceImpl();
	}
	@Test
	public void testSetOperatorPositive() throws OperatorNotFoundException{
		admin = new Administrator();
		admin.setEmail("mukesh.yadav@gmail.com");
		admin.setPassword("iamsuperstar");
		List<Administrator> a = loginServiceImpl.setOperator(admin);
		assertEquals("Login Success",1,a.get(0).getAdministratorId());
	}
	@Test
	public void testSetOperatorNegative() throws OperatorNotFoundException{
		admin = new Administrator();
		admin.setEmail("mukesh345.yadav@gmail.com");
		admin.setPassword("iamsuperstar23");
		List<Administrator> result = loginServiceImpl.setOperator(admin);
		assertEquals("Login Fail",0,result.size());
	}

}
