
/*
package com.mindtree.serviceTest;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;
import com.mindtree.service.impl.MyRidesServiceImpl;

public class MyRidePositiveTest {
	MyRidesServiceImpl myRidesServiceImpl;
	ChangeDestination changeDestObj;
	UpdateUpcoming updateObj;
	public MyRidePositiveTest() {
	}
	
		
		@Before
		public void init() {
			myRidesServiceImpl = new MyRidesServiceImpl();
			changeDestObj = new ChangeDestination();
			changeDestObj.setBookingId(270);
			changeDestObj.setLocation("Calavar");
			updateObj = new UpdateUpcoming();
			updateObj.setBookingId(26);
			updateObj.setLocation("Calavar");
		}

		@Test
		public void getPastRideTest(){
			List<Booking> pastRide = myRidesServiceImpl.getPastRides(2);
			assertEquals("got past ride",249,pastRide.get(0).getBookingId());
		}
		@Test
		public void getOngoingRideTest(){
			List<Booking> ongoingRide = myRidesServiceImpl.getOngoingRides(2);
			assertEquals("got ongoing ride",270,ongoingRide.get(0).getBookingId());
		}
		@Test
		public void getUpcomingRideTest(){
			List<Booking> upcomingRide = myRidesServiceImpl.getUpcomingRides(2);
			assertEquals("got upcoming ride",26,upcomingRide.get(0).getBookingId());
		}
		@Test
		public void getAllLocationTest(){
			List<Locations> location = myRidesServiceImpl.getAllLocation();
			assertEquals("got all location",1,location.get(0).getLocationId());
		}
		@Test
		public void changeDestTest(){
			List<Booking> change = myRidesServiceImpl.changeDestination(changeDestObj);
			assertEquals("destination changed",270,change.get(0).getBookingId());
		}
		@Test
		public void deleteTest(){
			List<Booking> delete = myRidesServiceImpl.deleteService(5);
			assertEquals("deleted",26,delete.get(0).getBookingId());
		}
		@Test
		public void updateUpcomingTest(){
			List<Booking> update = myRidesServiceImpl.updateUpcomingService(updateObj,"Anvard");
			assertEquals("update location",26,update.get(0).getBookingId());
		}
		@Test
		public void showDeletedTest(){
			List<Booking> showDeleted = myRidesServiceImpl.getShowDeleted(2);
			assertEquals("destination changed",1,showDeleted.get(0).getBookingId());
		}
		
}

<<<<<<< HEAD
*/

