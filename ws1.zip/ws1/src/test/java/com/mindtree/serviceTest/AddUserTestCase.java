package com.mindtree.serviceTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.dao.impl.AddCredentialsImpl;
 
import com.mindtree.entity.User;
import com.mindtree.exceptions.BookingIdNotFoundException;
 
import com.mindtree.service.impl.LoginServiceImpl;

public class AddUserTestCase {
    private  LoginServiceImpl loginServeimpl;
	private User user;
	AddCredentialsImpl logindaoimpl;
	@Before
	public  void init()
	{
		loginServeimpl=new LoginServiceImpl();
 

	}
	@Test
	public void testOperator() throws  BookingIdNotFoundException{
		 
		user=new User();
		user.setEmail("vishdets@gmail.com");
		user.setGender(0);
		user.setOtp(0);
		user.setPassword("11hhhlk");
		user.setPhoneNumber("9998888272");
		user.setUserName("testing");
		User u=loginServeimpl.addUser(user);
		assertEquals("Success",user.getEmail(),u.getEmail());
		 
		
	}
	

}
