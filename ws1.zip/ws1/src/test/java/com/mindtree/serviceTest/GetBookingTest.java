
//package com.mindtree.serviceTest;
//
//
//import static  org.junit.Assert.*;
//import java.util.List;
//
//
//import org.junit.Test;
//
//import com.mindtree.entity.Booking;
//import com.mindtree.service.impl.GetBookingsServiceImpl;
//
//
//
//public class GetBookingTest {
//	
//		GetBookingsServiceImpl bookingServImpl=new GetBookingsServiceImpl();
//	
//	@Test
//	public void testGetBookigs() {
//		
//		List<Booking> bookings = (List<Booking>)  bookingServImpl.getBookings();
//		assertEquals(164,bookings.get(0).getBookingId());	
//	}
//	
//
//}
