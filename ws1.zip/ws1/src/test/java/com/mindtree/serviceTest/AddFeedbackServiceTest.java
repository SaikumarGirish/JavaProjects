package com.mindtree.serviceTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.dao.impl.AddFeedbackImpl;
import com.mindtree.dto.Feedback;
import com.mindtree.exceptions.BookingIdNotFoundException;

public class AddFeedbackServiceTest {

	AddFeedbackImpl addFeedback;
	  Feedback feedback;
	  @Before
	  public void init()
	  {
		  addFeedback=new AddFeedbackImpl();
		  feedback=new Feedback();
	  }
	  @Test
	  public void testFeedback() throws BookingIdNotFoundException
	  {
		  addFeedback=new AddFeedbackImpl();
		  feedback.setBookingId(1);
		  feedback.setCommnet("Good Test");
		  feedback.setRating(4);
		  assertEquals("Feedback added successfully",true,addFeedback.addFeedback(feedback));
		  
			 
	  }

}
