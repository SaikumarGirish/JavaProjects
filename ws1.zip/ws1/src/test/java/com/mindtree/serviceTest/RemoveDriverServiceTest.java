package com.mindtree.serviceTest;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.mindtree.entity.Driver;
import com.mindtree.service.RemoveDriverService;
import com.mindtree.service.impl.RemoveDriverServiceImpl;

public class RemoveDriverServiceTest {

	RemoveDriverService rdService=new RemoveDriverServiceImpl();

	@Test
	public void testGetAllDrivers() {
		ArrayList<Driver> driverList=(ArrayList<Driver>) rdService.getAllDrivers();
		assertEquals(1,driverList.get(0).getDriverId());
	}

	@Test
	public void testDeleteDriver() {
		rdService.deleteDriver(6);
		ArrayList<Driver> driverList=(ArrayList<Driver>) rdService.getAllDrivers();
		assertEquals("akshay",driverList.get(0).getDriverName());
	}

	@Test
	public void testGetAssignedDrivers() {
		ArrayList<Driver> driverList=(ArrayList<Driver>) rdService.getAssignedDrivers();
		assertEquals("sooraj",driverList.get(1).getDriverName());
	}

	@Test
	public void testUnassignDriver() {
		rdService.unassignDriver(8);
		ArrayList<Driver> driverList=(ArrayList<Driver>) rdService.getAssignedDrivers();
		assertEquals(1,driverList.get(0).getDriverId());
	}

}
