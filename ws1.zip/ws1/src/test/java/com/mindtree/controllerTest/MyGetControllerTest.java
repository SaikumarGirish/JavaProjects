package com.mindtree.controllerTest;


import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.Test;

import com.mindtree.controller.MyGetController;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.entity.User;

public class MyGetControllerTest {
MyGetController myGetController = new MyGetController();

@Test
public void getLocations(){
	Locations location = new Locations();
	location.setLocationId(1);
	location.setLocation("Anvard");
	  ArrayList<Locations> list = (ArrayList<Locations>) myGetController.getLocationsList();
	 assertNotNull(list);
	 assertEquals(location.getLocationId(), list.get(0).getLocationId());
	 assertEquals(location.getLocation(), list.get(0).getLocation());
}
@Test
public void getUsers(){
	ArrayList<User> list = (ArrayList<User>)myGetController.getUserList();
	assertNotNull(list);
}
@Test
public void getDrivers(){
	ArrayList<Driver> list = (ArrayList<Driver>)myGetController.getDriverList();
	assertNotNull(list);
}
@Test
public void getOperators(){
	ArrayList<Administrator> list = (ArrayList<Administrator>)myGetController.getOperatorList();
	assertNotNull(list);
}

}
