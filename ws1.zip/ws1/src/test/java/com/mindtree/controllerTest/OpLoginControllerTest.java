package com.mindtree.controllerTest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.controller.OperatorLoginController;
import com.mindtree.entity.Administrator;

public class OpLoginControllerTest {
	private OperatorLoginController loginController;
	private Administrator admin;
	
	@Before
	public void init(){
		loginController = new OperatorLoginController();
	}
	@Test
	public void testGetoperatordataPositive() {
		admin = new Administrator();
		admin.setEmail("mukesh.yadav@gmail.com");
		admin.setPassword("iamsuperstar");
		List<Administrator> list  = loginController.getoperatordata(admin);
		assertEquals("Login Success",1,list.get(0).getAdministratorId());
	}
	@Test
	public void testGetoperatordataNegative() {
		admin = new Administrator();
		admin.setEmail("mukesh.yadav@gmail.com");
		admin.setPassword("iamsuper4567888888888888star");
		List<Administrator> list  = loginController.getoperatordata(admin);
		assertEquals("Login Fail",0,list.size());
	}

}
