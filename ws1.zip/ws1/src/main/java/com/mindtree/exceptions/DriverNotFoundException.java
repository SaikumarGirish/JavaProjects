package com.mindtree.exceptions;

public class DriverNotFoundException extends Exception {
public DriverNotFoundException(String s){
	super(s);
}
}
