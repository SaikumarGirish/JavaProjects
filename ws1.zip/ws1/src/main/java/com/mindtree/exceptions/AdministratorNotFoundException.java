package com.mindtree.exceptions;

public class AdministratorNotFoundException extends Exception {
public AdministratorNotFoundException (String s){
	super(s);
}
}
