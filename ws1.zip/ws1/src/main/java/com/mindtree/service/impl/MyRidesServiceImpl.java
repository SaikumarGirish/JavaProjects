package com.mindtree.service.impl;

import com.mindtree.service.MyRidesService;

import java.util.Collections;
import java.util.List;

import com.mindtree.dao.MyRidesDao;
import com.mindtree.dao.impl.MyRidesDaoImpl;
import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;

public class MyRidesServiceImpl implements MyRidesService{

	//calling method of dao to get past rides of a user
	public List<Booking> getPastRides(int uId){
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		List<Booking> result = 	myRidesDao.pastRides(uId);
		Collections.reverse(result);
		return result;
	}

	//calling method of dao to get ongoing rides of a user
	@Override
	public List<Booking> getOngoingRides(int uId) {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		List<Booking> result = myRidesDao.ongoingRides(uId);
		Collections.reverse(result);
		return result;
	}
	//calling method of dao to get upcoming rides of a user
	@Override
	public List<Booking> getUpcomingRides(int uId) {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		return myRidesDao.upcomingRides(uId);
	}

	//calling method of dao to get all locations
	@Override
	public List<Locations> getAllLocation() {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		return myRidesDao.getlocations();
	}
	//calling method of dao to change destination of given ongoing ride
	@Override
	public List<Booking> changeDestination(ChangeDestination changeDestObj) {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		return myRidesDao.changingDestination(changeDestObj);
	}
	//calling method of dao to delete a given upcoming ride
	@Override
	public List<Booking> deleteService(int id) {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		return myRidesDao.deleteDao(id);
	}
	//calling method of dao to update pickup and drop location of a given upcoming ride
	@Override
	public List<Booking> updateUpcomingService(UpdateUpcoming updateObj, String pickUp) {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		return myRidesDao.updateUpcomingDao(updateObj,pickUp);
	}

	//calling method of dao to get deleted rides of a user
	@Override
	public List<Booking> getShowDeleted(int uId) {
		MyRidesDao myRidesDao = new MyRidesDaoImpl();
		return myRidesDao.getShowDeletedDao(uId);
	}
}
