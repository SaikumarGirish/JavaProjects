package com.mindtree.service;

import com.mindtree.dto.MailData;

public interface SendMail {
	public boolean sendEmail(MailData mailData);
}
