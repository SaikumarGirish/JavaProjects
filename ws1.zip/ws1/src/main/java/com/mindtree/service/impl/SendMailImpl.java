package com.mindtree.service.impl;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

import com.mindtree.dto.MailData;
import com.mindtree.service.SendMail;
@Service
public class SendMailImpl implements SendMail{
	/*This method contains inbuilt functions which will authenticate and send 
	 * mail to the particular user from specified email Id */
	@Override
	public boolean sendEmail(MailData mailData) 
	{try{
		final String username = "surajdoddangadi2@gmail.com";
		final String passwor = "surajkiran9";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "465");
		
		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, passwor);
			}
		  });

		

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("surajdoddangadi2@gmail.com"));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(mailData.getUserEmail()));
			message.setSubject("Booking confirmation");
			
			message.setText("Dear "+mailData.getName()+","+'\n'+"YOUR CAB IS SUCCESFULLY BOOKED..!" +'\n'+ '\n'+'\n'+'\n'+'\n'+"Your booking details are here: "+'\n'+"DRIVER NAME: "+mailData.getDriverName()+'\n'+"DRIVER PHONE NUMBER: "+mailData.getDriverNumber()+'\n'+"CAR NUMBER: "+mailData.getCarNumber()+'\n'+"COST: "+mailData.getCost()
			+'\n'+"DISTANCE: "+mailData.getDistance()+'\n'+"Thanks and regards"+'\n'+"Wheelz Car Rental.Co");
		
			Transport.send(message);

		} 
		catch (MessagingException e) 
		{
			return false;
 
		}
		return true;

	}
}
