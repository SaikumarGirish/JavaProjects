package com.mindtree.service.impl;

import com.mindtree.dao.FacebookLoginDao;
import com.mindtree.dao.impl.FacebookLoginDaoImpl;
import com.mindtree.dto.FaceBook;
import com.mindtree.entity.User;
import com.mindtree.service.FacebookLoginService;

public class FacebookLoginServiceImpl implements FacebookLoginService {

	FacebookLoginDao fbDao = new FacebookLoginDaoImpl();

	/*
	 * this method will check whether the user is already present in the
	 * database if already present it will return true otherwise false
	 */
	@Override
	public User facebookCheck(FaceBook facebook) {
		User user = new User();
		user.setUserName(facebook.getName());
		user.setEmail(facebook.getEmail());
		if (facebook.getGender().equals("male"))
			user.setGender(0);
		else
			user.setGender(1);
		return fbDao.facebookCheck(user);
	}

	/* this method will add user to database */
	@Override
	public User addFBUser(FaceBook facebook) {
		User user = new User();
		user.setUserName(facebook.getName());
		user.setEmail(facebook.getEmail());
		if (facebook.getGender().equals("male"))
			user.setGender(0);
		else
			user.setGender(1);

		return fbDao.addFBUser(user);
	}

}
