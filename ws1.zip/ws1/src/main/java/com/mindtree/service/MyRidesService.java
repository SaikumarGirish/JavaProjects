package com.mindtree.service;

import java.util.List;

import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;

public interface MyRidesService {
	public List<Booking> getPastRides(int uId);

	public List<Booking> getOngoingRides(int uId);

	public List<Booking> getUpcomingRides(int uId);

	public List<Locations> getAllLocation();

	public List<Booking> changeDestination( ChangeDestination changeDestObj);

	public List<Booking> deleteService(int id);

	public List<Booking> updateUpcomingService(UpdateUpcoming updateObj,String pickUp);

	public List<Booking> getShowDeleted(int uId);
}
