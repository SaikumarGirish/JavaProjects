package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Booking;


public interface GetBookingsService {

	List<Booking> getBookings();

}
