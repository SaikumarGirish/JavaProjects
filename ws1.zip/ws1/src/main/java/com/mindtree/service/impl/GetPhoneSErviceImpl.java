package com.mindtree.service.impl;

import java.util. List;

import com.mindtree.dao.GetPhone;
import com.mindtree.dao.impl.GetPhoneImpl;
import com.mindtree.service.GetPhoneService;

public class GetPhoneSErviceImpl implements GetPhoneService{

	 
	public  List getPhone() {
		//calling DaoClass method toget phone for all users
		GetPhone getPhone=new GetPhoneImpl();
		return getPhone.getPhone();
		 
	}

}
