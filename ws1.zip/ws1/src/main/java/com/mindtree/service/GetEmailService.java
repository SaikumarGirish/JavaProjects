package com.mindtree.service;

 
import java.util.List;

public interface GetEmailService {
	public List getEmail();
}
