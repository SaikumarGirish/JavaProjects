package com.mindtree.service;

import java.util.List;

import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;

public interface AddNewDriverService {

	List<Driver> addNewDriverService(AddNewDriverDto addNewDriverObj);

	List<Driver> getDriverService();

}
