package com.mindtree.service;



import com.mindtree.dto.BookingData;
import com.mindtree.dto.OperatorBookingData;
import com.mindtree.dto.PostBookingData;


public interface CalculateCost {
public PostBookingData calculateCost(BookingData bookingData);
public PostBookingData operatorCalculateCost(OperatorBookingData operatorBookingData);
}
