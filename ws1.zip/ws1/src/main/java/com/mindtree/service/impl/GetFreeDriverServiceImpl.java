package com.mindtree.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.GetFreeDriverDao;
import com.mindtree.dao.impl.GetFreeDriverImpl;
import com.mindtree.entity.Driver;
import com.mindtree.service.GetFreeDriverService;

@Service
public class GetFreeDriverServiceImpl implements GetFreeDriverService {


	
	@Override
	@Transactional
	public List<Driver> getFreeDrivers() {
		GetFreeDriverDao get = new GetFreeDriverImpl();
		
		return get.getFreeDrivers();
		
	}

}
