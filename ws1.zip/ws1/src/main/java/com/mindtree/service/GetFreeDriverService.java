package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Driver;

public interface GetFreeDriverService {



	public List<Driver> getFreeDrivers();

}
