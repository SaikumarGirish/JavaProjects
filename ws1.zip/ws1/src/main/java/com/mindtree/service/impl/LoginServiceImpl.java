package com.mindtree.service.impl;

 
import java.util.List;

import com.mindtree.dao.AddCredential;
import com.mindtree.dao.Login;
import com.mindtree.dao.impl.AddCredentialsImpl;
import com.mindtree.dao.impl.LoginImpl;
import com.mindtree.dto.Gmaildata;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.exceptions.UserNotFoundException;
import com.mindtree.service.LoginService;

public class LoginServiceImpl implements LoginService
{
	
	// This Service is used to send the login credentials to DAO layer
	
	@Override
	public User setUser(User users) throws UserNotFoundException {
		
		
		User u = new User();
		Login l = new LoginImpl();
		User log=null;
		u.setEmail(users.getEmail());
		u.setPassword(users.getPassword());
		log=l.check(u);
		return log;
	}

	public User addUser(User user) {
		AddCredential addCredential = new AddCredentialsImpl();
		return addCredential.addUser(user);
	}



	@Override
	public  List<Administrator> setOperator(Administrator admin) throws OperatorNotFoundException{
		Login operatorLogin = new LoginImpl();
		Administrator  adminDetailList = new Administrator();
		List<Administrator> adminObj =null;
		adminDetailList.setEmail(admin.getEmail());
		adminDetailList.setPassword(admin.getPassword());
			adminObj = operatorLogin.operatorLogin(adminDetailList);	
		return adminObj;
	}

	@Override
	public  User checkUser(Gmaildata gmailuser) {
	
		User user=new User();
		user.setUserName( gmailuser.getName());
		 
		user.setEmail( gmailuser.getEmail());
		 System.out.println(user.getEmail());
		AddCredential addCredential=new AddCredentialsImpl();
		return addCredential.checkUser( user);
	}
}
