package com.mindtree.service.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.entity.Locations;
import com.mindtree.entity.Route;
public class Demo {
public void addRoute(){
	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	String[] string = { "Anvard", "Archenland", "Aslans How", "Beavers Dam", "Beruna", "Bramandin",
			"Cair Paravel", "Calavar", "Calormen", "Doorn", "Duffler Isle", "Ettinsmoor", "Felinda",
			"Finchley", "Glasswater Creek", "Lantern Waste", "Mirazs Castle", "Pale Beaches", "Seven Isles", "Zalindreh" };
	Route route = new Route();
	for(int i=0;i<string.length;i++)
	{
		for(int j=0;j<string.length;j++)
		{Session session = sessionFactory.openSession();
			if(!(string[i].equals(string[j])))
				{session.beginTransaction();
		  Locations fromLocation = session.get(Locations.class,i+1);
		  Locations toLocation = session.get(Locations.class,j+1);
		  route.setFromLocation(fromLocation);
		  route.setToLocation(toLocation);
		  session.save(route);
		  session.getTransaction().commit();
			
				}	
			session.close();
		}
	}
	
}
}
