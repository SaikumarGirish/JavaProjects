package com.mindtree.service.impl;

import java.util.List;

import com.mindtree.dao.AddNewDriverDao;
import com.mindtree.dao.impl.AddNewDriverDaoImpl;
import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;
import com.mindtree.service.AddNewDriverService;

public class AddNewDriverServiceImpl implements AddNewDriverService {
	//calling method of dao to add a driver
	@Override
	public List<Driver> addNewDriverService(AddNewDriverDto addNewDriverObj) {
		AddNewDriverDao addNewDriverDao = new AddNewDriverDaoImpl();
		return addNewDriverDao.addDriverDao(addNewDriverObj);
	}

	//calling method of dao to get list of drivers
	@Override
	public List<Driver> getDriverService() {
		AddNewDriverDao addNewDriverDao = new AddNewDriverDaoImpl();
		return addNewDriverDao.getDriverDao();
	}

}
