package com.mindtree.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.GetBookings;
import com.mindtree.dao.impl.GetBookingsImpl;
import com.mindtree.entity.Booking;
import com.mindtree.service.GetBookingsService;


@Service
public class GetBookingsServiceImpl implements GetBookingsService 

{

	@Override
	@Transactional
	public List<Booking> getBookings() {
		
		GetBookings get = new GetBookingsImpl();
		
		return get.getBooking();
		
	}

}
