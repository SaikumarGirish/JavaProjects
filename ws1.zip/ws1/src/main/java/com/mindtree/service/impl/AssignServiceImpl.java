package com.mindtree.service.impl;

import com.mindtree.dao.AssignDao;
import com.mindtree.dao.impl.AssignDaoImpl;
import com.mindtree.dto.AssignDriver;
import com.mindtree.service.AssignService;

public class AssignServiceImpl implements AssignService
{

	public boolean get(AssignDriver detail)
	{
		AssignDao asd = new AssignDaoImpl();
		
		asd.get(detail);
		
		
		return true;
		
	}

}
