package com.mindtree.service;

import java.util.List;

import com.mindtree.dto.Gmaildata;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.exceptions.UserNotFoundException;

public interface LoginService {

	public User setUser(User users) throws UserNotFoundException;
	 
	public User addUser(User user);

	public List<Administrator> setOperator(Administrator admin) throws OperatorNotFoundException;

	
	public User checkUser(Gmaildata user);

}
