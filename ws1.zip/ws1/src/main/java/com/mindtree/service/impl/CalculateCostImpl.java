package com.mindtree.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.impl.AddBookingImpl;
import com.mindtree.dao.impl.AddOperatorBookingImpl;
import com.mindtree.dao.impl.GetCredentialsImpl;
import com.mindtree.dto.BookingData;
import com.mindtree.dto.OperatorBookingData;
import com.mindtree.dto.PostBookingData;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Route;
import com.mindtree.entity.User;
@Service
public class CalculateCostImpl {
	GetCredentialsImpl getCredentials = new GetCredentialsImpl();
	PostBookingData postBookingData = new PostBookingData();

	AddBookingImpl addBooking = new AddBookingImpl();
	Booking booking = new Booking();
	@Transactional
	public PostBookingData calculateCost(BookingData bookingData) {

		Route route = getCredentials.getRoute(bookingData.getPickUpLocation(), bookingData.getDropLocation());
		User user = getCredentials.getUser(bookingData.getEmail());
		int distance = route.getDistance();
		int carType = bookingData.getCarType();
		postBookingData.setDistance(route.getDistance());
		postBookingData.setCost(costCalculate(distance, carType));
		booking.setCost(postBookingData.getCost());
		booking.setRoute(route);
		booking.setTimeOfBooking(bookingData.getTimeStamp());
		booking.setCarType(bookingData.getCarType());
		booking.setBookingStatus(bookingData.getBookingStatus());
		booking.setScheduleTime(bookingData.getScheduleTime());
		booking.setWayOfPayment(bookingData.getPayType());
		booking.setUser(user);

		booking = addBooking.addNewBooking(booking);
		postBookingData.setBookingId(booking.getBookingId());

		return postBookingData;
	}
	@Transactional
	public PostBookingData operatorCalculateCost(OperatorBookingData operatorBookingData) {
		PostBookingData postBookingDataOperator = new PostBookingData();
		AddOperatorBookingImpl addOperatorBooking = new AddOperatorBookingImpl();
		User user = new User();
		user.setEmail(operatorBookingData.getEmail());
		user.setPhoneNumber(operatorBookingData.getPhoneNumber());
		user.setUserName(operatorBookingData.getUserName());
		user.setPassword(operatorBookingData.getPhoneNumber());
		Route routeOperator = getCredentials.getRoute(operatorBookingData.getPickUpLocation(),
				operatorBookingData.getDropLocation());
		user = addOperatorBooking.checkUser(user);

		Administrator operator = addOperatorBooking.getAdministrator(operatorBookingData.getOperatorId());
		int carType = operatorBookingData.getCarType();
		Driver driver = addOperatorBooking.getDriver(operatorBookingData.getDriverId());
		postBookingDataOperator.setDistance(routeOperator.getDistance());
		int distance = routeOperator.getDistance();
		postBookingDataOperator.setCost(costCalculate(distance, carType));

		booking.setCost(postBookingDataOperator.getCost());

		booking.setRoute(routeOperator);
		booking.setCarType(operatorBookingData.getCarType());
		booking.setTimeOfBooking(operatorBookingData.getTimeI());
		booking.setBookingStatus(operatorBookingData.getBookingStatus());
		booking.setScheduleTime(operatorBookingData.getScheduleTime());
		booking.setUser(user);
		booking.setAdministrator(operator);
		booking.setDriverAssignTime(operatorBookingData.getTimeI());
		booking.setDriver(driver);
		booking = addBooking.addNewBooking(booking);
		postBookingData.setBookingId(booking.getBookingId());
		return postBookingDataOperator;
	}

	private int costCalculate(int distance, int carType) {
		if (distance <= 4) {
			if (carType == 0) {
				return 40;
			} else if (carType == 1) {
				return 50;
			}
		} else {
			if (carType == 0) {
				return (((distance - 4) * 11) + 40);

			} else if (carType == 1) {
				return (((distance - 4) * 13) + 50);
			}
		}
		return 0;
	}

}
