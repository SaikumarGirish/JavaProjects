package com.mindtree.service.impl;

import com.mindtree.dao.AddFeedback;
import com.mindtree.dao.impl.AddFeedbackImpl;
import com.mindtree.dto.Feedback;
import com.mindtree.exceptions.BookingIdNotFoundException;
import com.mindtree.service.AddFeedbackService;

public class AddFeedbackServiceImpl implements AddFeedbackService {

	@Override
	public boolean addFeedback(Feedback feedback) throws BookingIdNotFoundException {
		//calling DaoClass method to addFeedback
		 AddFeedback addFeedback=new AddFeedbackImpl();
		return  addFeedback.addFeedback(feedback);	
	}

}
