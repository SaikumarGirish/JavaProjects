package com.mindtree.service.impl;

import java.util.List;

import com.mindtree.dao.GetEmail;
import com.mindtree.dao.impl.GetEmailImp;
import com.mindtree.service.GetEmailService;

public class GetEmailServiceImpl implements GetEmailService {
	public List getEmail(){
		//calling DaoClass method to getEmail of all user
		GetEmail getEmail=new GetEmailImp();
		return getEmail.getEmail();
		
	}
}
