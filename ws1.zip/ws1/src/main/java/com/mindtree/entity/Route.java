package com.mindtree.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;

import javax.validation.constraints.Digits;


@Entity
public class Route {
	@Id
	@Digits(fraction = 0, integer = 10)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int routeId;
	@ManyToOne
	private Locations fromLocation;
	@ManyToOne
	private Locations toLocation;
	
	private int distance;
	
	public int getRouteId() {
		return routeId;
	}

	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}

	public Locations getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(Locations fromLocation) {
		this.fromLocation = fromLocation;
	}

	public Locations getToLocation() {
		return toLocation;
	}

	public void setToLocation(Locations toLocation) {
		this.toLocation = toLocation;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

}
