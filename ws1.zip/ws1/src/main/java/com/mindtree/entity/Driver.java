package com.mindtree.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Driver {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int driverId;
	@NotNull
	@Size(max = 35)
	private String driverName;
	@Column(unique = true)
	@NotNull
	@Size(max = 50)
	private String email;
	@Column(unique = true)
	@NotNull
	@Size(max = 10)
	private String carNumber;

	private int modelType;

	private int gender;
	@Column(unique = true)
	@NotNull
	@Digits(fraction = 0, integer = 10)
	private String phoneNumber;
	@Digits(fraction = 0, integer = 1)
	private int driverRidingStatus;
	@Size(max = 20)
	private String licenceNumber;
	@Size(max = 15)
	private String password;
	@Digits(fraction = 0, integer = 1)
	private int driverDeleteStatus;
	//@Digits(fraction = 0, integer = 1)
	private int age;
	@Column
	private String address;
	@Column
	private Date dateOfRegistration;
	@ManyToOne
	private Administrator administrator;

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getEmail() {
		return email;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setModelType(int modelType) {
		this.modelType = modelType;
	}

	public int getGender() {
		return gender;
	}




	

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getDriverRidingStatus() {
		return driverRidingStatus;
	}

	public void setDriverRidingStatus(int driverRidingStatus) {
		this.driverRidingStatus = driverRidingStatus;
	}

	public String getLicenceNumber() {
		return licenceNumber;
	}

	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getDriverDeleteStatus() {
		return driverDeleteStatus;
	}

	public void setDriverDeleteStatus(int driverDeleteStatus) {
		this.driverDeleteStatus = driverDeleteStatus;
	}


	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDateOfRegistration() {
		return dateOfRegistration;
	}

	public void setDateOfRegistration(Date dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}
	
	public String getCarNumber() {
		return carNumber;
	}
	
	public Administrator getAdministrator() {
		return administrator;
	}

	public int getModelType() {
		return modelType;
	}

	
	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}

}
