package com.mindtree.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Administrator {
	@Id
	@Digits(fraction = 0, integer = 3)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int administratorId;
	@NotNull
	@Size(max = 35)
	private String administratorName;
	@Column(unique = true)
	@Size(max = 50)
	private String email;
	@Column(unique = true)
	@NotNull
	@Digits(fraction = 0, integer = 10)
	private String phoneNumber;
	@Digits(fraction = 0, integer = 1)
	private int gender;
	@Size(max = 15)
	private String password;
	@Digits(fraction = 0, integer = 1)
	private int authority;
	@Digits(fraction = 0, integer = 1)
	private int administratorDeleteStatus;

	public int getAdministratorId() {
		return administratorId;
	}

	public void setAdministratorId(int administratorId) {
		this.administratorId = administratorId;
	}

	public String getAdministratorName() {
		return administratorName;
	}

	public void setAdministratorName(String administratorName) {
		this.administratorName = administratorName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAuthority() {
		return authority;
	}

	public void setAuthority(int authority) {
		this.authority = authority;
	}

}
