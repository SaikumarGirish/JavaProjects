package com.mindtree.dao.impl;

import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.dao.FacebookLoginDao;
import com.mindtree.entity.User;

public class FacebookLoginDaoImpl implements FacebookLoginDao {

	SessionFactory s = new Configuration().configure().buildSessionFactory();

	public User facebookCheck(User user) {
		Session session = s.openSession();
	
		try {
			session.beginTransaction();
			Query q = session.createQuery(
					"from User where email='" + user.getEmail() + "' and userName='" + user.getUserName() + "'");
			ArrayList<User> list = (ArrayList<User>) q.list();
			session.getTransaction().commit();
			
		   if(list.isEmpty()){
			   user =null;
		   }
			else{
				 user = list.get(0);
			}
		   return user;

		} catch (NullPointerException e) {
			return null;
		}
		finally{
			session.close();
		}
	}

	public User addFBUser(User user) {
		Session session = s.openSession();
		try {
			session.beginTransaction();
			session.save(user);
			session.getTransaction().commit();
			
			
			session.beginTransaction();
			Query q = session.createQuery(
					"from User where email='" + user.getEmail() + "' and userName='" + user.getUserName() + "'");
			ArrayList<User> list = (ArrayList<User>) q.list();
			session.getTransaction().commit();
			user=list.get(0);
			return user;
		} catch (HibernateException e) {
			return user;
		} finally {
			session.close();
		}
	}
}
