package com.mindtree.dao.impl;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.User;
import com.mindtree.exceptions.AdministratorNotFoundException;
import com.mindtree.exceptions.DriverNotFoundException;

public class AddOperatorBookingImpl {
	SessionFactory s = new Configuration().configure().buildSessionFactory();

	public User checkUser(User user) {
		Session session = s.openSession();
		session.beginTransaction();
		String email = user.getEmail();
		Query query = session.createQuery("from User where email='" + email + "'");
		ArrayList<User> userList = (ArrayList<User>) query.list();
		session.getTransaction().commit();
		session.close();
		if (userList.isEmpty()) {

			session = s.openSession();
			session.beginTransaction();
			session.save(user);
			session.getTransaction().commit();
			session.close();
			session = s.openSession();
			session.beginTransaction();
			Query queryUser = session.createQuery("from User order by userId DESC");
			queryUser.setMaxResults(1);
			user = (User) queryUser.uniqueResult();
			session.getTransaction().commit();
			session.close();
		} else {

			user = userList.get(0);
		}
		return user;
	}

	public Administrator getAdministrator(int administrartorId) {
		Administrator operator = null;
		Session session = s.openSession();
		session.beginTransaction();
		try{
		operator = session.get(Administrator.class, administrartorId);
		if(operator == null){
			throw new AdministratorNotFoundException("Administrator not found");
		}
		session.getTransaction().commit();
		}catch(AdministratorNotFoundException e){
			
			return operator;
		}
		finally{
		session.close();
		}
		return operator;
	}

	public Driver getDriver(int driverId) {
		Driver driver = null;
		Session session = s.openSession();
		session.beginTransaction();
        try{
		driver = session.get(Driver.class, driverId);
		if(driver == null){
			throw new DriverNotFoundException("Driver not found");
		}
		driver.setDriverRidingStatus(1);
		session.update(driver);
		session.getTransaction().commit();
        }catch(DriverNotFoundException e){
        	return driver;
        }
		finally{
        session.close();
		}
		return driver;
	}

}
