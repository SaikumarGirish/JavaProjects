package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Driver;

public interface RemoveDriverDao {
	
	public List<Driver> getAllDrivers();
	public void deleteDriver(int driverId);
	public List<Driver> getAssignedDrivers();
	public void unassignDrivers(List<Integer> list);
	public void unassignDriver(int id);

}
