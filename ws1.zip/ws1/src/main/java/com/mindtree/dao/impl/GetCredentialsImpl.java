package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.dao.GetCredentials;
import com.mindtree.entity.Route;

import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
@Repository
public class GetCredentialsImpl implements GetCredentials {
	 SessionFactory  s = new Configuration().configure().buildSessionFactory();
	 @SuppressWarnings("unchecked")
	public List<User> getUsers() {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from User");
		List<User> userList = (ArrayList<User>) query.list();
		session.getTransaction().commit();
		session.close();
		
		return userList;
	}
	 @SuppressWarnings("unchecked")
	public List<Driver> getDrivers() {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Driver");
		ArrayList<Driver> driverList = (ArrayList<Driver>) query.list();
		session.getTransaction().commit();
		session.close();
		s.close();
		return driverList;
	}
	 @SuppressWarnings("unchecked")
	public List<Administrator> getOperators() {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Administrator");
		ArrayList<Administrator> operatorList = (ArrayList<Administrator>) query.list();
		session.getTransaction().commit();
		session.close();
		s.close();
		return operatorList;
	}
	@SuppressWarnings("unchecked")
	public List<Locations> getLocations() {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Locations");
		ArrayList<Locations> locationsList = (ArrayList<Locations>) query.list();
		session.getTransaction().commit();
		session.close();
		
		return locationsList;
	}
	@SuppressWarnings("unchecked")
	public Route getRoute(int pickUpLocation, int dropLocation) {

		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Route where fromLocation_locationId=? and toLocation_locationId=?");
		query.setParameter(0,pickUpLocation);
		query.setParameter(1,dropLocation);
		ArrayList<Route> routeList = (ArrayList<Route>) query.list();
		session.getTransaction().commit();
		session.close();
		
		return routeList.get(0);
	}
	@SuppressWarnings("unchecked")
	public User getUser(String email) {

		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from User where email=?");
		query.setParameter(0,email);
		ArrayList<User> userList = (ArrayList<User>) query.list();
		session.getTransaction().commit();
		session.close();
		
		return userList.get(0);
	}

}
