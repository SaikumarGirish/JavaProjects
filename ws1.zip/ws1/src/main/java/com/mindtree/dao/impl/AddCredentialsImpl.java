package com.mindtree.dao.impl;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
 
import org.hibernate.cfg.Configuration;

import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.dao.AddCredential;
import com.mindtree.entity.Administrator;
 
import com.mindtree.entity.User;

public class AddCredentialsImpl implements AddCredential {
	//Opening Session Factory
	 SessionFactory  s = new Configuration().configure().buildSessionFactory();


	public boolean addOperator(Administrator operator) {
		Session session = s.openSession();
		session.beginTransaction();
		session.save(operator);
		session.getTransaction().commit();
		session.close();
		s.close();
		return true;
	}

	public boolean addDriver(Driver driver) {
		
		Session session = s.openSession();
		session.beginTransaction();
		session.save(driver);
		session.getTransaction().commit();
		session.close();
		s.close();
		return true;
	}
   // 
	public User addUser(User user) {
		 SessionFactory  s = new Configuration().configure().buildSessionFactory();
		
     		 
			Session session = s.openSession();
			try
			{
			session.beginTransaction();

			session.save(user);

			session.getTransaction().commit();
			session.close();
			
			return user;
 
		} 
		catch (Exception ex) {
			 System.out.println("error in DaoImp layer"+ex);
			 
 
			return null;
		}
		}
	

	public boolean addLocation(Locations location) {
		Session session = s.openSession();
		session.beginTransaction();
		session.save(location);
		session.getTransaction().commit();
		session.close();
		s.close();
		return true;
	}

	@Override  /*checking whether email is in database or not if it is not there store data 
	in database else return false*/ 
	public User checkUser(User gmailuser) {
		 
		try{
				Session session = s.openSession();
				session.beginTransaction();
			 
               org.hibernate.Query query =session.createQuery( "from User u where u.email=:Email ");
			   query.setString("Email", gmailuser.getEmail());
			  ArrayList<User> list = (ArrayList<User>)query.list();
//				Long count = (Long)query.uniqueResult();
               			 
				if(list.isEmpty()) 
				{
					 
					session.save(gmailuser);
					session.getTransaction().commit();
					session.close();
					session = s.openSession();
					session.beginTransaction();
					Query query1 = session.createQuery("from User order by userId DESC");
					query1.setMaxResults(1);
					User user = (User) query1.uniqueResult();
					session.getTransaction().commit();
					session.close();
					 
					 
				 return user;
				}
				else{
					
					 
					 User user = list.get(0);
					 
					 session.close();
					return user;
				}
				 
		}
		catch(Exception e){ 
				 
				}
		return gmailuser;
		
		 
		
	}

}
