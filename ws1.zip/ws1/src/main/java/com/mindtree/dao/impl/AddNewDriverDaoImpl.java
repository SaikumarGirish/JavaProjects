package com.mindtree.dao.impl;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.dao.AddNewDriverDao;
import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;

public class AddNewDriverDaoImpl implements AddNewDriverDao{
	
	SessionFactory sessionFactory =  new Configuration().configure().buildSessionFactory();
	@Override
	//adding a new driver by acception details of driver to be added
	public List<Driver> addDriverDao(AddNewDriverDto addNewDriverObj) {
		AddNewDriverDaoImpl addNewDriverDaoImpl = new AddNewDriverDaoImpl();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		try{
		String hql = "from Administrator where administratorId='" + addNewDriverObj.getAdministratorId()+ "'";
		Query query3=session.createQuery(hql);
		List<Administrator> adminList = query3.list();
		Administrator admin = adminList.get(0);
		Driver driver = new Driver();
		driver.setAddress(addNewDriverObj.getAddress());
		driver.setAdministrator(admin);
		driver.setAge(addNewDriverObj.getAge());
		driver.setCarNumber(addNewDriverObj.getCarNumber());
		driver.setDriverDeleteStatus(addNewDriverObj.getDriverDeleteStatus());
		driver.setDriverName(addNewDriverObj.getDriverName());
		driver.setDriverRidingStatus(addNewDriverObj.getDriverRidingStatus());
		driver.setEmail(addNewDriverObj.getEmail());
		driver.setGender(addNewDriverObj.getGender());
		driver.setLicenceNumber(addNewDriverObj.getLicenceNumber());
		driver.setModelType(addNewDriverObj.getModelType());
		driver.setPassword(addNewDriverObj.getPassword());
		driver.setPhoneNumber(addNewDriverObj.getPhoneNumber());
		driver.setDateOfRegistration(new Date(addNewDriverObj.getDateOfRegistration()));
		session.save(driver);
		session.getTransaction().commit();
		return addNewDriverDaoImpl.getDriverDao();
		}catch(Exception e){
			return Collections.emptyList();
		}
		finally{
			session.close();
			sessionFactory.close();
		}
	}
	//getting list of all drivers from database
	@Override
	public List<Driver> getDriverDao() {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		try{
		String hql = "from Driver";
		 Query query = session.createQuery(hql);
		 return query.list();
		}catch(Exception e){
			return Collections.emptyList();
		}
		finally{
			session.close();
			sessionFactory.close();
		}
		
	}
}
