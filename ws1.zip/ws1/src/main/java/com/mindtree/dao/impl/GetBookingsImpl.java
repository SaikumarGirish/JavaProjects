package com.mindtree.dao.impl;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.GetBookings;
import com.mindtree.entity.Booking;

@Repository
public class GetBookingsImpl implements GetBookings
{
	SessionFactory s = new Configuration().configure().buildSessionFactory();
	@Override
	public List<Booking> getBooking() {
		
		Session session = s.openSession();
		try{
		session.beginTransaction();
		Query query = session.createQuery("from Booking b where b.driver.driverId is null");
		List<Booking> bookingList = (List<Booking>) query.list();
		session.getTransaction().commit();
		
		
		return bookingList;
		}
		finally{
			session.close();
			s.close();
		}
	}
	
	
	
	
	

}
