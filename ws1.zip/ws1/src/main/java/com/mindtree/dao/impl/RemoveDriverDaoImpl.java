package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.RemoveDriverDao;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;

@Repository
public class RemoveDriverDaoImpl implements RemoveDriverDao {

	SessionFactory s = new Configuration().configure().buildSessionFactory();

	@SuppressWarnings("unchecked")
	public List<Driver> getAllDrivers() {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Driver D where D.driverDeleteStatus = 0");
		ArrayList<Driver> driverList = (ArrayList<Driver>) query.list();
		session.getTransaction().commit();
		session.close();
		return driverList;
	}

	public void deleteDriver(int driverId) {
		Session session = s.openSession();
		session.beginTransaction();
		Driver driver = session.get(Driver.class, driverId);
		driver.setDriverDeleteStatus(1);
		session.update(driver);
		session.getTransaction().commit();
		session.close();
	}

	@SuppressWarnings("unchecked")
	public List<Driver> getAssignedDrivers() {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Driver D where D.driverRidingStatus = 1 and D.driverDeleteStatus = 0");
		ArrayList<Driver> driverList = (ArrayList<Driver>) query.list();
		session.getTransaction().commit();
		session.close();
		return driverList;
	}

	@Override
	public void unassignDrivers(List<Integer> list) {
		for (int i = 0; i < list.size(); i++) {
			unassignDriver(list.get(i));
		}

	}

	@Override
	public void unassignDriver(int id) {
		Session session = s.openSession();
		session.beginTransaction();
		Driver driver = session.get(Driver.class, id);
		driver.setDriverRidingStatus(0);
		session.update(driver);
		session.getTransaction().commit();
		session.close();
		List<Integer> bookingId = getBookingList(id);
		changeStatus(bookingId);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> getBookingList(int id) {
		Session session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("select B.bookingId from Booking B where B.driver.driverId =? and B.bookingStatus != 2");
		query.setParameter(0,id);
		ArrayList<Integer> bookingList = (ArrayList<Integer>) query.list();
		session.getTransaction().commit();
		session.close();
		return bookingList;
	}
	
	public void changeStatus(List<Integer> bId){
		for(int i=0; i<bId.size(); i++){
			Session session = s.openSession();
			session.beginTransaction();
			Booking booking = session.get(Booking.class, bId.get(i));
			booking.setBookingStatus(2);
			session.update(booking);
			session.getTransaction().commit();
			session.close();
		}
	}

}
