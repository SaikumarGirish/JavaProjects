package com.mindtree.dao;

import java.util.List;

import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;

public interface AddNewDriverDao {

	List<Driver> addDriverDao(AddNewDriverDto addNewDriverObj);

	List<Driver> getDriverDao();

}
