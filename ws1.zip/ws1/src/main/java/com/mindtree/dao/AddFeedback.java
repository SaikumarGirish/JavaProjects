package com.mindtree.dao;

import com.mindtree.dto.Feedback;
import com.mindtree.exceptions.BookingIdNotFoundException;

public interface AddFeedback {
public boolean addFeedback(Feedback feedback) throws BookingIdNotFoundException;
}
