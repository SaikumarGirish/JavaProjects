package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.dao.GetEmail;
@SuppressWarnings("unchecked")
public class GetEmailImp implements GetEmail{
	SessionFactory s = new Configuration().configure().buildSessionFactory();
   public  List<String> getEmail(){
			Session session = s.openSession();
			session.beginTransaction();
			String hql="select email from User where ";
			Query query = session.createQuery(hql);
			ArrayList<String> emailList =   (ArrayList<String>) query.list();
			session.getTransaction().commit();
			session.close();
			s.close();
			return emailList;
			
		}
	}
