
package com.mindtree.dao.impl;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.dao.MyRidesDao;
import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;
import com.mindtree.entity.Route;

public class MyRidesDaoImpl implements MyRidesDao {
	List<Booking> emptyList = new ArrayList<>();
	List<Locations> emptyLoc = new ArrayList<>();
	String constQuery="from Booking where bookingStatus=";
	String fromBook = "from Booking where bookingId=";
	String fromLoc = "from Locations where location=";
	SessionFactory sessionFactory =  new Configuration().configure().buildSessionFactory();
	//getting past ride detail from database
	@SuppressWarnings("unchecked")
	public List<Booking> pastRides(int uId){	
		Session session1=sessionFactory.openSession();
		try{
			String hql = constQuery + "? and user_userId=?";
		Query query1=session1.createQuery(hql);
 
		query1.setParameter(0, 2);
		query1.setParameter(1,uId);
		return (List<Booking>)query1.list();
		}
		catch(Exception e){
			return emptyList;
		}	
		finally {
			 session1.close();
			    sessionFactory.close();
		}
	}
	//getting ongoing ride detail from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> ongoingRides(int uId1) {
		Session session2=sessionFactory.openSession();
		try{
			String hql = constQuery + "?  and user_userId=?";
		Query query2=session2.createQuery(hql);
		query2.setParameter(0,0);
		query2.setParameter(1, uId1);
		return (List<Booking>)query2.list();
		}
		catch(Exception e){
			return emptyList;
		}
		finally {
			 session2.close();
			    sessionFactory.close();
		}
	}
	//getting upcoming ride detail from database
	@Override
	public List<Booking> upcomingRides(int uId) {
		Session session=sessionFactory.openSession();
		try{
			String hql = constQuery + "? and deleted=? and user_userId=?";
		Query query=session.createQuery(hql);
		query.setParameter(0,1);
		query.setParameter(1,0);
		query.setParameter(2,uId);
		return (List<Booking>)query.list();
		}
		catch(Exception e){
			return emptyList;
		}
		finally {
			 session.close();
			    sessionFactory.close();
		}
	}
	//getting all locations from database
	@Override
	public List<Locations> getlocations() {
		Session session=sessionFactory.openSession();
		try{
		String hql="from Locations";
		Query query=session.createQuery(hql);
		return (List<Locations>)query.list();
		}
		catch(Exception e){
			return emptyLoc;
		}
		finally {
			 session.close();
			    sessionFactory.close();
		}
	}
	//changing destination of ongoing ride in database
	@Override
	public List<Booking> changingDestination(ChangeDestination changeDestObj) {
		Session session=sessionFactory.openSession();
		try{
		session.beginTransaction();
		String hql = fromBook + "?";
		Query query=session.createQuery(hql);
		query.setParameter(0,changeDestObj.getBookingId() );
		List<Booking> bookingList=query.list();
		Booking booking =bookingList.get(0);
		Route route = booking.getRoute();
		int carType = booking.getCarType();
		String pickUp = route.getFromLocation().getLocation();
		
		
		String hql1 = fromLoc + "?";
		Query query1=session.createQuery(hql1);
		query1.setParameter(0, pickUp);
		List<Locations> loc1=query1.list();
		Locations pickupLoc = loc1.get(0);
		int pickupLocId = pickupLoc.getLocationId();
		
		String hql2 = fromLoc + "?";
		Query query2=session.createQuery(hql2);
		query2.setParameter(0, changeDestObj.getLocation());
		List<Locations> loc2=query2.list();
		Locations dropLoc = loc2.get(0);
		int dropLocId = dropLoc.getLocationId();
	
		String hql3 = "from Route where fromLocation_locationId=? and toLocation_locationId=?";
		Query query3=session.createQuery(hql3);
		query3.setParameter(0, pickupLocId);
		query3.setParameter(1, dropLocId);
		List<Route> routes = query3.list();
		Route r = routes.get(0);
	
		int distance = r.getDistance();
		MyRidesDaoImpl myRidesDaoImpl = new MyRidesDaoImpl();
		int cost = myRidesDaoImpl.calculateCost(distance,carType);
		
		
		booking.setRoute(r);
		booking.setCost(cost);
		session.update(booking);
		session.getTransaction().commit();
		
		String finalHql = fromBook+"?";
		Query finalQuery=session.createQuery(finalHql);
		finalQuery.setParameter(0,changeDestObj.getBookingId());
		return (List<Booking>)finalQuery.list();
		}
		catch(Exception e){
			return emptyList;
		}
		finally {
			 session.close();
			    sessionFactory.close();
		}
	}
	//deleting a given upcoming ride from database
	@Override
	public List<Booking> deleteDao(int id) {
		Session session=sessionFactory.openSession();
		try{
		session.beginTransaction();
		String hql = fromBook + "?";
		Query query=session.createQuery(hql);
		query.setParameter(0, id);
		List<Booking> bookingList=(List<Booking>)query.list();
		Booking booking = bookingList.get(0);
		booking.setDeleted(1);
		session.update(booking);
		session.getTransaction().commit();
		
		String hql1="from Booking where bookingStatus=? and deleted=?";
		Query query1=session.createQuery(hql1);
		query1.setParameter(0, 1);
		query1.setParameter(1, 0);
		return (List<Booking>)query1.list();
		}
		catch(Exception e){
			return emptyList;
		}
		finally {
			 session.close();
			    sessionFactory.close();
		}
		
	}
	//change pickup and drop location of given upcoming ride from database
	@Override
	public List<Booking> updateUpcomingDao(UpdateUpcoming updateObj,String pickUp) {
		Session session=sessionFactory.openSession();
		try{
		session.beginTransaction();
		
		String hql = fromBook  + "?";
		Query query=session.createQuery(hql);
		query.setParameter(0, updateObj.getBookingId());
		List<Booking> bookingList=query.list();
		Booking booking =bookingList.get(0);
	
		
		String hql1 = fromLoc + "?";
		Query query1=session.createQuery(hql1);
		query1.setParameter(0, pickUp );
		List<Locations> loc1=query1.list();
		Locations pickupLoc = loc1.get(0);
		int pickupLocId = pickupLoc.getLocationId();
		
		String hql2 = fromLoc + "?";
		Query query2=session.createQuery(hql2);
		query2.setParameter(0, updateObj.getLocation());
		List<Locations> loc2=query2.list();
		Locations dropLoc = loc2.get(0);
		int dropLocId = dropLoc.getLocationId();
		
		String hql3 = "from Route where fromLocation_locationId=? and toLocation_locationId=?";
		Query query3=session.createQuery(hql3);
		query3.setParameter(0, pickupLocId);
		query3.setParameter(1, dropLocId);
		List<Route> routes = query3.list();
		Route r = routes.get(0);
		MyRidesDaoImpl myRidesDaoImpl = new MyRidesDaoImpl();
		int cost = myRidesDaoImpl.calculateCost(r.getDistance(),booking.getCarType()); 
		
		booking.setCost(cost);
		booking.setRoute(r);
		session.update(booking);
		session.getTransaction().commit();
		return bookingList;
		}
		catch(Exception e){
			return emptyList;
		}
		finally {
			 session.close();
			    sessionFactory.close();
		}
	}
	//getting delettedrides of a given user
	@Override
	public List<Booking> getShowDeletedDao(int uId) {
		Session session=sessionFactory.openSession();
		try{
		String hql="from Booking where deleted=? and user_userId=?";
		Query query=session.createQuery(hql);
		query.setParameter(0, 1);
		query.setParameter(1, uId);
		return (List<Booking>)query.list();
		}
		catch(Exception e){
			return emptyList ;
		}
		finally {
			 session.close();
			    sessionFactory.close();
		}
	}
	//calculating cost for changing the booking details
	public int calculateCost(int distance, int carType){
		int cost = 0;
		if (distance <= 4) {
			if (carType == 0) {
				cost = 40;
			} else if (carType == 1) {
				cost = 50;
			}
		}
		else {
			if (carType == 0) {
				cost = (((distance - 4) * 11) + 40);

			} else if (carType == 1) {
				cost = (((distance - 4) * 13) + 50);
			}
		}
		
		return cost;
		
	}
	
}
