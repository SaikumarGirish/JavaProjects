package com.mindtree.dao.impl;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.GetFreeDriverDao;
import com.mindtree.entity.Driver;


@Repository
public class GetFreeDriverImpl implements GetFreeDriverDao {
	
	SessionFactory s = new Configuration().configure().buildSessionFactory();
	@Override
	public List<Driver> getFreeDrivers() {
			
		Session session = s.openSession();
		try{
		session.beginTransaction();
		Query query = session.createQuery("from Driver where driverRidingStatus=0 and driverDeleteStatus=0");
		List<Driver> driverList = (List<Driver>) query.list();
		session.getTransaction().commit();
		
		return driverList;
		}
		finally{
			session.close();
			s.close();
		}
	}

}
