package com.mindtree.dao;

import java.util.List;

import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;

public interface MyRidesDao {
	public List<Booking> pastRides(int uId);

	public List<Booking> ongoingRides(int uId);

	public List<Booking> upcomingRides(int uId);

	public List<Locations> getlocations();

	public List<Booking> changingDestination(ChangeDestination changeDestObj);

	public List<Booking> deleteDao(int id);

	public List<Booking> updateUpcomingDao(UpdateUpcoming updateObj,String pickUp);

	public List<Booking> getShowDeletedDao(int uId);
}
