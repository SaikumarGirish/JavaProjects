package com.mindtree.dao.impl;


import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.dao.AssignDao;
import com.mindtree.dto.AssignDriver;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;

public class AssignDaoImpl implements AssignDao
{
	SessionFactory s =  new Configuration().configure().buildSessionFactory();
	@Override
	public boolean get(AssignDriver detail) {
		
		Session session = s.openSession();
		try{
		session.beginTransaction();
		int adminId = detail.getAdministratorId();
		int driveId =detail.getDriverId();
		int bookId =detail.getBookingId();
		Date driverAssignTime =detail.getDriverAssignTime();
		AddOperatorBookingImpl addOperatorBookingImpl = new AddOperatorBookingImpl();
		Driver driver = addOperatorBookingImpl.getDriver(driveId);
		Administrator operator = getOperator(adminId);

		Booking booking = session.get(Booking.class,bookId);
		booking.setDriver(driver);
		booking.setAdministrator(operator);
		booking.setDriverAssignTime(driverAssignTime);
		session.update(booking);
		session.getTransaction().commit();
		return true;
		}
		finally
		{
			session.close();
		}
		
		
	}
	
	
	private Administrator getOperator(int adminId){
		Session session = s.openSession();
		session.beginTransaction();
		Administrator operator = session.get(Administrator.class,adminId);
		session.getTransaction().commit();
		session.close();
		return operator;
	}

}
