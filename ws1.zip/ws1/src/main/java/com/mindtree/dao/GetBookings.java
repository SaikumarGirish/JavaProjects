package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Booking;

public interface GetBookings {

	List<Booking> getBooking();

}
