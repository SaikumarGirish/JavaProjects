package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.Login;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.exceptions.UserNotFoundException;


@Repository
public class LoginImpl implements Login

{
	SessionFactory s = new Configuration().configure().buildSessionFactory();

	@Override
	public User check(User u) throws UserNotFoundException
	{
		String checkUser= " ";
		String checkPass = " ";
		User emailId = null ;
		Session session = s.openSession();
		session.beginTransaction();
		try {

			Query q = session.createQuery("from User where Email='" + u.getEmail() + "'");
			List<User> list = (ArrayList<User>) q.list();
			for (User o : list) {
				checkUser = o.getEmail();
				checkPass = o.getPassword();
				emailId = o;
			}
			
		} catch (NullPointerException e) {
			throw new UserNotFoundException("User Not Found");
		}
		finally
		{
			session.close();
		}

			if ((checkUser.equalsIgnoreCase(u.getEmail())) && checkPass.equals(u.getPassword())) {
				return emailId;
			} else {
				return null;
			}

		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Administrator> operatorLogin(Administrator a) throws OperatorNotFoundException {
		String findEmail= " ";
		String findPass = " ";
		Session session = s.openSession();
		List<Administrator> list=null;
		session.beginTransaction();
		Query que = session.createQuery("from Administrator where Email='" + a.getEmail() +"'");
		try {
			list = (List<Administrator>) que.list();
			for (Administrator i : list) {
				findEmail = i.getEmail();
				findPass = i.getPassword();
			}
		} catch (NullPointerException ex) {
			throw new OperatorNotFoundException();
		}
		finally
		{
			session.close();
		}
		if (!(list.isEmpty())&&(findEmail.equalsIgnoreCase(a.getEmail())) && findPass.equals(a.getPassword())) {
			return list;
		} else {
			return Collections.emptyList();
		}

	}

}
