package com.mindtree.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddBooking;
import com.mindtree.entity.Booking;
@Repository
public class AddBookingImpl implements AddBooking {
	SessionFactory s = new Configuration().configure().buildSessionFactory();
/*This method is used to insert booking details 
 * into the booking table when user 
 * books a cab by logging in and returns the last inserted booking 
 * Id to front end for further use*/
	public Booking addNewBooking(Booking booking) {
		Session session = s.openSession();
		session.beginTransaction();
		session.save(booking);
		session.getTransaction().commit();
		session.close();
		session = s.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Booking order by bookingId DESC");
		query.setMaxResults(1);
		booking = (Booking) query.uniqueResult();
		session.getTransaction().commit();
		session.close();
	
		return booking;
	}
}
