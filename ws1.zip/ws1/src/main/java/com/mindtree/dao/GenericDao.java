package com.mindtree.dao;

public interface GenericDao<T> {

	public T add(T t);

	public T get(int id);
}
