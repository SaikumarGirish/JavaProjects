package com.mindtree.dto;

public class UpdateUpcoming {
	private int bookingId;
	private String location;
	public int getBookingId() {
		return bookingId;
	}
	
	
	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	
		
}
