package com.mindtree.dto;

public class Feedback {
private int bookingId;
/**
 * @param bookingId
 * @param rating
 * @param commnet
 */
public Feedback(int bookingId, int rating, String commnet) {
	super();
	this.bookingId = bookingId;
	this.rating = rating;
	this.commnet = commnet;
}
public int getBookingId() {
	return bookingId;
}
public void setBookingId(int bookingId) {
	this.bookingId = bookingId;
}
private int rating;
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
public String getCommnet() {
	return commnet;
}
public void setCommnet(String commnet) {
	this.commnet = commnet;
}
/**
 * @param rating
 * @param commnet
 */
public Feedback(int rating, String commnet) {
	super();
	this.rating = rating;
	this.commnet = commnet;
}
/**
 * 
 */
public Feedback() {
	super();
	 
}
private String commnet;

	
}
