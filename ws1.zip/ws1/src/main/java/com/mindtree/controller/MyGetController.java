package com.mindtree.controller;


import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dao.GetCredentials;
import com.mindtree.dao.impl.GetCredentialsImpl;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.entity.User;

@RestController
public class MyGetController {

	@RequestMapping(value = "/allUsers", method = RequestMethod.GET)
	public List<User> getUserList() {
		GetCredentials getCredential = new GetCredentialsImpl();
		return getCredential.getUsers();
	}

	@RequestMapping(value = "/allDrivers", method = RequestMethod.GET)
	public List<Driver> getDriverList() {
		GetCredentials getCredential = new GetCredentialsImpl();
		return  getCredential.getDrivers();
	}

	@RequestMapping(value = "/allOperators", method = RequestMethod.GET)
	public List<Administrator> getOperatorList() {
		GetCredentials getCredential = new GetCredentialsImpl();
		return getCredential.getOperators();
	}

	@RequestMapping(value = "/allLocations", method = RequestMethod.GET)
	public List<Locations> getLocationsList() {
		GetCredentials getCredential = new GetCredentialsImpl();
		return getCredential.getLocations();
	}

	@RequestMapping(value = "/oplogin", method = RequestMethod.GET)
	public boolean getOperatorList(@RequestBody User user) {

		return true;
	}

	
}