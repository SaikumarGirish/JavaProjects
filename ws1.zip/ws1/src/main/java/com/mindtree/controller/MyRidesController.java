package com.mindtree.controller;

import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;
import com.mindtree.service.MyRidesService;
import com.mindtree.service.impl.MyRidesServiceImpl;

@RestController
public class MyRidesController {
	
	//mapping for getting past rides of a user
	@RequestMapping(value = "/past/{id}")
	@ResponseBody
	public List<Booking> pasts(@PathVariable("id") int uId) {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.getPastRides(uId);
	}
	
	//mapping for getting deleted rides of a user
	@RequestMapping(value = "/showDeleted/{id}")
	@ResponseBody
	public List<Booking> showDeleted(@PathVariable("id") int uId) {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		 return myRidesService.getShowDeleted(uId);
	}
	
	//mapping for getting ongoing rides of a user
	@RequestMapping(value = "/ongoing/{id}")
	@ResponseBody
	public List<Booking> ongoing(@PathVariable("id") int uId) {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.getOngoingRides(uId);
	}
	
	//mapping for getting upcoming rides of a user
	@RequestMapping(value = "/upcoming/{id}")
	@ResponseBody
	public List<Booking> upcoming(@PathVariable("id") int uId) {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.getUpcomingRides(uId);
	}
	
	//mapping for getting all locations to display in select box
	@RequestMapping(value = "/getLocations")
	@ResponseBody
	public List<Locations> getLocations() {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.getAllLocation();
	}
	
	//mapping to change destination for ongoing ride
	@RequestMapping(value = "/changeDestination")
	public List<Booking> changeDestination(@RequestBody ChangeDestination changeDestObj) {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.changeDestination(changeDestObj);
	}

	// mapping to cancel any upcoming ride
	@RequestMapping(value="/deleteRecord/{deleteId}")
	@ResponseBody
	public List<Booking> deleteRow(@PathVariable("deleteId") int id){
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.deleteService(id);
	}
	
	// mapping to change location for upcoming ride
	@RequestMapping(value = "/changeUpcoming/{pickUpLoc}")
	public List<Booking> changeUpcoming(@PathVariable("pickUpLoc") String pickUp,@RequestBody UpdateUpcoming updateObj) {
		MyRidesService myRidesService = new MyRidesServiceImpl();
		return myRidesService.updateUpcomingService(updateObj,pickUp);
	}
	
	
	
}
