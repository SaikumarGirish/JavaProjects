package com.mindtree.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.BookingData;
import com.mindtree.dto.OperatorBookingData;
import com.mindtree.dto.PostBookingData;
import com.mindtree.service.impl.CalculateCostImpl;

@RestController
public class BookingController {
	/*This method used to add booking data in database after user books a cab, 
	 the information is sent to booking table*/
	@RequestMapping(value = "/addBooking", method = RequestMethod.POST)
	public PostBookingData addBookingDetails(@RequestBody BookingData bookingData) {
		CalculateCostImpl calculateCost = new CalculateCostImpl();
		System.out.println(bookingData.getBookingStatus());
		return calculateCost.calculateCost(bookingData);
		
	}
	/*This method is used to add booking data in database after operator books a cab and
	  the data will be stored into booking table*/
	@RequestMapping(value = "/operatorbooking", method = RequestMethod.POST)
	public PostBookingData operatorBooking(@RequestBody OperatorBookingData operatorBookingData){
		CalculateCostImpl calculateCost = new CalculateCostImpl();
		return calculateCost.operatorCalculateCost(operatorBookingData);
	}
	
}
