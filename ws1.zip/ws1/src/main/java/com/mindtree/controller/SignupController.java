package com.mindtree.controller;
 
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.Gmaildata;
import com.mindtree.entity.User;
 
 
import com.mindtree.service.LoginService;
 
 
 
import com.mindtree.service.GetEmailService;
import com.mindtree.service.GetPhoneService;
  
 
 
import com.mindtree.service.impl.GetEmailServiceImpl;
import com.mindtree.service.impl.GetPhoneSErviceImpl;
import com.mindtree.service.impl.LoginServiceImpl;


@RestController
public class SignupController {

	LoginService longinService=new LoginServiceImpl();
	@CrossOrigin
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	
	//Saving data to the database after signup
	public User getSignData(@RequestBody User user) {
		return longinService.addUser(user);
	}
	@CrossOrigin /*getting data from google login which include name and email and stores the
	data in database if it is new user*/
	@RequestMapping(value = "/gmail", method = RequestMethod.POST)
	public User gmaidata(@RequestBody Gmaildata user)
	{
		 
		return longinService.checkUser(user );
		
	}
	
	@RequestMapping(value = "/allEmail", method = RequestMethod.GET)
	//Return All user's EmailId Exist in Database
	public List getEmailList() {
		
		GetEmailService getEmailService=new GetEmailServiceImpl();
		
		return getEmailService.getEmail();
		
	}
	
	
	@CrossOrigin
	@RequestMapping(value = "/allPhone", method = RequestMethod.GET)
	//Return All user's PhoneNo Exist in Database
	public List getPhonelList() {
		
		GetPhoneService getPhoneService=new GetPhoneSErviceImpl();
		
		return  getPhoneService.getPhone();
		
	}
	 
}
