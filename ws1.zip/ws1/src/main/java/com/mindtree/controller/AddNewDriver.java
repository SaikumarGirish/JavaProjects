package com.mindtree.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;
import com.mindtree.service.AddNewDriverService;
import com.mindtree.service.impl.AddNewDriverServiceImpl;

@RestController
public class AddNewDriver {
	
	//mapping for adding a new driver
	@RequestMapping(value = "/addNewDriver")
	public List<Driver> changeDestination(@RequestBody AddNewDriverDto addNewDriverObj) {
	   AddNewDriverService addNewDriverService = new AddNewDriverServiceImpl();
	    return addNewDriverService.addNewDriverService(addNewDriverObj);
	}
	
	//mapping for getting list of all drivers 
	@RequestMapping(value = "/getDriverList")
	public List<Driver> getDriver() {
	   AddNewDriverService addNewDriverService = new AddNewDriverServiceImpl();
	   return addNewDriverService.getDriverService();
		
	}

}