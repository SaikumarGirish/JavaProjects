package com.mindtree.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.mindtree.entity.Driver;
import com.mindtree.service.GetFreeDriverService;
import com.mindtree.service.impl.GetFreeDriverServiceImpl;

@RestController
public class GetFreeDriversController {
	
	/*This method is used to get all the free drivers who are not in the ride 
	 and sending the list of free drivers to assign for new bookings */
	
	@RequestMapping(value = "/freeDrivers", method = RequestMethod.GET)
	public List<Driver> getFreeDriverList()
	
	{
	
		GetFreeDriverService serve = new GetFreeDriverServiceImpl();
		
		return serve.getFreeDrivers();
		
	}
	

}
