package com.mindtree.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.Driver;
import com.mindtree.service.RemoveDriverService;
import com.mindtree.service.impl.RemoveDriverServiceImpl;

@RestController
public class RemoveDriverController {
	
	RemoveDriverService rdService=new RemoveDriverServiceImpl();

	@ResponseBody
	@RequestMapping(value="listDrivers/",method=RequestMethod.GET)
	public List<Driver> listDrivers() {
		return rdService.getAllDrivers();
	}

	@ResponseBody
	@RequestMapping(value="deleteDriver/{id}",method=RequestMethod.GET)
	public List<Driver> deleteDriver(@PathVariable("id") int id) {
		rdService.deleteDriver(id);
		return rdService.getAllDrivers();
	}
	
	@ResponseBody
	@RequestMapping(value="/assignedDrivers",method=RequestMethod.GET)
	public List<Driver> listAssignedDriver() {
		return rdService.getAssignedDrivers();
	}
	
	@ResponseBody
	@RequestMapping(value="unassignDriver/{id}",method=RequestMethod.GET)
	public List<Driver> unassignDriver(@PathVariable("id") int id) {
		rdService.unassignDriver(id);
		return rdService.getAssignedDrivers();
	}

	@ResponseBody
	@RequestMapping(value="/unassignDrivers", method=RequestMethod.POST)
	public List<Driver> unAssignAll(@RequestBody List<Integer> list) {
		rdService.unassignDrivers(list);
		return rdService.getAssignedDrivers();
	}
	
}
