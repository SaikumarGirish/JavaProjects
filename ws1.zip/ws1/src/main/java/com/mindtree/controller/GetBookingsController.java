package com.mindtree.controller;


import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.entity.Booking;
import com.mindtree.service.GetBookingsService;
import com.mindtree.service.impl.GetBookingsServiceImpl;


@RestController
public class GetBookingsController {
	
	/*This method is used to get all the new bookings done by the user and
	sending to the operator to assign the driver for the booking*/
	
	@RequestMapping(value = "/getbookings", method = RequestMethod.GET)
	public List<Booking> getdata() 
	{
		
		GetBookingsService serve = new GetBookingsServiceImpl();			
       return serve.getBookings();
}
	
}
