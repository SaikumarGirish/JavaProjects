package com.mindtree.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.service.LoginService;
import com.mindtree.service.impl.LoginServiceImpl;

@RestController
public class OperatorLoginController 
{
	
	LoginService service = new LoginServiceImpl();
	
	@RequestMapping(value = "/oplogin", method = RequestMethod.POST)
	public List<Administrator> getoperatordata(@RequestBody Administrator admin) {	
	try {
			return service.setOperator(admin);
			
		} catch (OperatorNotFoundException e) {
			return Collections.emptyList();
		}
	}

}

