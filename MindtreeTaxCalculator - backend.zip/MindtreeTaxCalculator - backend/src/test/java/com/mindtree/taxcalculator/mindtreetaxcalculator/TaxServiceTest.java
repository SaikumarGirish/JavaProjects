package com.mindtree.taxcalculator.mindtreetaxcalculator;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Objects;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.mockito.Mockito.doThrow;

import com.mindtree.taxcalculator.dto.TaxCalculationDto;
import com.mindtree.taxcalculator.dto.ZoneWisePropetyTaxDto;
import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;
import com.mindtree.taxcalculator.service.TaxService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TaxServiceTest {

	@Autowired
	private TaxService taxService;

	@Test
	public void testListLength() {
		List<Long> taxYears = taxService.getDistinctTaxYears();
		assertTrue(taxYears.size() > 1);
	}

	@Test
	public void testGetTaxZoneWise() {
		List<ZoneWisePropetyTaxDto> zoneWisePropetyTaxes = taxService.getTaxZoneWise(Long.valueOf(2017));
		zoneWisePropetyTaxes.forEach(zoneWisePropetyTax -> {
			assertTrue(Objects.nonNull(zoneWisePropetyTax));
		});
	}

	@Test
	public void testCalculateTax() {
		TaxCalculationDto taxCalculationDto = new TaxCalculationDto();
		taxCalculationDto.setBuiltArea(Long.valueOf(345));
		taxCalculationDto.setConstructedYear(Long.valueOf(1986));
		taxCalculationDto.setDescId(Long.valueOf(2));
		taxCalculationDto.setStatus(BuildingOwnerStatus.OWNER.toString());
		taxCalculationDto.setYearOfAssessment(Long.valueOf(2019));
		taxCalculationDto.setZoneId(Long.valueOf(1));
		assertTrue(taxService.calculateTaxForUser(taxCalculationDto) == 96.2396);
	}

	@Mock
	TaxService taxesService;

	@Test(expected = NullPointerException.class)
	public void testExceptionForTaxZoneWise() {
		doThrow(new NullPointerException("Fetch Operation failed due to NULL values")).when(taxesService)
				.getTaxZoneWise(Long.valueOf(2026));
		assertTrue(Objects.isNull(taxesService.getTaxZoneWise(Long.valueOf(2026))));
	}

	@Test(expected = NullPointerException.class)
	public void getExceptionDistinctYears() {
		doThrow(new NullPointerException("Get list failed due to lack of data")).when(taxesService)
				.getDistinctTaxYears();
		assertTrue(Objects.isNull(taxesService.getDistinctTaxYears()));
	}

	@Test(expected = NullPointerException.class)
	public void testNegativeCaseOfCalculateTax() {
		doThrow(new NullPointerException("Got NULL POINTER beacuse of input data is NULL")).when(taxesService)
				.calculateTaxForUser(null);
		assertTrue(Objects.isNull(taxesService.calculateTaxForUser(null)));
	}

}
