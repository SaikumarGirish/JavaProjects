package com.mindtree.taxcalculator.repository.impl;


import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.mindtree.taxcalculator.repository.UAVRepository;

@Repository
public class UAVRepositoryImpl implements UAVRepository {

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	private final String getUavValue = "select value from Uav where desc_id = :descId and zone_id = :zoneId and status = :status";

	@Override
	public Double findUavValue(Long zoneId, Long descId, String buildingOwnerStatus) {
		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
		session.beginTransaction();
		Double value = session.createQuery(getUavValue, Double.class).setParameter("descId", descId)
				.setParameter("zoneId", zoneId).setParameter("status", buildingOwnerStatus.toString())
				.getSingleResult();
		session.getTransaction().commit();
		session.close();
		return value;
	}
}
