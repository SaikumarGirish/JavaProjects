package com.mindtree.taxcalculator.enums;

public enum BuildingOwnerStatus {
	TENANTED,OWNER
}
