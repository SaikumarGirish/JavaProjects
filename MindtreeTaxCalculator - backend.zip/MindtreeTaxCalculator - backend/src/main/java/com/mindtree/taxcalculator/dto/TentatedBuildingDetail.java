package com.mindtree.taxcalculator.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;

import lombok.Data;

@Data
public class TentatedBuildingDetail {

	@NotEmpty
	private BuildingOwnerStatus buildingOwnerStatus;
	@NotNull
	private Double collectedTax;
}
