package com.mindtree.taxcalculator.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.taxcalculator.dto.TaxCalculationDto;
import com.mindtree.taxcalculator.dto.ZoneWisePropetyTaxDto;
import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;
import com.mindtree.taxcalculator.exception.ResourceNotFoundException;
import com.mindtree.taxcalculator.model.Description;
import com.mindtree.taxcalculator.model.Tax;
import com.mindtree.taxcalculator.model.Zone;
import com.mindtree.taxcalculator.repository.DescriptionRepository;
import com.mindtree.taxcalculator.repository.TaxRepository;
import com.mindtree.taxcalculator.repository.ZoneRepository;
import com.mindtree.taxcalculator.service.TaxService;
import org.springframework.http.HttpStatus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/tax-ui/v1.0")
public class TaxController {
	
	private static final Logger logger = LoggerFactory.getLogger(TaxController.class);
	
	@Autowired
	private ZoneRepository zoneRepository;

	@Autowired
	private DescriptionRepository descriptionRepository;

	@Autowired
	private TaxService taxservice;

	@Autowired
	private TaxRepository taxRepository;

	@GetMapping("/getzones")
	public List<Zone> getZones() {
		logger.info("##API CALL## -- GET -- /getzones");
		return zoneRepository.findAll();
	}

	@GetMapping("/getdescriptions")
	public List<Description> getDescriptions() {
		logger.info("##API CALL## -- GET -- /getdescriptions");
		return descriptionRepository.findAll();
	}

	@PostMapping("/calculatetax")
	public ResponseEntity<Double> calculateTax(@RequestBody TaxCalculationDto taxCalculationDto)
			throws ResourceNotFoundException {
		logger.info("##API CALL## -- POST -- /calculatetax");
		validateTaxCalculationDto(taxCalculationDto);
		return ResponseEntity.ok((taxservice.calculateTaxForUser(taxCalculationDto)));
	}

	@PostMapping("/savetaxdetails")
	@ResponseStatus(HttpStatus.CREATED)
	public Long saveTaxDetails(@RequestBody Tax tax) {
		logger.info("##API CALL## -- GET -- /savetaxdetails");
		return taxRepository.save(tax).getId();
	}

	@GetMapping("/getpaidtaxdetails/{year}")
	public ResponseEntity<List<ZoneWisePropetyTaxDto>> getPaidTaxDetails(@PathVariable("year") Long year) {
		logger.info("##API CALL## -- POST -- /getpaidtaxdetails/"+year);
		return ResponseEntity.ok(taxservice.getTaxZoneWise(year));
	}

	@GetMapping("/getdistinctpaidtaxyears")
	public ResponseEntity<List<Long>> getDistinctPaidTaxYears() {
		logger.info("##API CALL## -- GET -- /getdistinctpaidtaxyears");
		return ResponseEntity.ok(taxservice.getDistinctTaxYears());
	}

	private void validateTaxCalculationDto(TaxCalculationDto taxCalculationDto) throws ResourceNotFoundException {
		if (zoneRepository.findById(taxCalculationDto.getZoneId()).equals(Optional.empty())) {
			logger.error("ResourceNotFoundException(Zone does not exist with id: "+taxCalculationDto.getZoneId()+")");
			throw new ResourceNotFoundException("Zone does not exist with id: " + taxCalculationDto.getZoneId());
		}

		if (zoneRepository.findById(taxCalculationDto.getDescId()).equals(Optional.empty())) {
			logger.error("ResourceNotFoundException(Description does not exist with id: "+taxCalculationDto.getDescId()+")");
			throw new ResourceNotFoundException("Description does not exist with id: " + taxCalculationDto.getDescId());
		}

		if (!(taxCalculationDto.getStatus().equals(BuildingOwnerStatus.OWNER.toString())
				|| taxCalculationDto.getStatus().equals(BuildingOwnerStatus.TENANTED.toString()))) {
			logger.error("ResourceNotFoundException(Invalid building status: "+taxCalculationDto.getStatus()+")");
			throw new ResourceNotFoundException("Invalid building status: " + taxCalculationDto.getStatus());
		}
	}
}
