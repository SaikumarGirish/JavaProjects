package com.mindtree.taxcalculator.dto;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class ZoneDetail {
	
	@NotEmpty
	private String zoneName;
	private TentatedBuildingDetail tentatedBuildingDetail;
	private OwnedBuildingDetail ownedBuildingDetail;

}
