package com.mindtree.taxcalculator.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.taxcalculator.model.Zone;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public interface ZoneRepository extends JpaRepository<Zone, Long>{

}
