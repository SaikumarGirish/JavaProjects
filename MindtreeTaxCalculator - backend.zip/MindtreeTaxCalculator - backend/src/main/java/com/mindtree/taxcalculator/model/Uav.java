package com.mindtree.taxcalculator.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "uav")
@EqualsAndHashCode(of = "id")
public class Uav {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private Long id;

	@JoinColumn(name = "zone_id", nullable = false)
	@ManyToOne(cascade=CascadeType.ALL)
	private Zone zone;

	@JoinColumn(name = "desc_id", nullable = false)
	@ManyToOne(cascade=CascadeType.ALL)
	private Description description;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private BuildingOwnerStatus buildingOwnerStatus;

	@Column(name = "value")
	private Double value;

}
