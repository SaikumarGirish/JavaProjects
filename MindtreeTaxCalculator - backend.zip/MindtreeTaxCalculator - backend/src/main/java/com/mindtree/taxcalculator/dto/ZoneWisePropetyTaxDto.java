package com.mindtree.taxcalculator.dto;

import javax.validation.constraints.Null;

import lombok.Data;

@Data
public class ZoneWisePropetyTaxDto {
	
	@Null
	private ZoneDetail zoneDetails;

}
