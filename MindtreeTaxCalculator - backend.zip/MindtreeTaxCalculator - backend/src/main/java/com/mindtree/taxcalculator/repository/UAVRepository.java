package com.mindtree.taxcalculator.repository;


public interface UAVRepository{

	public Double findUavValue(Long zoneId,Long descId,String status);
}
