package com.mindtree.taxcalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindtreeTaxCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindtreeTaxCalculatorApplication.class, args);
	}

}
