package com.mindtree.taxcalculator.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "tax")
@EqualsAndHashCode(of = "id")
public class Tax {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "email", nullable = false)
	private String email;
	
	@Column(name = "address")
	private String address;

	@JoinColumn(name = "zone_id", nullable = false)
	@ManyToOne(cascade=CascadeType.MERGE)
	private Zone zone;

	@JoinColumn(name = "desc_id", nullable = false)
	@ManyToOne(cascade=CascadeType.MERGE)
	private Description description;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private BuildingOwnerStatus buildingOwnerStatus;

	@Column(name = "tax_paid")
	private Double taxPaid;
	
	@Column(name = "year_assessment")
	private Long yearOfAssessment;
	
	@Column(name = "build_construct_year")
	private Long buildConstructYear;
	
	@Column(name = "area")
	private Long area;
	

}
