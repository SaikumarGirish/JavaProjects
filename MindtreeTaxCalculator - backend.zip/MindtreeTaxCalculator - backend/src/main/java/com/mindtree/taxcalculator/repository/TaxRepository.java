package com.mindtree.taxcalculator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;
import com.mindtree.taxcalculator.model.Tax;
import com.mindtree.taxcalculator.model.Zone;

@Repository
public interface TaxRepository extends JpaRepository<Tax, Long>{
	 
	 @Query("select t from Tax t where t.yearOfAssessment = ?1 and t.zone = ?2 and t.buildingOwnerStatus = ?3")
	 public List<Tax> getTaxDetail(Long year,Zone zone, BuildingOwnerStatus buildingOwnerStatus);
	 
	 @Query("select distinct t.yearOfAssessment from Tax t order by t.yearOfAssessment asc")
	 public List<Long> getTaxYears();
	 	 
}
