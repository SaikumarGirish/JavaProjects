package com.mindtree.taxcalculator.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.taxcalculator.model.Description;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public interface DescriptionRepository extends JpaRepository<Description, Long>{

}
