package com.mindtree.taxcalculator.service;

import java.util.List;


import com.mindtree.taxcalculator.dto.TaxCalculationDto;
import com.mindtree.taxcalculator.dto.ZoneWisePropetyTaxDto;

public interface TaxService {

	public Double calculateTaxForUser(TaxCalculationDto taxCalculationDto);
	
	public List<ZoneWisePropetyTaxDto> getTaxZoneWise(Long year);
	
	public List<Long> getDistinctTaxYears();
	
}
