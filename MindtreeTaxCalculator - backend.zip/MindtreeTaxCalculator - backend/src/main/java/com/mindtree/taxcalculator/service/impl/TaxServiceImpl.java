package com.mindtree.taxcalculator.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.mindtree.taxcalculator.dto.OwnedBuildingDetail;
import com.mindtree.taxcalculator.dto.TaxCalculationDto;
import com.mindtree.taxcalculator.dto.TentatedBuildingDetail;
import com.mindtree.taxcalculator.dto.ZoneDetail;
import com.mindtree.taxcalculator.dto.ZoneWisePropetyTaxDto;
import com.mindtree.taxcalculator.enums.BuildingOwnerStatus;
import com.mindtree.taxcalculator.repository.TaxRepository;
import com.mindtree.taxcalculator.repository.UAVRepository;
import com.mindtree.taxcalculator.repository.ZoneRepository;
import com.mindtree.taxcalculator.service.TaxService;

@Service
public class TaxServiceImpl implements TaxService {
	
	private static final Logger logger = LoggerFactory.getLogger(TaxServiceImpl.class);

	@Autowired
	private UAVRepository uavRepository;

	@Autowired
	private ZoneRepository zoneRepository;

	@Autowired
	private TaxRepository taxRepository;

	private Double tentatedTaxPaid;

	private Double ownedTaxPaid;

	private List<ZoneWisePropetyTaxDto> zoneWisePropetyTaxesDto;

	private ZoneWisePropetyTaxDto zoneWisePropetyTaxDto;

	private ZoneDetail zoneDetail;

	private OwnedBuildingDetail ownedBuildingDetail;

	private TentatedBuildingDetail tentatedBuildingDetail;

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Double calculateTaxForUser(TaxCalculationDto taxCalculationDto) {
		
		
		Double uavValue = uavRepository.findUavValue(taxCalculationDto.getZoneId(), taxCalculationDto.getDescId(),
				taxCalculationDto.getStatus());
		
		logger.info("----------- UAV Value received -----------");

		return Math.round(
				0.248 * (((taxCalculationDto.getYearOfAssessment() - taxCalculationDto.getConstructedYear()) <= 60)
						? (0.6249 * taxCalculationDto.getBuiltArea() * uavValue)
						: (0.3332 * taxCalculationDto.getBuiltArea() * uavValue)) * 10000.0)
				/ 10000.0;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public List<ZoneWisePropetyTaxDto> getTaxZoneWise(Long year) {
		zoneWisePropetyTaxesDto = new ArrayList<>();
		zoneRepository.findAll().forEach(zone -> {
			tentatedTaxPaid = 0.0;
			taxRepository.getTaxDetail(year, zone, BuildingOwnerStatus.TENANTED).forEach(tentatedTax -> {
				tentatedTaxPaid += tentatedTax.getTaxPaid();
			});
			ownedTaxPaid = 0.0;
			taxRepository.getTaxDetail(year, zone, BuildingOwnerStatus.OWNER).forEach(ownedTax -> {
				ownedTaxPaid += ownedTax.getTaxPaid();
			});
			zoneWisePropetyTaxDto = new ZoneWisePropetyTaxDto();
			zoneDetail = new ZoneDetail();
			ownedBuildingDetail = new OwnedBuildingDetail();
			tentatedBuildingDetail = new TentatedBuildingDetail();
			tentatedBuildingDetail.setBuildingOwnerStatus(BuildingOwnerStatus.TENANTED);
			tentatedBuildingDetail.setCollectedTax(Math.round(tentatedTaxPaid * 10000.0) / 10000.0);
			ownedBuildingDetail.setBuildingOwnerStatus(BuildingOwnerStatus.OWNER);
			ownedBuildingDetail.setCollectedTax(Math.round(ownedTaxPaid * 10000.0) / 10000.0);
			zoneDetail.setZoneName(zone.getName());
			zoneDetail.setTentatedBuildingDetail(tentatedBuildingDetail);
			zoneDetail.setOwnedBuildingDetail(ownedBuildingDetail);
			zoneWisePropetyTaxDto.setZoneDetails(zoneDetail);
			zoneWisePropetyTaxesDto.add(zoneWisePropetyTaxDto);
		});
		return zoneWisePropetyTaxesDto;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public List<Long> getDistinctTaxYears() {
		logger.info("---------------- Distinct years received --------------------------");
		return taxRepository.getTaxYears();
	}

}
