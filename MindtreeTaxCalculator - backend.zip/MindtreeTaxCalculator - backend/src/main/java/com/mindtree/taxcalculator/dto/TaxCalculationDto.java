package com.mindtree.taxcalculator.dto;

import javax.validation.constraints.NotNull;

import lombok.Data;
@Data
public class TaxCalculationDto {

	@NotNull
	private Long yearOfAssessment;
	@NotNull
	private Long zoneId;
	@NotNull
	private Long descId;
	@NotNull
	private String status;
	@NotNull
	private Long constructedYear;
	@NotNull
	private Long builtArea;
}
