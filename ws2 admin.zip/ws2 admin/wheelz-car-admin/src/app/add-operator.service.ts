import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { UserService } from "./user.service";

@Injectable()
export class AddOperatorService {
  result;

  constructor(private service: UserService, private http: HttpClient) { }

  url = this.service.ROOT_URL;

  getOperator() {
    return this.http.get(this.url + '/getOperatorList');
  }

  insertData(operatorInfo) {
    console.log("service called");
    console.log(operatorInfo);
    return this.http.post(this.url + '/addNewOperator', operatorInfo);
  }

  getOperatorAnalytic() {
   return this.http.get(this.url + '/getOperatorAnalytic');
  }
}
