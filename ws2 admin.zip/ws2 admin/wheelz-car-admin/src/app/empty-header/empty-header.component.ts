import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empty-header',
  templateUrl: './empty-header.component.html',
  styleUrls: ['./empty-header.component.css']
})
export class EmptyHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
