import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material';
import { UserService } from '../user.service';
 


@Component({
  selector: 'app-removeuser',
  templateUrl: './removeuser.component.html',
  styleUrls: ['./removeuser.component.css']
})
export class RemoveuserComponent implements OnInit {
  len: any;
  res: any[];
check:boolean=false;
  constructor(private user:UserService) { }

  ngOnInit() {
this.user.getUser().subscribe(data => {
  data as any[];
  this.res=data;
    console.log(this.res);
 
 
});
  }
  displayedColumns = ['userid', 'email', 'gender', 'phone','button'];
  dataSource = new MatTableDataSource(this.res);
 
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
remove(element:any)
{

console.log(element);

 
}
}
const elem=this.res;