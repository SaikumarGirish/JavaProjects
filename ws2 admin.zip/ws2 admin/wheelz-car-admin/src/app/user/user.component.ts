import { Component, OnInit } from '@angular/core';
import { FeatureRoutingModule } from '../app-routing.module';
import { Router } from '@angular/router';
import { Chart } from 'chart.js';
import { UserService } from '../user.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  date1: any;
  
  res: any;
  message: boolean=false;
  day: any;
  date: any;
  booking: any;
  timeOfBooking=[];
  scheduleTime=[];
  chart = [];
  gsDayNames = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday'
  ];
  check:boolean=true;
  current=[0,0,0,0,0,0,0];
  schedule=[0,0,0,0,0,0,0];
  constructor(private router:Router,private user:UserService) { }
i:any;
  ngOnInit() {
  this.i=0
  this.user.getbooking()
  .subscribe(res => {
   
for(let i in res)
{
  this.timeOfBooking.push(res[i][0]);
  this.scheduleTime.push(res[i][1]);

}
 
for(let i=0;i<this.timeOfBooking.length;i++)
{
 this.date1  =(new Date(this.timeOfBooking[i])).toString();
 this.timeOfBooking[i]=this.date1;
 
}    
 
     this.check=false;
    for(let i=0;i<this.timeOfBooking.length;i++)
    {
      
      if(this.scheduleTime[i]==null)
      {
        this.date = new Date( this.timeOfBooking[i]); 
      this.day=this.gsDayNames[this.date.getDay()];
     
        if(this.day=='Sunday')
        {
         this.current[0]=Number(this.current[0])+Number(1);
     
        }
        if(this.day=='Monday')
        {
          this.current[1]=this.current[1]+Number(1);
        }
        if(this.day=='Tuesday')
        {
          this.current[2]=this.current[2]+Number(1);
        }
        if(this.day=='Wednesday')
        {
          this.current[3]=this.current[3]+Number(1);
          
        }
        if(this.day=='Thursday')
        {
          this.current[4]=this.current[4]+Number(1);
           
        }
        if(this.day=='Friday')
        {
          this.current[5]=this.current[5]+Number(1);
        }
        if(this.day=='Monday')
        {
          this.current[6]=this.current[6]+Number(1);
        }
      }
      else
      {
        this.date = new Date( this.scheduleTime[i]); 
      this.day=this.gsDayNames[this.date.getDay()];
      
        if(this.day=='Sunday')
        {
         this.schedule[0]=this.schedule[0]+Number(1);
        }
        if(this.day=='Monday')
        {
          this.schedule[1]=this.schedule[1]+Number(1);
        }
        if(this.day=='Tuesday')
        {
          this.schedule[2]=this.schedule[2]+Number(1);
        }
        if(this.day=='Wednesday')
        {
          this.schedule[3]=this.schedule[3]+Number(1);
        }
        if(this.day=='Thursday')
        {
          this.schedule[4]=this.schedule[4]+Number(1);
        }
        if(this.day=='Friday')
        {
          this.schedule[5]=this.schedule[5]+Number(1);
          
        }
        if(this.day=='Monday')
        {
          this.schedule[6]=this.schedule[6]+Number(1);
        }
      }

    }
    this.chart = new Chart('usercanvas', {
      type: 'bar',
     data: {
       labels:this. gsDayNames,
       datasets: [
         { 
           label:'Current booking',
            data: this.current,
            borderColor: "#3cba9f",
            backgroundColor:"#3cba9f",
            fill: false
          },
          { 
            label:'Schedule booking',
            data: this.schedule,
            borderColor: "#ffcc00",
            backgroundColor:"#ffcc00",
            fill: false
          },
        ]
     },
          options: {
            title: {
              display: true,
              text: 'User Booking Bar Chart'
            
          },
         legend: {
         display: true
       },
       scales: {
          xAxes: [{
            scaleLabel:{
              display:true,
              labelString:"Days",
              fontSize:20
            },
            display: true
         }],
          yAxes: [{
            scaleLabel:{
              display:true,
              labelString:"Number of Rides",
              fontSize:20
            },
            display: true,
            ticks: {
              min: 0,
              max: 100,
  
              // forces step size to be 5 units
              stepSize: 5
          }
          }],
         
       }
     }
    });
     
  }, err=>{
    this.message=true;
    this.check=false;
  })
 
   
 }
  }

