import { TestBed, inject } from '@angular/core/testing';

import { AddOperatorService } from './add-operator.service';

describe('AddOperatorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddOperatorService]
    });
  });

  it('should be created', inject([AddOperatorService], (service: AddOperatorService) => {
    expect(service).toBeTruthy();
  }));
});
