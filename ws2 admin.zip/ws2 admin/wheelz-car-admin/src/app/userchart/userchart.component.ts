import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userchart',
  templateUrl: './userchart.component.html',
  styleUrls: ['./userchart.component.css']
})
export class UserchartComponent implements OnInit {
  chart = []; 
  constructor(private user:UserService) { }

  ngOnInit() {
    this.user.getbooking()
    .subscribe(res => {
      console.log(res)
    })
    
  }

}
