import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public resultSet;
  public load = false;
  public checkingPassword;
  public checkingEmail;
  flag="no";
  adminId: any;
  adminName: any;
  rForm: FormGroup;
     email: '';
     password: '';
     // tslint:disable-next-line:no-inferrable-types
     emailAlert: string = 'Invalid Email Id';
     // tslint:disable-next-line:no-inferrable-types
     passwordAlert: string = 'Only 6 to 14 characters';

     public adminCredentials = {
        'email': '',
        'password': ''
     };

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router, private user: UserService) {
    this.rForm = fb.group({
      // tslint:disable-next-line:max-line-length
      'email': [null, Validators.compose([Validators.required, Validators.pattern('([a-zA-Z0-9_.]{1,})((@[a-zA-Z]{2,})[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))$')])],
      'password': [null, Validators.compose([Validators.required, Validators.maxLength(14), Validators.minLength(6)])],
});
   }

  ngOnInit() {
  }

login() {
    this.load = true;
    this.adminCredentials.email = this.checkingEmail;
    this.adminCredentials.password = this.checkingPassword;
    console.log(this.adminCredentials);
    this.http.post(this.user.ROOT_URL + '/adminLogin', this.adminCredentials)
    .subscribe(
      res => {

        this.load = false;
        if (res[0]) {
         this.flag = "yes";
          localStorage.setItem('flag',this.flag);
          this.router.navigate(['/dashboard']);
          this.adminId = res[0].administratorId;
          this.adminName = res[0].administratorName;
          console.log(this.adminName);
          localStorage.setItem('adminId', JSON.stringify(this.adminId));
          localStorage.setItem('adminName', this.adminName);
          localStorage.setItem('adminEmail', this.adminCredentials.email);
        } else {
          alert('Incorrect Email or Password');
        }

      },
      err => {
     this.load = false;
     alert('Connection problem..Please try again');
     console.log(this.load);
   }
    );

  }


}
