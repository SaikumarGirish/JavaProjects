import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { Chart } from 'chart.js';
import { UserService } from '../user.service';
@Component({
  selector: 'app-driver-analysis',
  templateUrl: './driver-analysis.component.html',
  styleUrls: ['./driver-analysis.component.css']
})
export class DriverAnalysisComponent implements OnInit {
 readonly ROOT_URL;
 flag = true;
 chart = [];
 piChart=[];
 count=[];
 name=[];
 cost =[];
  constructor(private http: HttpClient, public service: UserService) {
    this.ROOT_URL = this.service.ROOT_URL; 
   }

  ngOnInit() {
    this.getVal();
  }
 getVal(){
   this.http.get(this.ROOT_URL+"/driverChart").subscribe(res=>{

     this.flag = false;
for (let i in res){
  this.count.push(res[i][0]);
  this.name.push(res[i][1]);
  this.cost.push(res[i][2]);
}
this.chart = new Chart('canvas1', {
          type: 'line',
          data: {
            labels: this.name,
            datasets: [
              // { 
              //   data:this.cost,
              //   borderColor: "#3cba9f",
              //   fill: false
              // },
              { 
                data:this.count,
                borderColor: "#ffcc00",
                fill: true
              },
            ]
          },
          options: {
            title: {
            display: true,
            text: 'Driver efficency graph',
            fontSize:30
        },
            legend: {
              display: false
            },
            scales: {
              xAxes: [{
                 scaleLabel: {
                display: true,
                 labelString: 'Driver names--------->',
                  fontSize:19
                 }
              }],
              yAxes: [{
                 scaleLabel: {
                display: true,
                 labelString: 'Number of rides--------->',
                  fontSize:19
                 }
              }],
            }
          }
        });
        this.piChart = new Chart('canvas2', {
        type: 'pie',
        data: {
          labels: this.name,
          datasets: [
            {
              data: this.cost,
              backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'lightblue', '#b99ca5', 'black', 'skyblue','#9d9ca5','#ea9ca5','#ea9ce0','#fe783e','#ab783e','#68783e','#98783e','#c9783e','red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'lightblue', '#b99ca5', 'black', 'skyblue','#9d9ca5','#ea9ca5','#ea9ce0'],
              fill: false
            }
          ],
        },
        options: {
           title: {
            display: true,
            text: '---Driver earnings---',
            fontSize:30
        },
          legend: {
            display: true,
            position: 'left',
            labels: {
              usePointStyle: true
            }
          },
          responsive: true
        }
      });
    });  
  }
  
  
}
