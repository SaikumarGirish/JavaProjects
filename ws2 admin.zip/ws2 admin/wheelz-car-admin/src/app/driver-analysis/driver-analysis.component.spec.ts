import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverAnalysisComponent } from './driver-analysis.component';

describe('DriverAnalysisComponent', () => {
  let component: DriverAnalysisComponent;
  let fixture: ComponentFixture<DriverAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
