import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';
import { LoginComponent } from './login/login.component';
import { AddOperatorComponent } from './add-operator/add-operator.component';
import { RemoveOperatorComponent } from './remove-operator/remove-operator.component';
import { RemoveComponent } from './remove/remove.component';
import { DriverAnalysisComponent } from './driver-analysis/driver-analysis.component';
import { DashboardComponent } from "./dashboard/dashboard.component";
import { OperatorAnalyticsComponent } from "./operator-analytics/operator-analytics.component";
import { UserComponent } from './user/user.component';
import { AuthGuard } from './auth.guard';
const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'dashboard', component: DashboardComponent,canActivate:[AuthGuard] },
    {
        path: 'remove', component: RemoveOperatorComponent,canActivate:[AuthGuard]
    },
    {
        path:'operatorAnalytics',component:OperatorAnalyticsComponent,canActivate:[AuthGuard]
    },
    {
        path: 'removeuser', component: RemoveComponent,canActivate:[AuthGuard]
    },
    {
        path: 'driverStats', component: DriverAnalysisComponent,canActivate:[AuthGuard]
    },
    {
        path:'dashboard',component:DashboardComponent,canActivate:[AuthGuard]
    },
    {
        path:'user',component:UserComponent,canActivate:[AuthGuard]
    },
    { path: '**', component: PageNotFoundComponent },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})
export class FeatureRoutingModule { }
