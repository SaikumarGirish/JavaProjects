import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatTableDataSource, MatInputModule} from '@angular/material';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RemoveOperatorComponent } from './remove-operator/remove-operator.component';
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';
import { FeatureRoutingModule } from './app-routing.module';
import { AddOperatorComponent } from './add-operator/add-operator.component';
import { FooterComponent } from './footer/footer.component';
import { OperatorAnalyticsComponent } from './operator-analytics/operator-analytics.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddOperatorService } from './add-operator.service';
import { HttpClientModule } from "@angular/common/http";
import { EmptyHeaderComponent } from './empty-header/empty-header.component';
import { UserComponent } from './user/user.component';
import { RemoveuserComponent } from './removeuser/removeuser.component';
import {MatButtonModule} from '@angular/material/button';
import {MatTableModule} from '@angular/material/table';
import {MatFormFieldModule} from '@angular/material/form-field';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { DriverAnalysisComponent } from './driver-analysis/driver-analysis.component';
import { UserService } from './user.service';
import { RemoveComponent } from './remove/remove.component';
import { UserchartComponent } from './userchart/userchart.component';
import { UserheaderComponent } from './userheader/userheader.component';
import { AuthGuard } from './auth.guard';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    DashboardComponent,
    RemoveOperatorComponent,
    PageNotFoundComponent,
    AddOperatorComponent,
    FooterComponent,
    OperatorAnalyticsComponent,
    EmptyHeaderComponent,
    DriverAnalysisComponent,
    UserComponent,
    RemoveuserComponent,
    RemoveComponent,
    UserchartComponent,
    UserheaderComponent,
     
  ],
  imports: [
    BrowserModule, FeatureRoutingModule, FormsModule,
    ReactiveFormsModule ,HttpClientModule,MatFormFieldModule,MatTableModule, MatInputModule,BrowserAnimationsModule
  ],
  providers: [
    AddOperatorService,
    BrowserModule, FeatureRoutingModule, FormsModule, HttpClientModule,
    ReactiveFormsModule, MatButtonModule, MatTableModule, MatFormFieldModule, MatInputModule, BrowserAnimationsModule,UserService,AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
