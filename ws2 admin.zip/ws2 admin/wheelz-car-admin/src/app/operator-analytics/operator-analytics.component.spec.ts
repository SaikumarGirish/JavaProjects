import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorAnalyticsComponent } from './operator-analytics.component';

describe('OperatorAnalyticsComponent', () => {
  let component: OperatorAnalyticsComponent;
  let fixture: ComponentFixture<OperatorAnalyticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OperatorAnalyticsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OperatorAnalyticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
