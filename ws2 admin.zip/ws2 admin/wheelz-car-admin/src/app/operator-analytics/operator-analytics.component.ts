import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { AddOperatorService } from "../add-operator.service";
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-operator-analytics',
  templateUrl: './operator-analytics.component.html',
  styleUrls: ['./operator-analytics.component.css']
})
export class OperatorAnalyticsComponent implements OnInit {
  name = [];
  count = [];
  chart = [];

  constructor(private service: AddOperatorService) { }

  ngOnInit() {
    this.getOperatorAnalytic();
  }

  getOperatorAnalytic() {

    this.service.getOperatorAnalytic().subscribe(res => {
      for (let i in res) {
        this.name.push(res[i][0]);
        this.count.push(res[i][1]);
      }

      this.chart = new Chart('canvas', {
        type: 'pie',
        data: {
          labels: this.name,
          datasets: [
            {
              data: this.count,
              backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', '#dddce3', '#f77016', '#dddce3', 'black', 'skyblue'],
              fill: false
            }
          ],
        },
        options: {
          legend: {
            display: true,
            position: 'left',
            labels: {
              usePointStyle: true
            }
          },
          responsive: true
        }
      });
    });
  }
}
