import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { RemoveOperatorComponent } from './remove-operator.component';
import { UserService } from '../user.service';
import { HeaderComponent } from '../header/header.component';
import { RouterTestingModule } from '@angular/router/testing';
fdescribe('RemoveOperatorComponent', () => {
  let component: RemoveOperatorComponent;
  let fixture: ComponentFixture<RemoveOperatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveOperatorComponent, HeaderComponent 
      ],
      imports:[RouterTestingModule],
      providers:[UserService,HttpClient]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveOperatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
