import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../user.service';
@Component({
  selector: 'app-remove-operator',
  templateUrl: './remove-operator.component.html',
  styleUrls: ['./remove-operator.component.css']
})
export class RemoveOperatorComponent implements OnInit {
 member: any;
 found:boolean = true;
 id:number;
 flag:boolean =false; 
  constructor(private http: HttpClient,private user:UserService) {  }
readonly ROOT_URL=this.user.ROOT_URL;
  ngOnInit() {
    this.getOperators();
  }
  set(val) {
    this.id = val;
  }
  getOperators(){
    this.http.get(this.ROOT_URL+'/allOperators')
    .subscribe(
      (data: any[]) => {

        if (data.length !== 0) {
          this.member = data;
          this.flag = false;
        }
      }
    );
  }
  Delete() {
    this.flag = true;
      this.http.get(this.ROOT_URL + `/deleteOperator/${this.id}`).subscribe(data=>{
        this.getOperators();
      });
  }
  

}
