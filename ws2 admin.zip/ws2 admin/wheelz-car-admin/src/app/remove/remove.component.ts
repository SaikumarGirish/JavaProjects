import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-remove',
  templateUrl: './remove.component.html',
  styleUrls: ['./remove.component.css']
})
export class RemoveComponent implements OnInit {
  message: boolean=false;
  len: number;
  newresult: any;
  flag: boolean=true;
  userdetails:any[];
  id: any;
  res: any;
 inc:number=0;
  constructor(private user:UserService,private http:HttpClient) { }

  ngOnInit() {
    this.user.getUser().subscribe(data => {
      this.len=data.length;
      if(data.length!==0)
      {
        this.userdetails=data;
        this.flag=false;
        this.newresult=data;
      
      }

      for(let k=0;k<data.length;k++)
      {
        if(this.userdetails[k].userDeleteStatus==1)
        {
            this.len=Number(this.len)-Number(1);
             
        }
      }

       
  },
err =>{
  
 this.flag=false;
 this.message=true;
}
);


}
Delete(val) {
  this.id = val;
  this.flag = true;
    this.http.get(this.user.ROOT_URL + `/removeUser/${this.id}`).subscribe(data=>{
   
      this.ngOnInit();
    });
}

 
applyFilter(filterValue: any) {
  if(filterValue=="")
  {
    this.userdetails=this.newresult;
  }
  filterValue = filterValue.trim(); // Remove whitespace
    // MatTableDataSource defaults to lowercase matches
 
for(let i=0;i<this.newresult.length;i++)
{
  if(filterValue==this.newresult[i].userId||filterValue==this.newresult[i].userName)
  {
    
this.userdetails=new Array();
this.userdetails.push(this.newresult[i]);
 

  }
  
}
}

}
