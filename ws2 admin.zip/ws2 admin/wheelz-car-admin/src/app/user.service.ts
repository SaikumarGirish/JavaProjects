import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
 
import { HttpClient } from '@angular/common/http';
@Injectable()
export class UserService {

  // readonly ROOT_URL ='http://localhost:8083/WheelzCarRental';
  readonly ROOT_URL ='https://wheelzcarrentalserver.azurewebsites.net/WheelzCarRental';
  constructor(private http:HttpClient) { }

  public getUser(): Observable<any> {
    return this.http.get( this.ROOT_URL+'/allUsers');

}
public getbooking():Observable<any>{
  return this.http.get(this.ROOT_URL+'/chartdata');
}
}
