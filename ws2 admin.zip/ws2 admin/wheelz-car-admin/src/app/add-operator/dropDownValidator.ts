import { AbstractControl } from '@angular/forms';
export function validateDropDown(control: AbstractControl) {
    console.log('hioi');
    if (control.value == 0) {
        return {
            defaultValue: true
        }
    }
}
