import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from '@angular/forms';
import { AddOperatorService } from '../add-operator.service';
import { validateDropDown } from "./dropDownValidator";
@Component({
  selector: 'app-add-operator',
  templateUrl: './add-operator.component.html',
  styleUrls: ['./add-operator.component.css']
})
export class AddOperatorComponent implements OnInit {


  ngOnInit() {
    this.getData();
  }


  load: boolean;
  rForm: FormGroup;
  public driverDetail;
  public operatorAdded = false;
  public emailDup = 0;
  //for validation
  name: string = '';
  age: number;
  gender: number;
  email: string;
  phone: string = '';
  password: string = '';
  confirm: string = '';
  
  nameAlert: string = 'Enter a name of less than 35 characters';
  ageAlert: string = 'Enter a valid age';
  genderAlert: string = 'Gender field is mandatory';
  emailAlert: string = 'email should be valid';
  phoneAlert: string = 'valid phone is requied';
  passwordAlert: string = 'password should be atleast 6 digit and atmost 14';
  confirmAlert: string = 'should be equal as password';

  public operator;
  public checkingName = '';
  public checkingGender;
  public checkingEmail;
  public checkingPhone;
  public checkingPassword;
  public confirmPassword;
  public operatorInfo = {
    'operatorName': '',
    'email': '',
    'gender': 0,
    'phoneNumber': '',
    'password': ''
  };
  constructor(private fb: FormBuilder, private service: AddOperatorService) {
    this.load = false;
    this.rForm = fb.group({
      'name': [null, Validators.compose([Validators.required, Validators.pattern('[a-zA-Z]{1}[A-Za-z\\s]{1,34}')])],
      'gender': [validateDropDown],
      'email': [null, Validators.compose([Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern('[7 8 9][0-9]{9}$')])],
      'password': [null, Validators.compose([Validators.required, Validators.maxLength(14), Validators.minLength(6)])],
      'confirm': [null, Validators.compose([Validators.required])]
    });
  }

  // checking existing email
  checkEmail() {
    for (const driver of this.driverDetail) {
      if (driver.email == this.checkingEmail) {
        console.log(this.rForm.controls['name']);
        // this.emailDup =1;
        alert('email already exists');
      }
    }
  }

  checkPhone() {
    for (let driver of this.driverDetail) {
      if (driver.phoneNumber == this.checkingPhone) {
        console.log('checkPhone called');
        // this.emailDup =1;
        alert('phone number already exists');


      }
    }
  }


  //storing driver details for validation
  getData(): void {
    this.service.getOperator().subscribe((data) => {
      this.driverDetail = data;
      console.log(this.driverDetail);
    });
  }
  
  passwordcheck() {
    if (((document.getElementById('password') as HTMLInputElement).value) ===
      ((document.getElementById('confirm') as HTMLInputElement).value)) {

    } else {
      this.confirmPassword = '';
    }
  }

  register() {
    console.log('registered called');
    this.load = true;
    var self=this;
    this.operatorInfo.operatorName = this.checkingName;
    this.operatorInfo.email = this.checkingEmail;
    this.operatorInfo.gender = this.checkingGender;
    this.operatorInfo.phoneNumber = this.checkingPhone;
    this.operatorInfo.password = this.checkingPassword;
      this.service.insertData(this.operatorInfo).subscribe((data2) => {
        self.load = false;
        this.operatorAdded = true;
        this.operator = data2;
        console.log(this.operator);
      },
        err => {
          self.load = false;
          console.log(this.load);
          alert('connection problem..Please try again');
          console.log(this.load);

        });
  }
}
