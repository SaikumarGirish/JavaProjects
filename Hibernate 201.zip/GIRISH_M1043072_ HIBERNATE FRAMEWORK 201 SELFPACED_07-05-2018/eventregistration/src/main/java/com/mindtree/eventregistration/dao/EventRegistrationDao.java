package com.mindtree.eventregistration.dao;

import java.util.List;

import com.mindtree.eventregistration.entity.Employees;
import com.mindtree.eventregistration.entity.Events;
import com.mindtree.eventregistration.exception.EventRegistrationServiceException;
import com.mindtree.eventregistration.exception.NoDataFoundException;

public interface EventRegistrationDao {

	public List<Employees> getEmployeeData() throws NoDataFoundException;

	public List<Events> getEventData() throws NoDataFoundException;

	public boolean getSavedResult(Employees employee) throws EventRegistrationServiceException;

}
