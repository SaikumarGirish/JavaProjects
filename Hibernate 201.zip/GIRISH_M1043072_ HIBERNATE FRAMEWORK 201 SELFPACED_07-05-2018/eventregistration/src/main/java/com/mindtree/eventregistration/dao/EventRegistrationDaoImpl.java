package com.mindtree.eventregistration.dao;

import java.sql.SQLDataException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mindtree.eventregistration.EventRegistrationMenu;
import com.mindtree.eventregistration.entity.Employees;
import com.mindtree.eventregistration.entity.Events;
import com.mindtree.eventregistration.exception.EventRegistrationServiceException;
import com.mindtree.eventregistration.exception.NoDataFoundException;

public class EventRegistrationDaoImpl implements EventRegistrationDao {

	SessionFactory s = new Configuration().configure().buildSessionFactory();
	Logger logger = Logger.getLogger(EventRegistrationMenu.class.getName());

	public List<Employees> getEmployeeData() throws NoDataFoundException {
		List<Employees> list = null;
		Session session = s.openSession();
		try {
			session.beginTransaction();
			logger.info("Excecuting SQL query");
			Query que = session.createQuery("from Employees");
			list = (List<Employees>) que.list();
		} catch (Exception e) {
			throw new NoDataFoundException();
		}
		return list;
	}

	public List<Events> getEventData() throws NoDataFoundException {
		List<Events> list = null;
		Session session = s.openSession();
		try {
			session.beginTransaction();
			logger.info("Excecuting SQL query");
			Query que = session.createQuery("from Events");
			list = (List<Events>) que.list();
		} catch (Exception e) {
			throw new NoDataFoundException();
		}
		return list;
	}

	public boolean getSavedResult(Employees employee) throws EventRegistrationServiceException {
		logger.info("Starting Transaction");
		Transaction transaction = null;
		logger.info("Opening Session");
		Session session = s.openSession();
		try {
			logger.info("Beginning Transaction");
			transaction = session.beginTransaction();
			logger.info("Saving the Employee Object");
			session.save(employee);
			transaction.commit();
		} catch (HibernateException e) {
			throw new EventRegistrationServiceException();
		} finally {
			session.close();
		}
		return true;
	}

}
