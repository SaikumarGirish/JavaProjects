package com.mindtree.eventregistration.service;

import java.util.List;
import java.util.logging.Logger;

import com.mindtree.eventregistration.EventRegistrationMenu;
import com.mindtree.eventregistration.dao.EventRegistrationDao;
import com.mindtree.eventregistration.dao.EventRegistrationDaoImpl;
import com.mindtree.eventregistration.entity.Employees;
import com.mindtree.eventregistration.entity.Events;
import com.mindtree.eventregistration.exception.EventRegistrationServiceException;
import com.mindtree.eventregistration.exception.NoDataFoundException;

public class EventRegistrationServiceImpl implements EventRegistrationService {

	Logger logger = Logger.getLogger(EventRegistrationMenu.class.getName());
	EventRegistrationDao eventRegistrationDao = new EventRegistrationDaoImpl();

	public List<Employees> getAllEmployees() throws NoDataFoundException {
		logger.info("Transferring function call to Dao layer");
		List<Employees> employeeList = eventRegistrationDao.getEmployeeData();
		return employeeList;
	}

	public List<Events> getAllEvents() throws NoDataFoundException {
		logger.info("Transferring function call to Dao layer");
		List<Events> eventList = eventRegistrationDao.getEventData();
		return eventList;
	}

	public boolean saveEmployee(Employees employee) throws EventRegistrationServiceException {
		logger.info("Transferring function call to Dao layer");
		boolean result = eventRegistrationDao.getSavedResult(employee);
		return result;
	}
}
