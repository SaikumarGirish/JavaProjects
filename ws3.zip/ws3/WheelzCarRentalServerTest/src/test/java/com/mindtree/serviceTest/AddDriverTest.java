package com.mindtree.serviceTest;


import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;
import com.mindtree.service.AddNewDriverService;
import com.mindtree.service.impl.AddNewDriverServiceImpl;
public class AddDriverTest {
	@Autowired
	AddNewDriverService addNewDriverServiceImpl;
	Driver driver;
	AddNewDriverDto addDriver;
		@Before
		public void init(){
		 driver = new Driver();
		 driver.setDriverId(1);
		 addDriver = new AddNewDriverDto();
		 addDriver.setAge(30);
		 addDriver.setCarNumber("AP33N0000");
		 addDriver.setAddress("narnia");
		 addDriver.setDriverDeleteStatus(0);
		 addDriver.setDriverName("anush");
		 addDriver.setDriverRidingStatus(0);
		 addDriver.setEmail("anush@gmail.com");
		 addDriver.setGender(0);
		 addDriver.setLicenceNumber("DL-0420140140000");
		 addDriver.setModelType(0);
		 addDriver.setPassword("anush12345");
		 addDriver.setPhoneNumber("9988776655");
		 addDriver.setAdministratorId(1);
		 addDriver.setDateOfRegistration("01/01/2018 10:00:00");
		}
	 
		@Test
		public void getDriverServiceTest() {
			List<Driver> driverList =	addNewDriverServiceImpl.getDriverService();
			assertEquals("got driver list",1,driverList.get(0).getDriverId());
		}
		
//		@Test
//		public void addNewDriverServiceTest() {
//			List<Driver> driverList =	addNewDriverServiceImpl.addNewDriverService(addDriver);
//			assertEquals("driver added",1,driverList.get(0).getDriverId());
//		}
		
		
		
		
		
}
