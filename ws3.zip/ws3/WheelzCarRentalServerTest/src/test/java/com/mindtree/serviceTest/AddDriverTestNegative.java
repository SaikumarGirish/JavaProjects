//package com.mindtree.serviceTest;
//
//import static org.junit.Assert.assertEquals;
//
//import java.util.List;
//
//import org.junit.Before;
//import org.junit.Test;
//
//import com.mindtree.entity.Driver;
//import com.mindtree.service.impl.AddNewDriverServiceImpl;
//
//public class AddDriverTestNegative {
//	AddNewDriverServiceImpl addNewDriverServiceImpl;
//	Driver driver;
//	public AddDriverTestNegative() {
//	}
//			
//		@Before
//		public void init(){
//			addNewDriverServiceImpl = new AddNewDriverServiceImpl();
//			 driver = new Driver();
//			 driver.setDriverId(1000);			
//		}
//		@Test
//		public void getDriverServiceTest() {
//			List<Driver> driverList =	addNewDriverServiceImpl.getDriverService();
//			assertEquals("driver id is not present",0,driverList.size());
//	}
//
//}
