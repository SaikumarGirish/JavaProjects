

package com.mindtree.serviceTest;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import com.mindtree.dto.BookingData;
import com.mindtree.dto.OperatorBookingData;
import com.mindtree.dto.PostBookingData;
import com.mindtree.service.impl.CalculateCostImpl;

public class CalculateCostTest {
	CalculateCostImpl calculateCost = new CalculateCostImpl();
	@Test
	public void calculateCostTest() {
		BookingData bookingData = new BookingData();
		bookingData.setCarType(1);
		bookingData.setDropLocation(2);
		bookingData.setPickUpLocation(1);
		bookingData.setEmail("surajdoddangadi@gmail.com");
		bookingData.setTimeStamp(new Date());
		PostBookingData postBookingData = calculateCost.calculateCost(bookingData);
		assertEquals(2, postBookingData.getDistance());
		assertEquals(50, postBookingData.getCost());
	}

	@Test
	public void operatorCalculateCostTest() {
     OperatorBookingData operatorBookingData = new OperatorBookingData();
     operatorBookingData.setUserName("suraj");
     operatorBookingData.setEmail("surajdoddangadi@gmail.com");
     operatorBookingData.setPhoneNumber("8892443074");
     operatorBookingData.setCarType(0);
     operatorBookingData.setDriverId(9);
     operatorBookingData.setDropLocation(2);
     operatorBookingData.setPickUpLocation(1);
     operatorBookingData.setOperatorId(1);
     operatorBookingData.setTimeI(new Date());
     PostBookingData postBookingData = calculateCost.operatorCalculateCost(operatorBookingData);
     assertEquals(2, postBookingData.getDistance());
     assertEquals(40, postBookingData.getCost());
	}

}

