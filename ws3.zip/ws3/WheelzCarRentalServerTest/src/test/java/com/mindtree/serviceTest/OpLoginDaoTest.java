package com.mindtree.serviceTest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.dao.impl.LoginImpl;
import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.OperatorNotFoundException;

public class OpLoginDaoTest {

	private LoginImpl loginImpl;
	private Administrator admin;
	@Before
	public void init() {
		loginImpl = new LoginImpl();
	}

	@Test
	public void testOperatorLoginPositive() throws OperatorNotFoundException {
		admin = new Administrator();
		admin.setEmail("mukesh.yadav@gmail.com");
		admin.setPassword("iamsuperstar");
		List<Administrator> list  = loginImpl.operatorLogin(admin);
		assertEquals("Login Success",1,list.get(0).getAdministratorId());
	}
	@Test
	public void testOperatorLoginNegative() throws OperatorNotFoundException {
			admin = new Administrator();
			admin.setEmail("mukesh.yadav@gmail.com");
			admin.setPassword("iamsuperstar23");
			List<Administrator> result = loginImpl.operatorLogin(admin);
			assertEquals("Login Fail",0,result.size());
	}
}
