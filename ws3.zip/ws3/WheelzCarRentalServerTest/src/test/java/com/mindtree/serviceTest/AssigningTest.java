/*package com.mindtree.serviceTest;

public class AssigningTest {
	
	

}*/
