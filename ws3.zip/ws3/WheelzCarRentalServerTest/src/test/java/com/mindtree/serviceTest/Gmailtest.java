//package com.mindtree.serviceTest;
//
//import static org.junit.Assert.*;
//
//
//import org.junit.Test;
// 
//
//import com.mindtree.dto.Gmaildata;
//import com.mindtree.service.LoginService;
//import com.mindtree.service.impl.LoginServiceImpl;
//
//
//public class Gmailtest {
//	LoginService loginService=new LoginServiceImpl();
//	Gmaildata data=new Gmaildata();
//	Gmaildata data1=new Gmaildata();
//	@Test
//	public void test() {
//		
//		 data.setEmail("vidyachowdary880@gmail.com");
//			  
//		boolean b=loginService.checkUser(data);
//		 
//		assertEquals(false,b);
//		
//	}
//	@Test
//	public void test1(){
//		data1.setEmail( "arjun@gmail.com");
//		boolean c=loginService.checkUser(data);
//		assertEquals(,c);
//	}
//
//}
