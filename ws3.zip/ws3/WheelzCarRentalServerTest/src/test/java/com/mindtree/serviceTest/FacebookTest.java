//package com.mindtree.serviceTest;
//
//import static org.junit.Assert.assertEquals;
//
//import org.junit.Test;
//
//import com.mindtree.dto.FaceBook;
//import com.mindtree.service.FacebookLoginService;
//import com.mindtree.service.impl.FacebookLoginServiceImpl;
//
//public class FacebookTest {
//
//	FacebookLoginService fbtest = new FacebookLoginServiceImpl();
//
//	@Test
//	public void boundaryFbCheck() {
//		FaceBook fb = new FaceBook();
//		fb.setEmail("mamesh.mohan@gmail.com");
//		fb.setGender("male");
//		fb.setName("Mamesh Mohan");
//		assertEquals(true, fbtest.facebookCheck(fb));
//	}
//
//	@Test
//	public void negativeFbCheck() {
//		FaceBook fb = new FaceBook();
//		fb.setEmail("mamesh@gmail.com");
//		fb.setGender("male");
//		fb.setName("Mamesh Mohan");
//		assertEquals(false, fbtest.facebookCheck(fb));
//	}
//
//	@Test
//	public void addUser() {
//		FaceBook fb = new FaceBook();
//		fb.setEmail("radha@gmail.com");
//		fb.setGender("female");
//		fb.setName("Radha");
//		assertEquals(true, fbtest.addFBUser(fb));
//	}
//
//}
