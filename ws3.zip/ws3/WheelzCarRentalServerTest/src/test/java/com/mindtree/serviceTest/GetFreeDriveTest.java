
//package com.mindtree.serviceTest;
//
//
//import static  org.junit.Assert.*;
//import java.util.List;
//
//
//import org.junit.Test;
//
//import com.mindtree.entity.Driver;
//import com.mindtree.service.impl.GetFreeDriverServiceImpl;
//
//
//
//public class GetFreeDriveTest {
//	
//	GetFreeDriverServiceImpl driverServImpl=new GetFreeDriverServiceImpl();
//	
//	@Test
//	public void testGetBookigs() {
//		
//		List<Driver> drivers = (List<Driver>) driverServImpl.getFreeDrivers();
//		assertEquals(10,drivers.get(0).getDriverId());	
//	}
//	
//	
//
//}
