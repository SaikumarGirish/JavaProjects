//package com.mindtree.serviceTest;
//
//import static org.junit.Assert.*;
//
//import org.junit.Before;
//import org.junit.Test;
//
//import com.mindtree.service.impl.GetEmailServiceImpl;
// 
//
//public class GetAllEmailServiceTest {
//
//
//	 GetEmailServiceImpl getEmailService;
//	 @Before
//	 public void init()
//	 {
//		 getEmailService=new GetEmailServiceImpl();
//	 }
//	 @Test
//	 public void getAllPhone()
//	 {
//		 assertEquals("mohan@gmail.com",getEmailService.getEmail().get(0));
//	 }
//
//}
