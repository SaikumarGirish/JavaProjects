package com.mindtree.serviceTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.mindtree.service.impl.GetPhoneSErviceImpl;

public class GetAllPhoneServiceTest {

	 GetPhoneSErviceImpl getPhoneService;
	 @Before
	 public void init()
	 {
		 getPhoneService=new GetPhoneSErviceImpl();
	 }
	 @Test
	 public void getAllPhone()
	 {
		 assertEquals("8050774633",getPhoneService.getPhone().get(0));
	 }

}
