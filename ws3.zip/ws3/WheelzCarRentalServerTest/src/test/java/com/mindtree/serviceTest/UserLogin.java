package com.mindtree.serviceTest;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import com.mindtree.service.impl.LoginServiceImpl;

import com.mindtree.entity.User;

import com.mindtree.exceptions.UserNotFoundException;


public class UserLogin {
	private  LoginServiceImpl loginServImpl;
	private User user;
	
	
	@Before
	public  void init()
	{
		loginServImpl=new LoginServiceImpl();
	
	}
	
	
	@Test
	public void loginTestPositive() throws UserNotFoundException
	{
		user = new User();
		user.setEmail("mohan@gmail.com");
		user.setPassword("mohan123");	
		User u =loginServImpl.setUser(user);
		assertEquals("Success",user.getPassword(),u.getPassword());
	}
	
	@Test
	public void loginTestNegative() throws UserNotFoundException
	{
		user = new User();
	    user.setEmail("mohan234@gmail.com");
		user.setPassword("mohan1234567768");	
		User u =loginServImpl.setUser(user);
		try{
		assertEquals("Success",null,u.getPassword());
		assertTrue("Exception Was Thrown", true);
		}
		catch(NullPointerException e)
		{
			assertTrue(true);
		}
				
	}
	

}
