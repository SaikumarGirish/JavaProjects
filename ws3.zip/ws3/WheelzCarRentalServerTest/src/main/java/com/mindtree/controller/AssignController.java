package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.mindtree.dao.impl.SendMailDaoImpl;
import com.mindtree.dto.AssignDriver;
import com.mindtree.service.AssignService;
import com.mindtree.service.MailService;
//import com.mindtree.service.impl.SendMailImpl;

@RestController
public class AssignController
{
	@Autowired
	AssignService as;
	
	@Autowired
	MailService mailService;
	
	@RequestMapping(value = "/assign", method = RequestMethod.POST)
	public boolean getdata(@RequestBody AssignDriver details) 
	{
		
		
		// SendMailImpl sendMail = new SendMailImpl();
		 as.get(details);
		 // SendMailDaoImpl sendMailDaoImpl = new SendMailDaoImpl();
		// return sendMail.sendEmail(sendMailDaoImpl.getDetails(details));
		 mailService.mailToUser(details);
		 mailService.mailToDriver(details);
		 return true;

	}
	}
