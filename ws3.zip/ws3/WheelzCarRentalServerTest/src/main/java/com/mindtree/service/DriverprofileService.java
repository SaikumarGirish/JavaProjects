package com.mindtree.service;

import com.mindtree.entity.Driver;

public interface DriverprofileService {

	public Driver driverDetail(int id);
	public boolean setDriver(Driver driver);
	
}
