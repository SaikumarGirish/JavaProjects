package com.mindtree.service;

import java.text.ParseException;
import java.util.List;

import com.mindtree.dto.Userchart;
import com.mindtree.entity.Booking;

public interface GetBookingsService {

	List<Booking> getBookings();

	List<Booking> getPastTrip(int dId);

	long getCost(int dId) throws ParseException;

	List<Booking> getBooking();

	List<Userchart> getchart();
}
