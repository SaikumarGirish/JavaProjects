package com.mindtree.controller;


import java.text.ParseException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.Userchart;
import com.mindtree.entity.Booking;
import com.mindtree.service.GetBookingsService;

@RestController
public class GetBookingsController {

	@Autowired
	GetBookingsService serve;
	/*
	 * This method is used to get all the new bookings done by the user and
	 * sending to the operator to assign the driver for the booking
	 */

	@RequestMapping(value = "/getbookings", method = RequestMethod.GET)
	public List<Booking> getdata() {
		return serve.getBookings();
	}
	
	/*
	 * This method is used to get all the bookings done by the user 
	 *
	 */
	

	@RequestMapping(value = "/allbookings", method = RequestMethod.GET)
	public List<Booking> alldata() {
		return serve.getBooking();
	}
	 
	@RequestMapping(value = "/chartdata", method = RequestMethod.GET)
	public List<Userchart> chart(){
		return serve.getchart();
	}
	
	/*
	 * This method is used to get all the bookings done by the driver and
	 * sending to driver to view 
	 */
	@RequestMapping(value = "/pastRide/{id}")
	@ResponseBody
	public List<Booking> pastride(@PathVariable("id") int dId) {
		System.out.println(dId);
		return serve.getPastTrip(dId);
	}
	


	
	/*
	 * This method is used to get the earnings done by the user and
	 * sending to the driver 
	 */
	
		@RequestMapping(value = "/earnings/{id}")
		@ResponseBody
		public long getcosts(@PathVariable("id") int dId) throws ParseException {
			System.out.println(dId);
			
			return serve.getCost(dId);
	
		}

	
	
	

}
