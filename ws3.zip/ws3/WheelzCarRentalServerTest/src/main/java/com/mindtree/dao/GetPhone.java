package com.mindtree.dao;

 
import java.util.List;

public interface GetPhone {
	public List getPhone();
}
