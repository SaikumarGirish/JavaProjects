package com.mindtree.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.MailDao;
import com.mindtree.dto.AssignDriver;
import com.mindtree.dto.PostBookingData;
import com.mindtree.service.MailService;

@Service
@Transactional
public class MailServiceImpl implements MailService {

	@Autowired
	private MailDao mailDao;
	
	@Transactional
	public boolean mailToUser(AssignDriver details) {
		mailDao.mailToUser(details);
		return true;
	}

	@Transactional
	public boolean mailToDriver(AssignDriver details) {
		mailDao.mailToDriver(details);
		return true;
	}

	@Override
	public boolean mailToUser(PostBookingData details) {
		mailDao.mailToUser(details);
		return true;
	}

	@Override
	public boolean mailToDriver(PostBookingData details) {
		mailDao.mailToDriver(details);
		return true;
	}

}
