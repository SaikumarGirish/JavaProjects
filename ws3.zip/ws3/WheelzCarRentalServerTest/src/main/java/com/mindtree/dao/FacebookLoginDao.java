package com.mindtree.dao;

import com.mindtree.entity.User;

public interface FacebookLoginDao {
	public User facebookCheck(User user);
	public User addFBUser(User user);
}
