package com.mindtree.dao.impl;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddCredential;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.entity.User;
@Repository
public class AddCredentialsImpl implements AddCredential {

	@Autowired
	 private SessionFactory sessionFactory;

	public boolean addOperator(Administrator operator) {
		sessionFactory.getCurrentSession().saveOrUpdate(operator);
		return true;
	}

	public boolean addDriver(Driver driver) {
		sessionFactory.getCurrentSession().saveOrUpdate(driver);
		return true;
	}

	public User addUser(User user) {	 
		sessionFactory.getCurrentSession().saveOrUpdate(user);
			return user;
		}
	

	public boolean addLocation(Locations location) {
		sessionFactory.getCurrentSession().saveOrUpdate(location);
		return true;
	}

	@Override  /*checking whether email is in database or not if it is not there store data 
	in database else return false*/ 
	@SuppressWarnings("unchecked")
	public User checkUser(User gmailuser) {
		 		try{
			 
			 
         org.hibernate.Query query = sessionFactory.getCurrentSession().createQuery( "from User u where u.email=:Email ");
			   query.setString("Email", gmailuser.getEmail());
		  ArrayList<User> list = (ArrayList<User>)query.list();
				Long count = (Long)query.uniqueResult();
            			 
			if(list.isEmpty()) 
			{
				
				sessionFactory.getCurrentSession().save(gmailuser);
					 
 					 
				Query query1 =  sessionFactory.getCurrentSession().createQuery("from User order by userId DESC");
				query1.setMaxResults(1);
				User user = (User) query1.uniqueResult();
 					 
			 return user;
			}
			else{
								 
				 User user = list.get(0);
				 
				  
				return user;
				}
			 
		}
		catch(Exception e){ 
				 
				}
		return gmailuser;
		
		 
		
	}

}
