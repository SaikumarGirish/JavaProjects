package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.dto.BookingData;
import com.mindtree.dto.OperatorBookingData;
import com.mindtree.dto.PostBookingData;
import com.mindtree.service.CalculateCost;
import com.mindtree.service.MailService;

@RestController
public class BookingController {
	@Autowired
	CalculateCost calculateCost;
	
	@Autowired
	private MailService mailService;
	/*This method used to add booking data in database after user books a cab, 
	 the information is sent to booking table*/
	@RequestMapping(value = "/addBooking", method = RequestMethod.POST)
	public PostBookingData addBookingDetails(@RequestBody BookingData bookingData) {
		System.out.println(bookingData.getBookingStatus());
		return calculateCost.calculateCost(bookingData);
		
	}
	/*This method is used to add booking data in database after operator books a cab and
	  the data will be stored into booking table*/
	@RequestMapping(value = "/operatorbooking", method = RequestMethod.POST)
	public PostBookingData operatorBooking(@RequestBody OperatorBookingData operatorBookingData){
		PostBookingData postBookingData = calculateCost.operatorCalculateCost(operatorBookingData);
		mailService.mailToUser(postBookingData);
		mailService.mailToDriver(postBookingData);
		return postBookingData;
	}
	
}
