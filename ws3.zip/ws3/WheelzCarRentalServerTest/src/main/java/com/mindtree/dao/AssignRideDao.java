package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Booking;

public interface AssignRideDao {
public List<Booking> assignRide(int id);
public boolean startRide(int id);
public boolean endRide(int id);
public boolean costRide(int bookingId);
}
