package com.mindtree.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.GetEmail;
import com.mindtree.dao.impl.GetEmailImp;
import com.mindtree.service.GetEmailService;
@Service
@Transactional
public class GetEmailServiceImpl implements GetEmailService {
	@Autowired
	GetEmail getEmail;
	public List getEmail(){
		//calling DaoClass method to getEmail of all user
		 
		return getEmail.getEmail();
		
	}
}
