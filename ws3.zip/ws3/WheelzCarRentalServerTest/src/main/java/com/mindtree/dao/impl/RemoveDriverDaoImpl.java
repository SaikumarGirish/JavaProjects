package com.mindtree.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.RemoveDriverDao;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;

@Repository
public class RemoveDriverDaoImpl implements RemoveDriverDao {
	
	@Autowired
	 private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Driver> getAllDrivers() {
		return sessionFactory.getCurrentSession().createQuery("from Driver D where D.driverDeleteStatus = 0").list();
	}

	public void deleteDriver(int driverId) {
		Driver driver=(Driver) sessionFactory.getCurrentSession().get(Driver.class,driverId);
		driver.setDriverDeleteStatus(1);
		sessionFactory.getCurrentSession().update(driver);
	}

	@SuppressWarnings("unchecked")
	public List<Driver> getAssignedDrivers() {
		return sessionFactory.getCurrentSession().createQuery("from Driver D where D.driverRidingStatus = 1 and D.driverDeleteStatus = 0").list();
	}

	@Override
	public void unassignDrivers(List<Integer> list) {
		for (int i = 0; i < list.size(); i++) {
			unassignDriver(list.get(i));
		}

	}

	@Override
	public void unassignDriver(int id) {
		Driver driver=(Driver) sessionFactory.getCurrentSession().get(Driver.class,id);
		driver.setDriverRidingStatus(0);
		sessionFactory.getCurrentSession().update(driver);
		List<Integer> bookingList = getBookingList(id);
		changeStatus(bookingList);
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> getBookingList(int id) {
		Query query = sessionFactory.getCurrentSession().createQuery("select B.bookingId from Booking B where B.driver.driverId = ? and B.bookingStatus != 2");
		query.setParameter(0,id);
		return query.list();
	}
	
	public void changeStatus(List<Integer> bId){
		for(int i=0; i<bId.size(); i++){
			Booking booking = (Booking) sessionFactory.getCurrentSession().get(Booking.class,bId.get(i));
			booking.setBookingStatus(2);
			sessionFactory.getCurrentSession().update(booking);
		}
	}

}

/*public void changeStatus(List<Integer> bId){
	for(int i=0; i<bId.size(); i++){
		Booking booking = (Booking) sessionFactory.getCurrentSession().get(Booking.class,bId.get(i));
		booking.setBookingStatus(2);
		sessionFactory.getCurrentSession().update(booking);
	}
}*/





//@Repository
//public class ChannelsDaoImpl implements ChannelsDao{
//	
//	 @Autowired
//	 private SessionFactory sessionFactory;
//
//	@Override
//	public void addChannels(Channels channels) {
//		sessionFactory.getCurrentSession().saveOrUpdate(channels);
//	}
//
//	@Override
//	public Channels updateChannels(Channels channels) {
//		sessionFactory.getCurrentSession().update(channels);
//		return channels;
//	}
//
//	@Override
//	@SuppressWarnings("unchecked")
//	public List<Channels> listChannels() {
//		return sessionFactory.getCurrentSession().createQuery("from Channels").list();
//	}
//
//	@Override
//	public Channels getChannelsById(int id) {
//		return (Channels) sessionFactory.getCurrentSession().get(Channels.class,id);
//	}
//
//	@Override
//	public void deleteChannels(int id) {
//		Channels channels = (Channels) sessionFactory.getCurrentSession().load(
//				Channels.class, id);
//        if (null != channels) {
//            this.sessionFactory.getCurrentSession().delete(channels);
//        }
//	}
//	
//}