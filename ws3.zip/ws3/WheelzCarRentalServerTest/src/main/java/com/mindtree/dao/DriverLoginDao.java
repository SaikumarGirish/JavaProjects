package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Driver;

public interface DriverLoginDao {
	public List<Driver> getDriverList();
}
