package com.mindtree.dao.impl;


import java.util.Date;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddOperatorBooking;
import com.mindtree.dao.AssignDao;
import com.mindtree.dto.AssignDriver;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;

@Repository
public class AssignDaoImpl implements AssignDao
{
	@Autowired
	 private SessionFactory sessionFactory;
	
	@Autowired
	private AddOperatorBooking addOperatorBooking;
	
//	SessionFactory s =  new Configuration().configure().buildSessionFactory();
	@Override
	public boolean get(AssignDriver detail) {
		
//		Session session = s.openSession();
//		try{
//		session.beginTransaction();
//		int adminId = detail.getAdministratorId();
//		int driveId =detail.getDriverId();
//		int bookId =detail.getBookingId();
//		Date driverAssignTime =detail.getDriverAssignTime();
//		AddOperatorBookingImpl addOperatorBookingImpl = new AddOperatorBookingImpl();
//		Driver driver = addOperatorBookingImpl.getDriver(driveId);
//		Administrator operator = getOperator(adminId);
//
//		Booking booking = session.get(Booking.class,bookId);
//		booking.setDriver(driver);
//		booking.setAdministrator(operator);
//		booking.setDriverAssignTime(driverAssignTime);
//		session.update(booking);
//		session.getTransaction().commit();
		
		int adminId = detail.getAdministratorId();
		int driveId =detail.getDriverId();
		int bookId =detail.getBookingId();
		
		Date driverAssignTime =detail.getDriverAssignTime();
		System.out.println(driverAssignTime);
		
		Administrator operator = getOperator(adminId);
		Driver driver = addOperatorBooking.getDriver(driveId);
		
		System.out.println(operator);
		System.out.println(driver);
		
		Booking booking=(Booking) sessionFactory.getCurrentSession().get(Booking.class, bookId);
		booking.setDriver(driver);
		booking.setAdministrator(operator);
		booking.setDriverAssignTime(driverAssignTime);
		sessionFactory.getCurrentSession().update(booking);
		
		return true;
//		}
//		finally
//		{
//			session.close();
//		}
//		
		
	}
	
	
	private Administrator getOperator(int adminId){
//		Session session = s.openSession();
//		session.beginTransaction();
//		Administrator operator = session.get(Administrator.class,adminId);
//		session.getTransaction().commit();
//		session.close();
		
		Administrator operator=(Administrator) sessionFactory.getCurrentSession().get(Administrator.class, adminId);
		return operator;
	}

}
