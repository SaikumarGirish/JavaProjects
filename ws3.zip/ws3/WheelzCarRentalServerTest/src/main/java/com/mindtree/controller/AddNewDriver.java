package com.mindtree.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;
import com.mindtree.service.AddNewDriverService;

@RestController
public class AddNewDriver {
	@Autowired
	AddNewDriverService addNewDriverService;
	//mapping for adding a new driver
	@RequestMapping(value = "/addNewDriver")
	public List<Driver> changeDestination(@RequestBody AddNewDriverDto addNewDriverObj) {
		System.out.println(addNewDriverObj.getEmail());
	    return addNewDriverService.addNewDriverService(addNewDriverObj);
	}
	
	//mapping for getting list of all drivers 
	@RequestMapping(value = "/getDriverList")
	public List<Driver> getDriver() {
		System.out.println("get driver controller");
	   return addNewDriverService.getDriverService();
		
	}

}