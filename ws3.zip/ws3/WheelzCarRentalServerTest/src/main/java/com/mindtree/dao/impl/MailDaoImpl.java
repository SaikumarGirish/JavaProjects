package com.mindtree.dao.impl;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.MailDao;
import com.mindtree.dto.AssignDriver;
import com.mindtree.dto.PostBookingData;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Route;
import com.mindtree.entity.User;

@Repository
public class MailDaoImpl implements MailDao {
	
	static final String USERNAME = "wheelzcarrentalco@gmail.com";
    static final String PASS = "mukeshyadav";
    String mess = "\nThanks for using Wheelz car rental \n Your Driver details are as follows \n";
	
	@Autowired
	 private SessionFactory sessionFactory;

	public boolean mailToUser(AssignDriver details)
	{
		Booking booking = (Booking) sessionFactory.getCurrentSession().get(Booking.class,details.getBookingId());
		User user=booking.getUser();
		Driver driver = booking.getDriver();
		 Properties props = new Properties();
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "587");
	        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(USERNAME, PASS);
	            }
	        });

	        try {

	            Message message = new MimeMessage(session);
	            message.setFrom(new InternetAddress(USERNAME));
	            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
	            message.setSubject("BOOKING CONFIRMED - Driver details");
	            message.setText(mess + "Driver Name : " + driver.getDriverName() + "\nDriver Phone Number : "
	            		+ driver.getPhoneNumber() + "\nCar Number : " + driver.getCarNumber() 
	            		+ "\nApproximate fare : " + booking.getCost() + "\n\nThanks and regards" +'\n' + "Wheelz Car Rental.Co");
	            Transport.send(message);

	        } catch (MessagingException e) {
	        	
	        }
		
		return true;
	}
	
	public boolean mailToDriver(AssignDriver details)
	{
		Booking booking = (Booking) sessionFactory.getCurrentSession().get(Booking.class,details.getBookingId());
		User user = booking.getUser();
		Driver driver = booking.getDriver();
		Route route = booking.getRoute();
		String payment="";
		if(booking.getWayOfPayment()==0){
			payment="Cash";
		}
		else if(booking.getWayOfPayment()==1){
			payment="PayTM";
		}
		else {
			payment="BHIM";
		}
		Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASS);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(driver.getEmail()));
            message.setSubject("RIDE ASSIGNED - User details");
            if(booking.getBookingStatus()==0)
            {
	            message.setText("Ride details"+"\nCustomer Name : "+user.getUserName()+"\nPhone number : "
	            		+user.getPhoneNumber()+"\nPick-up Location : "+route.getFromLocation().getLocation()+"\nDrop Location : "
	            		+route.getToLocation().getLocation()+"\nPayment Method : "+payment);
            }
            else if(booking.getBookingStatus()==1)
            {
            	message.setText("Ride details"+"\nCustomer Name : "+user.getUserName()+"\nPhone number : "
	            		+user.getPhoneNumber()+"\nPick-up Location : "+route.getFromLocation().getLocation()+"\nDrop Location : "
	            		+route.getToLocation().getLocation()+"\nPick-up Time : "+booking.getScheduleTime()+"\nPayment Method : "+payment);
            }
            Transport.send(message);

        } catch (MessagingException e) {
        	
        }
		return true;
	}

	@Override
	public boolean mailToUser(PostBookingData details) {
		Booking booking = (Booking) sessionFactory.getCurrentSession().get(Booking.class,details.getBookingId());
		User user=booking.getUser();
		Driver driver = booking.getDriver();
		 Properties props = new Properties();
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "587");
	        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(USERNAME, PASS);
	            }
	        });

	        try {

	            Message message = new MimeMessage(session);
	            message.setFrom(new InternetAddress(USERNAME));
	            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
	            message.setSubject("BOOKING CONFIRMED - Driver details");
	            message.setText(mess + "Driver Name : " + driver.getDriverName() + "\nDriver Phone Number : "
	            		+ driver.getPhoneNumber() + "\nCar Number : " + driver.getCarNumber() 
	            		+ "\nApproximate fare : " + booking.getCost() + "\n\nThanks and regards" +'\n' + "Wheelz Car Rental.Co");
	            Transport.send(message);

	        } catch (MessagingException e) {
	        	e.printStackTrace();
	        }
		
		return true;
	}

	@Override
	public boolean mailToDriver(PostBookingData details) {
		Booking booking = (Booking) sessionFactory.getCurrentSession().get(Booking.class,details.getBookingId());
		User user = booking.getUser();
		Driver driver = booking.getDriver();
		Route route = booking.getRoute();
		String payment="";
		if(booking.getWayOfPayment()==0){
			payment="Cash";
		}
		else if(booking.getWayOfPayment()==1){
			payment="PayTM";
		}
		else {
			payment="BHIM";
		}
		Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASS);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(driver.getEmail()));
            message.setSubject("RIDE ASSIGNED - User details");
            if(booking.getBookingStatus()==0)
            {
	            message.setText("Ride details"+"\nCustomer Name : "+user.getUserName()+"\nPhone number : "
	            		+user.getPhoneNumber()+"\nPick-up Location : "+route.getFromLocation().getLocation()+"\nDrop Location : "
	            		+route.getToLocation().getLocation()+"\nPayment Method : "+payment);
            }
            else if(booking.getBookingStatus()==1)
            {
            	message.setText("Ride details"+"\nCustomer Name : "+user.getUserName()+"\nPhone number : "
	            		+user.getPhoneNumber()+"\nPick-up Location : "+route.getFromLocation().getLocation()+"\nDrop Location : "
	            		+route.getToLocation().getLocation()+"\nPick-up Time : "+booking.getScheduleTime()+"\nPayment Method : "+payment);
            }
            Transport.send(message);

        } catch (MessagingException e) {
        	e.printStackTrace();
        }
		return true;
	}
}
