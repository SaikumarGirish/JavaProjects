package com.mindtree.dao;

import com.mindtree.dto.AssignDriver;
import com.mindtree.dto.PostBookingData;

public interface MailDao {
	
	public boolean mailToUser(AssignDriver details);
	public boolean mailToDriver(AssignDriver details);
	public boolean mailToUser(PostBookingData details);
	public boolean mailToDriver(PostBookingData details);

}
