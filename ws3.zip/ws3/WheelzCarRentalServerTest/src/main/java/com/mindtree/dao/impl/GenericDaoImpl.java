package com.mindtree.dao.impl;

import com.mindtree.dao.GenericDao;

public abstract class GenericDaoImpl<T> implements GenericDao<T> {

	@Override
	public T add(T t) {
		return t;
		
	}

	@Override
	public T get(int id) {
		return null;
	}
}
