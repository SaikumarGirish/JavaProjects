package com.mindtree.dao.impl;

import java.util.ArrayList;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.FacebookLoginDao;
import com.mindtree.entity.User;

@Repository
public class FacebookLoginDaoImpl implements FacebookLoginDao {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public User facebookCheck(User user) {

		ArrayList<User> list = (ArrayList<User>) sessionFactory.getCurrentSession()
				.createQuery(
						"from User where email='" + user.getEmail() + "' and userName='" + user.getUserName() + "'")
				.list();

		try {
			if (list.isEmpty()) {
				user = null;
			} else {
				user = list.get(0);
			}
			return user;

		} catch (NullPointerException e) {
			return null;
		}

	}

	@SuppressWarnings("unchecked")
	public User addFBUser(User user) {

		sessionFactory.getCurrentSession().saveOrUpdate(user);

		ArrayList<User> list = (ArrayList<User>) sessionFactory.getCurrentSession()
				.createQuery("from User where email='" + user.getEmail() + "' and userName='" + user.getUserName() + "'")
				.list();
		user = list.get(0);
		return user;
	}
}
