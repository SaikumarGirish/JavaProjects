package com.mindtree.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Locations {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int locationId;
	@Column(unique = true)
	private String location;
	@ManyToOne
	private Administrator administrator;
	private Date creationOfLocation;
	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Administrator getAdministrator() {
		return administrator;
	}

	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}

	public Date getCreationOfLocation() {
		return creationOfLocation;
	}

	public void setCreationOfLocation(Date creationOfLocation) {
		this.creationOfLocation = creationOfLocation;
	}

}
