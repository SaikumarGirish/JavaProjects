package com.mindtree.dao;

import com.mindtree.entity.Driver;

public interface DriverprofileDao {
	
	public Driver getDDetail(int id);
	public boolean setDDeatil(Driver driver);

}
