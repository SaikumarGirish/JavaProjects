package com.mindtree.service;

import com.mindtree.dto.Feedback;
import com.mindtree.exceptions.BookingIdNotFoundException;

public interface AddFeedbackService {
	public boolean addFeedback(Feedback feedback) throws BookingIdNotFoundException;
}
