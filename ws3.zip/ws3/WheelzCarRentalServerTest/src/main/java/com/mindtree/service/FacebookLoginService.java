package com.mindtree.service;

import com.mindtree.dto.FaceBook;
import com.mindtree.entity.User;

public interface FacebookLoginService {

	public User facebookCheck(FaceBook facebook);
	public User addFBUser(FaceBook facebook);
}
