package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.Feedback;
import com.mindtree.exceptions.BookingIdNotFoundException;
import com.mindtree.service.AddFeedbackService;
import com.mindtree.service.impl.AddFeedbackServiceImpl;
 

@RestController
public class FeedbackController {
	@Autowired
	AddFeedbackService addFeedback;
	@RequestMapping(value = "/addFeedback", method = RequestMethod.POST)
	//Save  user's Feedback into database 
	public boolean addFeedback(@RequestBody Feedback feedback) throws BookingIdNotFoundException {
	
		return addFeedback.addFeedback(feedback);
		
	}
}
