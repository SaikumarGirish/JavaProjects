package com.mindtree.dto;

import java.util.Date;

public class Userchart {
private Date timeOfBooking;
private Date scheduleTime;
public Date getTimeOfBooking() {
	return timeOfBooking;
}
public void setTimeOfBooking(Date timeOfBooking) {
	this.timeOfBooking = timeOfBooking;
}
public Date getScheduleTime() {
	return scheduleTime;
}
public void setScheduleTime(Date scheduleTime) {
	this.scheduleTime = scheduleTime;
}
}
