package com.mindtree.dto;

import java.util.Date;

public class BookingData {
	private int pickUpLocation;
	private int dropLocation;
	private int carType;
	private Date timeStamp;
	private String email;
	private Date scheduleTime;
	private int bookingStatus;
	private int payType;

	public int getPickUpLocation() {
		return pickUpLocation;
	}

	public void setDropLocation(int dropLocation) {
		this.dropLocation = dropLocation;
	}

	public void setCarType(int carType) {
		this.carType = carType;
	}

	public int getCarType() {
		return carType;
	}

	public void setPickUpLocation(int pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}

	public int getDropLocation() {
		return dropLocation;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public String getEmail() {
		return email;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getScheduleTime() {
		return scheduleTime;
	}

	public void setScheduleTime(Date scheduleTime) {
		this.scheduleTime = scheduleTime;
	}

	public int getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(int bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public int getPayType() {
		return payType;
	}

	public void setPayType(int payType) {
		this.payType = payType;
	}

}
