package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.entity.Driver;
import com.mindtree.service.DriverprofileService;
@RestController
public class DriverProfileController {
	
	@Autowired
	DriverprofileService dpService ;
	

	@ResponseBody
	@RequestMapping(value="/driverProfile/{id}",method=RequestMethod.GET)
	public Driver edpDriver(@PathVariable("id") int id) {
		Driver obj = dpService.driverDetail(id);
		return obj;
	}
	
	@ResponseBody
	@RequestMapping(value = "/editDriver", method = RequestMethod.POST)
	public boolean editDriver(@RequestBody Driver driver) {	
			return dpService.setDriver(driver);	
	}
	
}	

