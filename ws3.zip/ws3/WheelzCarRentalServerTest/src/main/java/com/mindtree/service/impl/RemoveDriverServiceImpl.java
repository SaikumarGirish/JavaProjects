package com.mindtree.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.RemoveDriverDao;
import com.mindtree.entity.Driver;
import com.mindtree.service.RemoveDriverService;

@Service
@Transactional
public class RemoveDriverServiceImpl implements RemoveDriverService {

	@Autowired
	RemoveDriverDao rdDao;
	
	@Transactional
	public List<Driver> getAllDrivers() {
		return rdDao.getAllDrivers();
	}

	@Transactional
	public void deleteDriver(int driverId) {
		rdDao.deleteDriver(driverId);
	}


	@Transactional
	public List<Driver> getAssignedDrivers() {
		return rdDao.getAssignedDrivers();
	}

	@Transactional
	public void unassignDrivers(List<Integer> list) {
		rdDao.unassignDrivers(list);
		
	}

	@Transactional
	public void unassignDriver(int id) {
		rdDao.unassignDriver(id);
		
	}

}
