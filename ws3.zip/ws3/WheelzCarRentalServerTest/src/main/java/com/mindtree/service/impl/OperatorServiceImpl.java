package com.mindtree.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.GetCredentials;
import com.mindtree.dao.OperatorDao;
import com.mindtree.dto.OperatorAnalytic;
import com.mindtree.dto.OperatorDTO;
import com.mindtree.entity.Administrator;
import com.mindtree.service.OperatorService;

@Service
@Transactional
public class OperatorServiceImpl implements OperatorService{

	@Autowired
	private GetCredentials getCredentials;
	
	@Autowired
	private OperatorDao operator;
	
	public List<Administrator> getOperatorList(){
		return getCredentials.getOperators();
	}
	
	public Administrator addNewOperator(OperatorDTO dto){
		Administrator admin=new Administrator();
		admin.setAdministratorName(dto.getOperatorName());
		admin.setEmail(dto.getEmail());
		admin.setGender(dto.getGender());
		admin.setPassword(dto.getPassword());
		admin.setPhoneNumber(dto.getPassword());
		admin.setAuthority(0);
		return operator.addNewOperator(admin);
	}
	
	public List<OperatorAnalytic> getOperatorAnalytic(){
		return operator.getOperatorAnalytic();
	}
}
