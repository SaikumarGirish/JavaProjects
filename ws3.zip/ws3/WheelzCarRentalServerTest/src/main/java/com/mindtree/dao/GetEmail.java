package com.mindtree.dao;

import java.util.List;
public interface GetEmail {

	public List getEmail();
		 
 
}
