package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.AdministratorNotFoundException;

public interface AdminLoginDao {
	
	public List<Administrator> setOperator(Administrator admin) throws AdministratorNotFoundException;
	public List<Administrator> adminLogin(Administrator a) throws AdministratorNotFoundException;

}
