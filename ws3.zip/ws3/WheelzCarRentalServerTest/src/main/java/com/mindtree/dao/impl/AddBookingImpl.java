package com.mindtree.dao.impl;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddBooking;
import com.mindtree.entity.Booking;
@Repository
public class AddBookingImpl implements AddBooking {
	@Autowired
	 private SessionFactory sessionFactory;
/*This method is used to insert booking details 
 * into the booking table when user 
 * books a cab by logging in and returns the last inserted booking 
 * Id to front end for further use*/
	@Override
	public Booking addNewBooking(Booking booking) {
		sessionFactory.getCurrentSession().save(booking);
		Query query = sessionFactory.getCurrentSession().createQuery("from Booking order by bookingId DESC");
		query.setMaxResults(1);
		booking = (Booking) query.uniqueResult();
		return booking;
	}
}
