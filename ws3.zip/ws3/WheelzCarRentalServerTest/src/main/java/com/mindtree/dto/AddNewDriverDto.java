package com.mindtree.dto;

public class AddNewDriverDto {
	private String driverName;
	private String email;
	private String carNumber;
	private int modelType;
	private int gender;
	private String  phoneNumber;
    private String licenceNumber;
    private String password;
    private String address;
    private int age;
    private int driverRidingStatus;
    private int driverDeleteStatus;
   private String dateOfRegistration;
    private int administratorId;
	public String getDriverName() {
		return driverName;
	}
	
	
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	
	public int getDriverRidingStatus() {
		return driverRidingStatus;
	}
	public void setDriverRidingStatus(int driverRidingStatus) {
		this.driverRidingStatus = driverRidingStatus;
	}
	public int getDriverDeleteStatus() {
		return driverDeleteStatus;
	}
	public void setDriverDeleteStatus(int driverDeleteStatus) {
		this.driverDeleteStatus = driverDeleteStatus;
	}
	public String getDateOfRegistration() {
		return dateOfRegistration;
	}
	public void setDateOfRegistration(String dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}
	public int getAdministratorId() {
		return administratorId;
	}
	public void setAdministratorId(int administratorId) {
		this.administratorId = administratorId;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getEmail() {
		return email;
	}
	
	
	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}
	public int getModelType() {
		return modelType;
	}
	
	public int getGender() {
		return gender;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getLicenceNumber() {
		return licenceNumber;
	}
	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setModelType(int modelType) {
		this.modelType = modelType;
	}
	
	public String getCarNumber() {
		return carNumber;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setGender(int gender) {
		this.gender = gender;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
}
