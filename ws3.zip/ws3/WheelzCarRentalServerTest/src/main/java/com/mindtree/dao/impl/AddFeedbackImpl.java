package com.mindtree.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddFeedback;
import com.mindtree.dto.Feedback;
import com.mindtree.entity.Booking;
import com.mindtree.exceptions.BookingIdNotFoundException;
@Repository
public class AddFeedbackImpl implements AddFeedback{
	@Autowired
	 private SessionFactory sessionFactory;
	@Override
	public boolean addFeedback(Feedback feedback) throws BookingIdNotFoundException{
		//opening session Factory    
//		SessionFactory s = new Configuration().configure().buildSessionFactory();
//		Session session = s.openSession();
//			
		
				
//			    session.beginTransaction();
//			    Query query;
//				//hql to use whether bookingId exist or not in database//is  exist the save in database
//			    try{ 
//			    	query = session.createQuery("from Booking where bookingId= '"+feedback.getBookingId() + "'"); 
//			   
//			    	@SuppressWarnings("unchecked")
//					List<Booking> list=(List<Booking>)query.list(); 
//				    Booking booking = list.get(0); 
//				    booking.setUserFeedback(feedback.getCommnet()); 
//				    booking.setDriverRating(feedback.getRating()); 
//				    session.update(booking);
//				    session.getTransaction().commit();
//			    }
//			
//			    catch(Exception ex)
//			    {
//			    	throw new BookingIdNotFoundException("Booking Id Not Found");
//			    }
//			    finally{
//					 session.close();
//		             s.close();
//	                    }
//				
		Query query= sessionFactory.getCurrentSession().createQuery("from Booking where bookingId= '"+feedback.getBookingId() + "'");
		@SuppressWarnings("unchecked")
		List<Booking> list=(List<Booking>)query.list(); 
	    Booking booking = list.get(0); 
	    booking.setUserFeedback(feedback.getCommnet()); 
	    booking.setDriverRating(feedback.getRating()); 
	    sessionFactory.getCurrentSession().update(booking);
	    return true;
			    
					 
 

			 
	}
	

}
