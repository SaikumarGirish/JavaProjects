package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.exceptions.UserNotFoundException;

public interface Login 
{

	public User check(User u) throws UserNotFoundException;
	public List<Administrator> operatorLogin(Administrator a) throws OperatorNotFoundException;

	
}
