package com.mindtree.dto;

public class OperatorDTO {

	private String operatorName;
	private String email;
	private int gender;
	private String phoneNumber;
	private String password;
	
	public OperatorDTO() {
		super();
	}
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getGender() {
		return gender;
	}
	public void setGender(int gender) {
		this.gender = gender;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "OperatorDTO [operatorName=" + operatorName + ", email=" + email + ", gender=" + gender
				+ ", phoneNumber=" + phoneNumber + ", password=" + password + "]";
	}
	
}
