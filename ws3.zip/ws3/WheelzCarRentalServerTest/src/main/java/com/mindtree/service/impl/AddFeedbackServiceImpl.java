package com.mindtree.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.AddFeedback;
import com.mindtree.dto.Feedback;
import com.mindtree.exceptions.BookingIdNotFoundException;
import com.mindtree.service.AddFeedbackService;
@Service
@Transactional
public class AddFeedbackServiceImpl implements AddFeedbackService {
@Autowired
AddFeedback addFeedback;
	@Override
	public boolean addFeedback(Feedback feedback) throws BookingIdNotFoundException {
		//calling DaoClass method to addFeedback
		 
		return  addFeedback.addFeedback(feedback);	
	}

}
