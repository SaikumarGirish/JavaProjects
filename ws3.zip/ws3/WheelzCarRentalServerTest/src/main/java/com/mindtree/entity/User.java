package com.mindtree.entity;
 
import javax.persistence.*;
  
@Entity
public class User {

	@Id
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userId;

	private String userName;
	
	private String phoneNumber;

	private int gender;
	
	private String email;

	private String password;

	private int otp;
	
	private int userDeleteStatus;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public int getUserDeleteStatus() {
		return userDeleteStatus;
	}

	public void setUserDeleteStatus(int userDeleteStatus) {
		this.userDeleteStatus = userDeleteStatus;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", phoneNumber=" + phoneNumber + ", gender="
				+ gender + ", email=" + email + ", password=" + password + ", otp=" + otp + ", userDeleteStatus="
				+ userDeleteStatus + "]";
	}
	
	

}
