
package com.mindtree.dao.impl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.MyRidesDao;
import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;
import com.mindtree.entity.Route;

@Repository
public class MyRidesDaoImpl implements MyRidesDao {
	
	@Autowired
	SessionFactory sessionFactory;
	
	List<Booking> emptyList = new ArrayList<>();
	List<Locations> emptyLoc = new ArrayList<>();
	String constQuery="from Booking where bookingStatus=";
	String fromBook = "from Booking where bookingId=";
	String fromLoc = "from Locations where location=";

	//getting past ride detail from database
	@SuppressWarnings("unchecked")
	public List<Booking> pastRides(int uId){	
		
		try{
			String hql = constQuery + "? and user_userId=?";
		Query query1=sessionFactory.getCurrentSession().createQuery(hql);
 
		query1.setParameter(0, 2);
		query1.setParameter(1,uId);
		return (List<Booking>)query1.list();
		}
		catch(Exception e){
			return Collections.emptyList();
		}	
	}
	
	
	//getting ongoing ride detail from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> ongoingRides(int uId1) {
		try{
			String hql = constQuery + "?  and user_userId=?";
		Query query2=sessionFactory.getCurrentSession().createQuery(hql);
		query2.setParameter(0,0);
		query2.setParameter(1, uId1);
		return (List<Booking>)query2.list();
		}
		catch(Exception e){
			return Collections.emptyList();
		}
	}
	
	//getting upcoming ride detail from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> upcomingRides(int uId) {
		try{
			String hql = constQuery + "? and deleted=? and user_userId=?";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter(0,1);
		query.setParameter(1,0);
		query.setParameter(2,uId);
		return (List<Booking>)query.list();
		}
		catch(Exception e){
			return Collections.emptyList();
		}
	}
	
	//getting all locations from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Locations> getlocations() {
		try{
		String hql="from Locations";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		return (List<Locations>)query.list();
		}
		catch(Exception e){
			return Collections.emptyList();
		}
	}
	//changing destination of ongoing ride in database
	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> changingDestination(ChangeDestination changeDestObj) {
		try{
		String hql = fromBook + "?";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter(0,changeDestObj.getBookingId() );
		List<Booking> bookingList=query.list();
		Booking booking =bookingList.get(0);
		Route route = booking.getRoute();
		int carType = booking.getCarType();
		String pickUp = route.getFromLocation().getLocation();
		
		
		String hql1 = fromLoc + "?";
		Query query1=sessionFactory.getCurrentSession().createQuery(hql1);
		query1.setParameter(0, pickUp);
		List<Locations> loc1=query1.list();
		Locations pickupLoc = loc1.get(0);
		int pickupLocId = pickupLoc.getLocationId();
		
		String hql2 = fromLoc + "?";
		Query query2=sessionFactory.getCurrentSession().createQuery(hql2);
		query2.setParameter(0, changeDestObj.getLocation());
		List<Locations> loc2=query2.list();
		Locations dropLoc = loc2.get(0);
		int dropLocId = dropLoc.getLocationId();
	
		String hql3 = "from Route where fromLocation_locationId=? and toLocation_locationId=?";
		Query query3=sessionFactory.getCurrentSession().createQuery(hql3);
		query3.setParameter(0, pickupLocId);
		query3.setParameter(1, dropLocId);
		List<Route> routes = query3.list();
		Route r = routes.get(0);
	
		int distance = r.getDistance();
		int cost = calculateCost(distance,carType);
		
		
		booking.setRoute(r);
		booking.setCost(cost);
		sessionFactory.getCurrentSession().saveOrUpdate(booking);
		
		String finalHql = fromBook+"?";
		Query finalQuery=sessionFactory.getCurrentSession().createQuery(finalHql);
		finalQuery.setParameter(0,changeDestObj.getBookingId());
		return (List<Booking>)finalQuery.list();
		}
		catch(Exception e){
			return Collections.emptyList();
		}
	}
	//deleting a given upcoming ride from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> deleteDao(int id) {
		try{
		String hql = fromBook + "?";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter(0, id);
		List<Booking> bookingList=(List<Booking>)query.list();
		Booking booking = bookingList.get(0);
		booking.setDeleted(1);
		sessionFactory.getCurrentSession().saveOrUpdate(booking);
		
		String hql1="from Booking where bookingStatus=? and deleted=?";
		Query query1=sessionFactory.getCurrentSession().createQuery(hql1);
		query1.setParameter(0, 1);
		query1.setParameter(1, 0);
		return (List<Booking>)query1.list();
		}
		catch(Exception e){
			return Collections.emptyList();
		}
		
	}
	//change pickup and drop location of given upcoming ride from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> updateUpcomingDao(UpdateUpcoming updateObj,String pickUp) {
		try{
		String hql = fromBook  + "?";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter(0, updateObj.getBookingId());
		List<Booking> bookingList=query.list();
		Booking booking =bookingList.get(0);
	
		
		String hql1 = fromLoc + "?";
		Query query1=sessionFactory.getCurrentSession().createQuery(hql1);
		query1.setParameter(0, pickUp );
		List<Locations> loc1=query1.list();
		Locations pickupLoc = loc1.get(0);
		int pickupLocId = pickupLoc.getLocationId();
		
		String hql2 = fromLoc + "?";
		Query query2=sessionFactory.getCurrentSession().createQuery(hql2);
		query2.setParameter(0, updateObj.getLocation());
		List<Locations> loc2=query2.list();
		Locations dropLoc = loc2.get(0);
		int dropLocId = dropLoc.getLocationId();
		
		String hql3 = "from Route where fromLocation_locationId=? and toLocation_locationId=?";
		Query query3=sessionFactory.getCurrentSession().createQuery(hql3);
		query3.setParameter(0, pickupLocId);
		query3.setParameter(1, dropLocId);
		List<Route> routes = query3.list();
		Route r = routes.get(0);
		int cost = calculateCost(r.getDistance(),booking.getCarType()); 
		
		booking.setCost(cost);
		booking.setRoute(r);
		sessionFactory.getCurrentSession().saveOrUpdate(booking);
		return bookingList;
		}
		catch(Exception e){
			return Collections.emptyList();
		}

	}
	
	
	//calculating cost for changing the booking details
	public int calculateCost(int distance, int carType){
		int cost = 0;
		if (distance <= 4) {
			if (carType == 0) {
				cost = 40;
			} else if (carType == 1) {
				cost = 50;
		}
		}
		else {
			if (carType == 0) {
				cost = (((distance - 4) * 11) + 40);

			} else if (carType == 1) {
				cost = (((distance - 4) * 13) + 50);
			}
		}
		
		return cost;
		
	}
	
}
