package com.mindtree.dto;

public class OperatorAnalytic {

	private String name;
	private int bookingCount;
	
	public OperatorAnalytic() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBookingCount() {
		return bookingCount;
	}

	public void setBookingCount(int bookingCount) {
		this.bookingCount = bookingCount;
	}

	@Override
	public String toString() {
		return "OperatorAnalytic [name=" + name + ", bookingCount=" + bookingCount + "]";
	}
	
}
