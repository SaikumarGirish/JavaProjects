package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.Driver;
import com.mindtree.service.DriverLoginService;


@RestController
public class DriverLoginController {
	@Autowired
	 DriverLoginService driverLoginService;
	@RequestMapping(value = "/driverLogin")
	public Driver driverLogin(@RequestBody Driver driver) {
	   return driverLoginService.validateDriver(driver);
	}

}
