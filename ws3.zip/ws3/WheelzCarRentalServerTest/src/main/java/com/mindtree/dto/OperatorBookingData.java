package com.mindtree.dto;

import java.util.Date;

public class OperatorBookingData {
	private String userName;
	private String phoneNumber;
	private String email;
	private int pickUpLocation;
	private int dropLocation;
	private int carType;
	private int driverId;
	private Date timeI;
	private int operatorId;
	private Date scheduleTime;
	private int bookingStatus;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPickUpLocation() {
		return pickUpLocation;
	}

	public void setPickUpLocation(int pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}

	public int getDropLocation() {
		return dropLocation;
	}

	public void setDropLocation(int dropLocation) {
		this.dropLocation = dropLocation;
	}

	public int getCarType() {
		return carType;
	}

	public void setCarType(int carType) {
		this.carType = carType;
	}

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public Date getTimeI() {
		return timeI;
	}

	public void setTimeI(Date timeI) {
		this.timeI = timeI;
	}

	public int getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(int operatorId) {
		this.operatorId = operatorId;
	}

	public Date getScheduleTime() {
		return scheduleTime;
	}

	public void setScheduleTime(Date scheduleTime) {
		this.scheduleTime = scheduleTime;
	}

	public int getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(int bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

}
