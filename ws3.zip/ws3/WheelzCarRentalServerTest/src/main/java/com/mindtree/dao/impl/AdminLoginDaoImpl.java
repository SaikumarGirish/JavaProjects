package com.mindtree.dao.impl;

import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AdminLoginDao;
import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.AdministratorNotFoundException;

@Repository
public class AdminLoginDaoImpl implements AdminLoginDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public  List<Administrator> setOperator(Administrator admin) throws AdministratorNotFoundException{
		Administrator  adminDetailList = new Administrator();
		adminDetailList.setEmail(admin.getEmail());
		adminDetailList.setPassword(admin.getPassword());
		List<Administrator> adminObj = adminLogin(adminDetailList);	
		return adminObj;
	}
	
	@SuppressWarnings("unchecked")
	public List<Administrator> adminLogin(Administrator a) throws AdministratorNotFoundException {

		String findEmail= "";
		String findPass = "";
		Query query = sessionFactory.getCurrentSession().createQuery("from Administrator where Email= ? and authority = 1");
		query.setParameter(0, a.getEmail());
		List<Administrator> list = query.list();
 		try {
 			for (Administrator i : list) {
 				findEmail = i.getEmail();
 				findPass = i.getPassword();
 			}
 		} catch (NullPointerException ex) {
 			throw new AdministratorNotFoundException("Administrator not found");
 		}
 		
 		if (!(list.isEmpty())&&(findEmail.equalsIgnoreCase(a.getEmail())) && findPass.equals(a.getPassword())) {
			return list;
 		} else {
 			return Collections.emptyList();
 		}

	}

}
