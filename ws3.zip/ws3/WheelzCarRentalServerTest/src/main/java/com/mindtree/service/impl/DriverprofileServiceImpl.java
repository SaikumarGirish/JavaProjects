package com.mindtree.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.DriverprofileDao;
import com.mindtree.entity.Driver;
import com.mindtree.service.DriverprofileService;

@Service
@Transactional
public class DriverprofileServiceImpl implements DriverprofileService{
	
	@Autowired
	DriverprofileDao dpDao;

	@Transactional
	public Driver driverDetail(int id) {
		
		
		return dpDao.getDDetail(id);
	}

	@Transactional
	public boolean setDriver(Driver driver) {
		return dpDao.setDDeatil(driver);
	}

	
}
