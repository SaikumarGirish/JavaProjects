package com.mindtree.service;

import com.mindtree.dto.AssignDriver;

public interface AssignService {

	public boolean get(AssignDriver details);

}
