package com.mindtree.dao;

import java.util.List;

import com.mindtree.dto.OperatorAnalytic;
import com.mindtree.entity.Administrator;

public interface OperatorDao {
	public Administrator addNewOperator(Administrator operator);
	public List<OperatorAnalytic> getOperatorAnalytic();
}
