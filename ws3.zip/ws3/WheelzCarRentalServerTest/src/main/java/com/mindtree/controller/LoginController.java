package com.mindtree.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.entity.User;
import com.mindtree.exceptions.UserNotFoundException;
import com.mindtree.service.LoginService;


@RestController
public class LoginController {

	@Autowired
	LoginService sereve ;

/*	This method is use to check the login credentials from front end and sending this details to DAO 
	   layer for comparison*/
	
	@RequestMapping(value = "/logindata", method = RequestMethod.POST)
	public User getdata(@RequestBody User users) throws UserNotFoundException  
	{
		User flag = sereve.setUser(users);
		
		if (flag == null) {
			return null;
		} else {
			return flag ;
		}
	}
}
