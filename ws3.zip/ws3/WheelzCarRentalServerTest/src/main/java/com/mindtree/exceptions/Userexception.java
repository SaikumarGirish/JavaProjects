package com.mindtree.exceptions;

@SuppressWarnings("serial")
public class Userexception extends Exception{
public Userexception(String s,Throwable e)
{
	super(s,e);
}
}
