package com.mindtree.service.impl;

import java.util. List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.GetPhone;
import com.mindtree.dao.impl.GetPhoneImpl;
import com.mindtree.service.GetPhoneService;
@Service
@Transactional
public class GetPhoneSErviceImpl implements GetPhoneService{
@Autowired
	GetPhone getPhone;
	public  List getPhone() {
		//calling DaoClass method toget phone for all users
		 
		return getPhone.getPhone();
		 
	}

}
