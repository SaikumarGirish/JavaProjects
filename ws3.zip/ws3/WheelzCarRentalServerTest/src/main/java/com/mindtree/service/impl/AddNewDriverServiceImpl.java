package com.mindtree.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.AddNewDriverDao;
import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Driver;
import com.mindtree.service.AddNewDriverService;

@Service
@Transactional
public class AddNewDriverServiceImpl implements AddNewDriverService {
	@Autowired
	AddNewDriverDao addNewDriverDao;
	//calling method of dao to add a driver
	@Transactional
	@Override
	public List<Driver> addNewDriverService(AddNewDriverDto addNewDriverObj) {
		return addNewDriverDao.addDriverDao(addNewDriverObj);
	}

	//calling method of dao to get list of drivers
	@Transactional
	@Override
	public List<Driver> getDriverService() {
		return addNewDriverDao.getDriverDao();
	}

}
