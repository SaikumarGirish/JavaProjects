package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Driver;

public interface RemoveDriverService {
	
	public List<Driver> getAllDrivers();
	public void deleteDriver(int driverId);
	public List<Driver> getAssignedDrivers();
	public void unassignDrivers(List<Integer> list);
	public void unassignDriver(int id);

}
