package com.mindtree.dao;

import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.User;

public interface AddOperatorBooking {
	public User checkUser(User user);
	public Administrator getAdministrator(int administrartorId);
	public Driver getDriver(int driverId);
}
