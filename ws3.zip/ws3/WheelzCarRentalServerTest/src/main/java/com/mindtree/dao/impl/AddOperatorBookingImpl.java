package com.mindtree.dao.impl;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddOperatorBooking;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.User;
import com.mindtree.exceptions.AdministratorNotFoundException;
import com.mindtree.exceptions.DriverNotFoundException;
@Repository
public class AddOperatorBookingImpl implements AddOperatorBooking {
	@Autowired
	 private SessionFactory sessionFactory;
@Override
	public User checkUser(User user) {
		String email = user.getEmail();
		Query query =  sessionFactory.getCurrentSession().createQuery("from User where email='" + email + "'");
		ArrayList<User> userList = (ArrayList<User>) query.list();
		if (userList.isEmpty()) {
			sessionFactory.getCurrentSession().save(user);
			Query queryUser = sessionFactory.getCurrentSession().createQuery("from User order by userId DESC");
			queryUser.setMaxResults(1);
			user = (User) queryUser.uniqueResult();
		} else {

			user = userList.get(0);
		}
		return user;
	}
@Override
	public Administrator getAdministrator(int administrartorId) {
		Administrator operator = null;
		try{
		operator = (Administrator) sessionFactory.getCurrentSession().get(Administrator.class, administrartorId);
		if(operator == null){
			throw new AdministratorNotFoundException("Administrator not found");
		}
		}catch(AdministratorNotFoundException e){
			
			return operator;
		}
		return operator;
	}
@Override
	public Driver getDriver(int driverId) {
	Driver driver = null;
        try{
		driver = (Driver) sessionFactory.getCurrentSession().get(Driver.class, driverId);
		if(driver == null){
			throw new DriverNotFoundException("Driver not found");
		}
		driver.setDriverRidingStatus(1);
		sessionFactory.getCurrentSession().update(driver);
        }catch(DriverNotFoundException e){
        	return driver;
        }
		return driver;
	}

}
