package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.FaceBook;
import com.mindtree.entity.User;
import com.mindtree.service.FacebookLoginService;

@RestController
public class FacebookLoginController {

	@Autowired
	FacebookLoginService fbService;

	/*
	 * this method will retrieve the details of user from front end and check
	 * whether it is already present in the database or not if not present it
	 * will add it into database otherwise not.
	 */
	@RequestMapping(value = "/fblogin", method = RequestMethod.POST)
	public User getFacebookData(@RequestBody FaceBook facebook) {
		User user =fbService.facebookCheck(facebook);
		if (user==null) {
			user = fbService.addFBUser(facebook);
			return user;
		}
		return user;
	}
}
