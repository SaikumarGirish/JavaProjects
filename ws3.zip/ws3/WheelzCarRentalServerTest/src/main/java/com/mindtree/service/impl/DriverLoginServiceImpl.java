package com.mindtree.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.DriverLoginDao;
import com.mindtree.entity.Driver;
import com.mindtree.service.DriverLoginService;

@Service
@Transactional
public class DriverLoginServiceImpl implements DriverLoginService{
	@Autowired
	DriverLoginDao driverLoginDao;
	public DriverLoginServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	@Transactional
	@Override
	public Driver validateDriver(Driver driver) {
		List<Driver> driverList = driverLoginDao.getDriverList();
		for(Driver d: driverList){
			if(((d.getEmail()).equals(driver.getEmail())) && ((d.getPassword()).equals(driver.getPassword()))){
				return d;
			}
		}
		
		return new Driver();
	}

}
