package com.mindtree.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AssignRideDao;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;
 
@Repository
public class AssignRideDaoImpl implements AssignRideDao{
	@Autowired
	 private SessionFactory sessionFactory;
	 @SuppressWarnings("unchecked")
	@Override
	public List<Booking> assignRide(int id) {
	     
 
		 Query query= sessionFactory.getCurrentSession().createQuery("from Booking where driver_driverId = ? and bookingstatus = ?");
		 query.setParameter(0, id);
			query.setParameter(1,0);
			List<Booking> assignRide = (List<Booking>) query.list();
			return assignRide;
	}
	@Override
	public boolean startRide(int id) {
		 
 
		System.out.println(id);
		Query query= sessionFactory.getCurrentSession().createQuery("from Driver where driverId = ?");
		query.setParameter(0, id);
		@SuppressWarnings("unchecked")
		List<Driver> list=(List<Driver>)query.list(); 
		Driver driver = list.get(0); 
	    driver.setDriverRidingStatus(1); 
	    sessionFactory.getCurrentSession().update(driver);
	    System.out.println("print");
		return true;
	}
	@Override
	public boolean endRide(int id) {	
		System.out.println(id);
		Query query= sessionFactory.getCurrentSession().createQuery("from Driver where driverId = ?");
		 query.setParameter(0, id);
		@SuppressWarnings("unchecked")
		List<Driver> list=(List<Driver>)query.list(); 
		Driver driver = list.get(0); 
	    driver.setDriverRidingStatus(0); 
	    sessionFactory.getCurrentSession().update(driver);
		return true;
	}
	
	@Override
	public boolean costRide(int id) {		
		System.out.println(id);
		Query query= sessionFactory.getCurrentSession().createQuery("from Booking where bookingId = ?");
		 query.setParameter(0, id);
		@SuppressWarnings("unchecked")
		List<Booking> list=(List<Booking>)query.list(); 
		Booking booking = list.get(0); 
		booking.setPaymentStatus(1);
		booking.setBookingStatus(2);
	    sessionFactory.getCurrentSession().update(booking);
		return true;
	}
}
