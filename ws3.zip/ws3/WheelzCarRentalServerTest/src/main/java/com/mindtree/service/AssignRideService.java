package com.mindtree.service;

import java.util.List;

import com.mindtree.dto.AssignDriver;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;

public interface AssignRideService {
public List<Booking> assignRide(AssignDriver driver);
public boolean startRide(AssignDriver driver);
public boolean endRide(AssignDriver driver);
public boolean costRide(AssignDriver driver);
}
