package com.mindtree.service.impl;


import java.text.ParseException;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.GetBookings;
import com.mindtree.dto.Userchart;
import com.mindtree.entity.Booking;
import com.mindtree.service.GetBookingsService;


@Service
@Transactional
public class GetBookingsServiceImpl implements GetBookingsService 

{
	@Autowired
	GetBookings get;
	@Transactional
	public List<Booking> getBookings() {
		
		return get.getBooking();
		
	}
	
	/*
	 * This method is used to get all the bookings done by the driver and
	 * sending to driver to view
	 */
	@Transactional
	public List<Booking> getPastTrip(int dId) {
		List<Booking> result = get.pastTrips(dId);
		Collections.reverse(result);
		return result;
	}

	/*
	 * This method is used to get the earnings done by the user and sending to
	 * the driver
	 */

	@Transactional
	public long getCost(int dId) throws ParseException {
		


		Date fromDate = new Date();
		Instant now = Instant.now(); // current date
		Instant before = now.minus(Duration.ofDays(7));
		Date endDate = Date.from(before);

		return get.getEarnings(dId, fromDate, endDate);
	}

	@Override
	public List<Booking> getBooking() {
		
		return get.getBook();
	}

	@Override
	public List<Userchart> getchart() {
		// TODO Auto-generated method stub
		return get.getchart();
	}
	

}
