package com.mindtree.dto;

import com.mindtree.entity.Driver;

public class DriverChart {
private int count;
private String driver;
private int cost;
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
//public Driver getDriver() {
//	return driver;
//}
//public void setDriver(Driver driver) {
//	this.driver = driver;
//}
public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}


}
