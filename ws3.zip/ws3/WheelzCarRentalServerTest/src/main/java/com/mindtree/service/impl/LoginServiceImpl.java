package com.mindtree.service.impl;

 
import java.util.List;

 
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.dao.AddCredential;
import com.mindtree.dao.Login;
import com.mindtree.dto.Gmaildata;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.exceptions.UserNotFoundException;
import com.mindtree.service.LoginService;
 
@Service
@Transactional
public class LoginServiceImpl implements LoginService
{
	 @Autowired
		AddCredential addCredential;

	 
	 @Autowired
		private Login l;
	 
	@Autowired
	Login operatorLogin;
	// This Service is used to send the login credentials to DAO layer
 
	
	
	
	@Override
	@Transactional
	public User setUser(User users) throws UserNotFoundException {
		
		User u = new User();
		User us =null;
		u.setEmail(users.getEmail());
		u.setPassword(users.getPassword());
		us=  l.check(u);
		return us;
		
	}

	
	
	
	public User addUser(User user) {
		
		return addCredential.addUser(user);
	}



	@Override
	public  List<Administrator> setOperator(Administrator admin) throws OperatorNotFoundException{
		Administrator  adminDetailList = new Administrator();
		List<Administrator> adminObj =null;
		adminDetailList.setEmail(admin.getEmail());
		adminDetailList.setPassword(admin.getPassword());
			adminObj = operatorLogin.operatorLogin(adminDetailList);	
		return adminObj;
	}

	@Override
	@Transactional
	public  User checkUser(Gmaildata gmailuser) {
		
		User user=new User();
		user.setUserName( gmailuser.getName());
		 
		user.setEmail( gmailuser.getEmail());
		 System.out.println(user.getEmail());
		
		return this.addCredential.checkUser( user);
	}
}
