package com.mindtree.entity;







import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Digits;



@Entity
public class Booking {
	@Id
	@Digits(fraction = 0, integer = 20)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingId;
	@Digits(fraction = 0, integer = 1)
	private int bookingStatus;
	@ManyToOne
	private User user;
	@ManyToOne
	private Driver driver;
	@Column
	private Timestamp pickUpTime;
	@Column
	private Timestamp dropTime;
	@Digits(fraction = 0, integer = 1)
	private int driverRating;
	@ManyToOne
	private Route route;
	@ManyToOne
	private Administrator administrator;
	@Column
	@Digits(fraction = 0, integer = 1)
	private int paymentStatus;
	@Column
	@Digits(fraction = 0, integer = 1)
	private int deleted;
	private String userFeedback;
	@Digits(fraction = 0, integer = 5)
	private int cost;
	@Digits(fraction = 0, integer = 1)
	private int wayOfPayment;
	@Column
	private Date timeOfBooking;
	@Column
	private Date driverAssignTime;
	@Column
	@Digits(fraction = 0, integer = 1)
	private int carType;
	@Column
	private Date scheduleTime;
	public Date getScheduleTime() {
		return scheduleTime;
	}
	public void setScheduleTime(Date scheduleTime) {
		this.scheduleTime = scheduleTime;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getCarType() {
		return carType;
	}
	public void setCarType(int carType) {
		this.carType = carType;
	}
	public int getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(int bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Driver getDriver() {
		return driver;
	}
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	public Timestamp getPickUpTime() {
		return pickUpTime;
	}
	public void setPickUpTime(Timestamp pickUpTime) {
		this.pickUpTime = pickUpTime;
	}
	public Timestamp getDropTime() {
		return dropTime;
	}
	public void setDropTime(Timestamp dropTime) {
		this.dropTime = dropTime;
	}
	public int getDriverRating() {
		return driverRating;
	}
	public void setDriverRating(int driverRating) {
		this.driverRating = driverRating;
	}
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
	public Administrator getAdministrator() {
		return administrator;
	}
	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}
	public int getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(int paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
	public String getUserFeedback() {
		return userFeedback;
	}
	public void setUserFeedback(String userFeedback) {
		this.userFeedback = userFeedback;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getWayOfPayment() {
		return wayOfPayment;
	}
	public void setWayOfPayment(int wayOfPayment) {
		this.wayOfPayment = wayOfPayment;
	}
	public Date getTimeOfBooking() {
		return timeOfBooking;
	}
	public void setTimeOfBooking(Date timeOfBooking) {
		this.timeOfBooking = timeOfBooking;
	}
	public Date getDriverAssignTime() {
		return driverAssignTime;
	}
	public void setDriverAssignTime(Date driverAssignTime) {
		this.driverAssignTime = driverAssignTime;
	}

}
