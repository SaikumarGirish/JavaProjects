package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.AdministratorNotFoundException;

public interface AdminLoginService {
	
	public  List<Administrator> setOperator(Administrator admin) throws AdministratorNotFoundException;

}
