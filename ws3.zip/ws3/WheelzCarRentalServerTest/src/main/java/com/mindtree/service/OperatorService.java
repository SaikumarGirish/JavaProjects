package com.mindtree.service;

import java.util.List;

import com.mindtree.dto.OperatorAnalytic;
import com.mindtree.dto.OperatorDTO;
import com.mindtree.entity.Administrator;

public interface OperatorService {

	public List<Administrator> getOperatorList();
	public Administrator addNewOperator(OperatorDTO dto);
	public List<OperatorAnalytic> getOperatorAnalytic();
}
