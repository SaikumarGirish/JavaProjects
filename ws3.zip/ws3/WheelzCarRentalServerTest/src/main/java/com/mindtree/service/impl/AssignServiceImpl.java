package com.mindtree.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.AssignDao;
import com.mindtree.dto.AssignDriver;
import com.mindtree.service.AssignService;

@Service
@Transactional
public class AssignServiceImpl implements AssignService
{

	@Autowired
	private AssignDao asdDao;
	

	@Transactional

	public boolean get(AssignDriver detail)
	{
		asdDao.get(detail);
		return true;
		
	}

}
