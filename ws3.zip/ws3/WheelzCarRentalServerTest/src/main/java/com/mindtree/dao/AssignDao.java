package com.mindtree.dao;

import com.mindtree.dto.AssignDriver;

public interface AssignDao {

	public boolean get(AssignDriver detail);

}
