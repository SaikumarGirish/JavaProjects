package com.mindtree.service.impl;

import com.mindtree.service.MyRidesService;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.MyRidesDao;
import com.mindtree.dto.ChangeDestination;
import com.mindtree.dto.UpdateUpcoming;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Locations;

@Service
@Transactional
public class MyRidesServiceImpl implements MyRidesService{
	@Autowired
	MyRidesDao myRidesDao;
	
	//calling method of dao to get past rides of a user
	@Transactional
	@Override
	public List<Booking> getPastRides(int uId){
		List<Booking> result = 	myRidesDao.pastRides(uId);
		Collections.reverse(result);
		return result;
	}

	//calling method of dao to get ongoing rides of a user
	@Transactional
	@Override
	public List<Booking> getOngoingRides(int uId) {
		List<Booking> result = myRidesDao.ongoingRides(uId);
		Collections.reverse(result);
		return result;
	}
	//calling method of dao to get upcoming rides of a user
	@Transactional
	@Override
	public List<Booking> getUpcomingRides(int uId) {
		return myRidesDao.upcomingRides(uId);
	}

	//calling method of dao to get all locations
	@Transactional
	@Override
	public List<Locations> getAllLocation() {
		return myRidesDao.getlocations();
	}
	//calling method of dao to change destination of given ongoing ride
	@Transactional
	@Override
	public List<Booking> changeDestination(ChangeDestination changeDestObj) {
		return myRidesDao.changingDestination(changeDestObj);
	}
	//calling method of dao to delete a given upcoming ride
	@Transactional
	@Override
	public List<Booking> deleteService(int id) {
		return myRidesDao.deleteDao(id);
	}
	//calling method of dao to update pickup and drop location of a given upcoming ride
	@Transactional
	@Override
	public List<Booking> updateUpcomingService(UpdateUpcoming updateObj, String pickUp) {
		return myRidesDao.updateUpcomingDao(updateObj,pickUp);
	}

}
