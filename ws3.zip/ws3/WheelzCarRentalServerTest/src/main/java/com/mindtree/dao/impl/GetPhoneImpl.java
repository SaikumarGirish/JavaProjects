package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.GetPhone;
@Repository
public class GetPhoneImpl implements GetPhone{

	@Autowired
	 private SessionFactory sessionFactory;
	@Transactional
	public List getPhone() {
		 
//		SessionFactory s = new Configuration().configure().buildSessionFactory();
		   
//					Session session = s.openSession();
//					session.beginTransaction();
//					String hql="select phoneNumber from User";
//					Query query = session.createQuery(hql);
//					 List phonelList =   ( List) query.list();
//					session.getTransaction().commit();
//					session.close();
//					s.close();
		Query query= sessionFactory.getCurrentSession().createQuery("select phoneNumber from User");
		ArrayList phone=(ArrayList) query.list();
		return phone;
					
				} 
	}

 
