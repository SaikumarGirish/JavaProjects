package com.mindtree.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.AssignDriver;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;
import com.mindtree.service.AssignRideService;
import com.mindtree.service.impl.AssignRideSeriveImpl;

@RestController
public class AssignRideController {
 	@Autowired
 	AssignRideService assignRideSeriveImpl;
	 
	@RequestMapping(value = "/assignRide", method = RequestMethod.POST)
	public List<Booking> assignRide(@RequestBody AssignDriver driver)
	{		 
		 
		List<Booking> assign=assignRideSeriveImpl.assignRide(driver);
		if(assign.isEmpty())
		{
			return Collections.emptyList();
		}
		 
		  return assign;
	}
	@RequestMapping(value = "/startRide", method = RequestMethod.POST)
	public boolean startRide(@RequestBody AssignDriver driver)
	{
		 
		return  assignRideSeriveImpl.startRide(driver);
		 
	}
	@RequestMapping(value = "/endRide", method = RequestMethod.POST)
	public boolean endRide(@RequestBody AssignDriver driver)
	{
		 
		return assignRideSeriveImpl.endRide(driver);
		 
	}
	
	@RequestMapping(value = "/costRide", method = RequestMethod.POST)
	public boolean costRide(@RequestBody AssignDriver driver)
	{
		 
		return assignRideSeriveImpl.costRide(driver);
		 
	}
}
