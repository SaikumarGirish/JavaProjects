package com.mindtree.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.OperatorAnalytic;
import com.mindtree.dao.GetCredentials;
import com.mindtree.dto.OperatorDTO;
import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.Userexception;
import com.mindtree.service.CalculateCost;
import com.mindtree.service.OperatorService;

@RestController
public class AdminController {
	@Autowired
	CalculateCost calculateCost;
	@Autowired
	GetCredentials getCredential;
	@Autowired
	OperatorService operator;
	/*This method is used to delete a operator from the data base i.e, change the administrator
	 * delete status from zero to one*/
	@RequestMapping(value = "deleteOperator/{id}", method = RequestMethod.GET)
	public boolean deleteOperator(@PathVariable("id") int id){
		return calculateCost.deleteOperator(id);
	}
	
	@RequestMapping(value = "/getOperatorList", method = RequestMethod.GET)
	public List<Administrator> getOperatorList(){
		return operator.getOperatorList();
	}
	
	//Adding new operator to the database
	@RequestMapping(value = "/addNewOperator", method = RequestMethod.POST)
	public Administrator addNewOperator(@RequestBody OperatorDTO dto){
		System.out.println(dto);
		return operator.addNewOperator(dto);
	}
	
	@RequestMapping(value = "/getOperatorAnalytic", method = RequestMethod.GET)
	public List<OperatorAnalytic> getOperatorAnalytic(){
		return operator.getOperatorAnalytic();
	}
	@RequestMapping(value = "removeUser/{id}", method = RequestMethod.GET)
	public boolean removeUser(@PathVariable("id") long id) throws Userexception{
		return  this.getCredential.removeuser(id);
	}
	
}
