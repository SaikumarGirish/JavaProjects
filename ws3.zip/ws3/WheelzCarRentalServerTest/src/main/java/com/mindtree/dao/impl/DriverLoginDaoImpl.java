package com.mindtree.dao.impl;

import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.DriverLoginDao;
import com.mindtree.entity.Driver;

@Repository
public class DriverLoginDaoImpl implements DriverLoginDao{
	@Autowired
	SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Driver> getDriverList() {
		try{
		String hqlQuery = "from Driver where driverDeleteStatus = 0";
		 Query query =sessionFactory.getCurrentSession().createQuery(hqlQuery);
		 return query.list();
		}catch(Exception e){
			return Collections.emptyList();
		}
		
	}

	

}
