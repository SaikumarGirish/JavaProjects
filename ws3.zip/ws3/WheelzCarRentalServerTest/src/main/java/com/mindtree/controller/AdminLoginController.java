package com.mindtree.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.AdministratorNotFoundException;
import com.mindtree.service.AdminLoginService;

@RestController
public class AdminLoginController {
	
	@Autowired
	private AdminLoginService adminLogin;
	
	@ResponseBody
	@RequestMapping(value="/adminLogin", method=RequestMethod.POST)
	public List<Administrator> aminLogin(@RequestBody Administrator admin) {
		try {
			return adminLogin.setOperator(admin);
			
		} catch (AdministratorNotFoundException e) {
			return Collections.emptyList();
		}
	}
}
