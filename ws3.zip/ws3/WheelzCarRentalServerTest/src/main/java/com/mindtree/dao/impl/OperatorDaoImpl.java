package com.mindtree.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.OperatorDao;
import com.mindtree.dto.OperatorAnalytic;
import com.mindtree.entity.Administrator;

@Repository
public class OperatorDaoImpl implements OperatorDao {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public Administrator addNewOperator(Administrator operator) {
		sessionFactory.getCurrentSession().saveOrUpdate(operator);
		List<Administrator> list = sessionFactory.getCurrentSession()
				.createQuery("from Administrator where email='" + operator.getEmail() + "'").list();
		return list.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OperatorAnalytic> getOperatorAnalytic() {
		List<OperatorAnalytic> list = sessionFactory.getCurrentSession()
				.createSQLQuery("select a.administratorName name,count(b.administrator_administratorId) BookingCount "
						+ "from administrator a join booking b on a.administratorId=b.administrator_administratorId where a.authority=0 group by a.administratorId")
				.list();
		return list;
	}
}

// select a.administratorName name,count(b.administrator_administratorId)
// BookingCount from administrator a join booking b on
// a.administratorId=b.administrator_administratorId where a.authority=0 group
// by a.administratorId;