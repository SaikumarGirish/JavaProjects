package com.mindtree.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.GetFreeDriverDao;
import com.mindtree.dao.impl.GetFreeDriverImpl;
import com.mindtree.entity.Driver;
import com.mindtree.service.GetFreeDriverService;

@Service
@Transactional
public class GetFreeDriverServiceImpl implements GetFreeDriverService {
	@Autowired
	GetFreeDriverDao get;
	
	@Override
	@Transactional
	public List<Driver> getFreeDrivers() {
		return get.getFreeDrivers();
		
	}

}
