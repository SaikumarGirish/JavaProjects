package com.mindtree.dao;


import java.util.List;

import com.mindtree.dto.DriverChart;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.entity.Route;
import com.mindtree.entity.User;
import com.mindtree.exceptions.Userexception;

public interface GetCredentials {
	
	
	public List<Locations> getLocations();
	public List<User> getUsers();
	public List<Driver> getDrivers();
	public List<Administrator> getOperators();
	public Route getRoute(int pickUpLocation, int dropLocation);
	public User getUser(String email);
	public boolean deleteOperator(int id);
	public boolean removeuser(long id) throws Userexception;
	public List<DriverChart> getDriverCount();

}
