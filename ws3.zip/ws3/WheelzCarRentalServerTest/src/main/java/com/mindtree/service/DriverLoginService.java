package com.mindtree.service;

import com.mindtree.entity.Driver;

public interface DriverLoginService {
	public Driver validateDriver(Driver driver);
}
