package com.mindtree.dao.impl;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.GetFreeDriverDao;
import com.mindtree.entity.Driver;


@Repository
public class GetFreeDriverImpl implements GetFreeDriverDao {
	
	@Autowired
	SessionFactory sessionFactory;
	@Override
	public List<Driver> getFreeDrivers() {
			
		
		try{
		
			List<Driver> driverList = sessionFactory.getCurrentSession().createQuery("from Driver where driverRidingStatus=0 and driverDeleteStatus=0").list();
		
		return driverList;
		}
		finally{
			
		}
	}

}
