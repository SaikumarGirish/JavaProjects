package com.mindtree.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.AssignRideDao;
import com.mindtree.dto.AssignDriver;
import com.mindtree.entity.Booking;
import com.mindtree.service.AssignRideService;
 
@Service
@Transactional
public class AssignRideSeriveImpl implements AssignRideService{

	@Autowired 
	AssignRideDao assignRide;
 
	@Override
	public List<Booking> assignRide(AssignDriver driver) {
		   
		List<Booking> ride= assignRide.assignRide(driver.getDriverId());
	 
		return ride;
	}
	@Override
	public boolean startRide(AssignDriver driver) {
		 
		return assignRide.startRide(driver.getDriverId());
	}
	@Override
	public boolean endRide(AssignDriver driver) {
		 
		return assignRide.endRide(driver.getDriverId());
	}
	@Override
	public boolean costRide(AssignDriver driver) {
		 
		return assignRide.costRide(driver.getBookingId());
	}

}
