package com.mindtree.dao;

 

import com.mindtree.entity.User;

public interface AddCredential {
	public User addUser(User user);
	public User checkUser(User gmailuser);
}
