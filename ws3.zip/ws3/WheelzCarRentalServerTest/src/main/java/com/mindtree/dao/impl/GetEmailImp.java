package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.GetEmail;
@SuppressWarnings("unchecked")
@Repository
public class GetEmailImp implements GetEmail{
//	SessionFactory s = new Configuration().configure().buildSessionFactory();
	@Autowired
	 private SessionFactory sessionFactory;
   public  List<String> getEmail(){
//			Session session = s.openSession();
//			session.beginTransaction();
//			String hql="select email from User where ";
//			Query query = session.createQuery(hql);
//			ArrayList<String> emailList =   (ArrayList<String>) query.list();
//			session.getTransaction().commit();
//			session.close();
//			s.close();
	        Query query= sessionFactory.getCurrentSession().createQuery("select email from User");
			ArrayList email=(ArrayList) query.list();
			return email;
			
		}
	}
