package com.mindtree.dao.impl;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.AddNewDriverDao;
import com.mindtree.dto.AddNewDriverDto;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;

@Repository
public class AddNewDriverDaoImpl implements AddNewDriverDao{
	
	@Autowired
	SessionFactory sessionFactory;

	
	@SuppressWarnings("unchecked")
	@Override
	//adding a new driver by acception details of driver to be added
	public List<Driver> addDriverDao(AddNewDriverDto addNewDriverObj) {
		System.out.println("add driver dao");
		try{
		List<Administrator> adminList = sessionFactory.getCurrentSession().createQuery("from Administrator where administratorId='" + addNewDriverObj.getAdministratorId()+ "'").list();
		Administrator admin = adminList.get(0);
		Driver driver = new Driver();System.out.println(1);
		driver.setAddress(addNewDriverObj.getAddress());System.out.println(1);
		driver.setAdministrator(admin);
		driver.setAge(addNewDriverObj.getAge());
		driver.setCarNumber(addNewDriverObj.getCarNumber());
		driver.setDriverDeleteStatus(addNewDriverObj.getDriverDeleteStatus());
		driver.setDriverName(addNewDriverObj.getDriverName());
		driver.setDriverRidingStatus(addNewDriverObj.getDriverRidingStatus());
		driver.setEmail(addNewDriverObj.getEmail());
		driver.setGender(addNewDriverObj.getGender());
		driver.setLicenceNumber(addNewDriverObj.getLicenceNumber());
		driver.setModelType(addNewDriverObj.getModelType());
		driver.setPassword(addNewDriverObj.getPassword());
		driver.setPhoneNumber(addNewDriverObj.getPhoneNumber());
		driver.setDateOfRegistration(new Date(addNewDriverObj.getDateOfRegistration()));System.out.println(1);
		sessionFactory.getCurrentSession().saveOrUpdate(driver);
		return getDriverDao();
		}catch(Exception e){
			return Collections.emptyList();
		}
	}
	//getting list of all drivers from database
	@SuppressWarnings("unchecked")
	@Override
	public List<Driver> getDriverDao() {
		try{
		return sessionFactory.getCurrentSession().createQuery(" where driverDeleteStatus = 0").list();
		}catch(Exception e){
			return Collections.emptyList();
		}
		
	}
}
