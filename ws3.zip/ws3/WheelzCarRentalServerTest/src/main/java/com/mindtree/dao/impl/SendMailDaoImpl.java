package com.mindtree.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.dto.AssignDriver;
import com.mindtree.dto.MailData;
import com.mindtree.entity.Booking;
import com.mindtree.entity.Driver;

public class SendMailDaoImpl {
//	SessionFactory s = new Configuration().configure().buildSessionFactory();
	/*This method is used to retrieve all the information 
	 * required for sending the mail to the user how has booked the cab,
	 * this will extract driver details who is assigned
	 * and the user email Id for that particular assigned driver*/
	public MailData getDetails(AssignDriver details){
		MailData mailData = new MailData();
//		Session session = s.openSession();
//		session.beginTransaction();
//		Driver driver = session.get(Driver.class, details.getDriverId());
//		session.getTransaction().commit();
//		session.close();
//		 session = s.openSession();
//		session.beginTransaction();
//		Booking booking =  session.get(Booking.class,details.getBookingId());
//		session.getTransaction().commit();
//		session.close();
//		mailData.setCarNumber(driver.getCarNumber());
//		mailData.setDriverName(driver.getDriverName());
//		mailData.setDriverNumber(driver.getPhoneNumber());
//		mailData.setUserEmail(booking.getUser().getEmail());
//		mailData.setCost(booking.getCost());
//		mailData.setDistance(booking.getRoute().getDistance());
//		mailData.setName(booking.getUser().getUserName());
//		s.close();
		return mailData;
	}
}
