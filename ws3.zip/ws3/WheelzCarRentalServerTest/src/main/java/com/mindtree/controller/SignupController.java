package com.mindtree.controller;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.dto.Gmaildata;
import com.mindtree.entity.User;
import com.mindtree.service.GetEmailService;
import com.mindtree.service.GetPhoneService;
import com.mindtree.service.LoginService;
import com.mindtree.service.impl.GetEmailServiceImpl;
import com.mindtree.service.impl.GetPhoneSErviceImpl;


@RestController
public class SignupController {
     @Autowired
	 LoginService longinService ;
     @Autowired
     GetEmailService getEmailService;
     @Autowired
     GetPhoneService getPhoneService ;
 
	
	@RequestMapping(value = "/")
	public ModelAndView start(ModelAndView model){
		model.setViewName("index");
		return model;
	}
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	
	//Saving data to the database after signup
	public User getSignData(@RequestBody User user) {
		return longinService.addUser(user);
	}
	 /*getting data from google login which include name and email and stores the
	data in database if it is new user*/
	@RequestMapping(value = "/gmail", method = RequestMethod.POST)
	public User gmaildata(@RequestBody Gmaildata user)
	{
		 
		return this.longinService.checkUser(user );
		
	}
	
	@RequestMapping(value = "/allEmail", method = RequestMethod.GET)
	//Return All user's EmailId Exist in Database
	public List getEmailList() {
		
		
		
		return getEmailService.getEmail();
		
	}
	
	
	
	@RequestMapping(value = "/allPhone", method = RequestMethod.GET)
	//Return All user's PhoneNo Exist in Database
	public List getPhonelList() {
		 
		return  getPhoneService.getPhone();
		
	}
	 
}
