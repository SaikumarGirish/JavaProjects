package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Driver;

public interface GetFreeDriverDao {
	
	public List<Driver> getFreeDrivers();


}
