package com.mindtree.dao.impl;

 
import java.util.ArrayList;
import java.util.List;


import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.GetCredentials;
import com.mindtree.dto.DriverChart;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.Driver;
import com.mindtree.entity.Locations;
import com.mindtree.entity.Route;
import com.mindtree.entity.User;
import com.mindtree.exceptions.Userexception;

@Repository
@Transactional
public class GetCredentialsImpl implements GetCredentials {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public List<User> getUsers() {
 
		Query query = sessionFactory.getCurrentSession().createQuery("from User");
		ArrayList<User> userList = (ArrayList<User>) query.list();
		System.out.println(userList);
		return userList;
  
	}

	@SuppressWarnings("unchecked")
	public List<Driver> getDrivers() {
		return sessionFactory.getCurrentSession().createQuery("from Driver").list();
	}

	@SuppressWarnings("unchecked")
	public List<Administrator> getOperators() {
		return sessionFactory.getCurrentSession().createQuery("from Administrator where administratorDeleteStatus = 0 and authority = 0").list();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Locations> getLocations() {
		return sessionFactory.getCurrentSession().createQuery("from Locations").list();
	}

	@SuppressWarnings("unchecked")
	public Route getRoute(int pickUpLocation, int dropLocation) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("from Route where fromLocation_locationId=? and toLocation_locationId=?");
		query.setParameter(0, pickUpLocation);
		query.setParameter(1, dropLocation);
		ArrayList<Route> routeList = (ArrayList<Route>) query.list();
		return routeList.get(0);
	}

	@SuppressWarnings("unchecked")
	public User getUser(String email) {
		Query query = sessionFactory.getCurrentSession().createQuery("from User where email=?");
		query.setParameter(0, email);
		ArrayList<User> userList = (ArrayList<User>) query.list();

		return userList.get(0);
	}
	@Override
	public boolean deleteOperator(int id){
		Administrator administrator =(Administrator) sessionFactory.getCurrentSession().get(Administrator.class,id);
		administrator.setAdministratorDeleteStatus(1);
		sessionFactory.getCurrentSession().update(administrator);
		return true;
	}

	 
	@Override
	@Transactional
	public boolean removeuser(long id) throws Userexception {
		try{ 
		User user=(User) sessionFactory.getCurrentSession().get(User.class,id);
		if(user.getUserDeleteStatus()==0)
		user.setUserDeleteStatus(1);
		else
			user.setUserDeleteStatus( 0);
		sessionFactory.getCurrentSession().update( user);
		}
		catch(Exception e)
		{
			throw new Userexception("remove user failed",e);
		}
		return true;
	}

	@Override
	@Transactional
	@SuppressWarnings("unchecked")
	public List<DriverChart> getDriverCount() {
	ArrayList<DriverChart> list = (ArrayList<DriverChart>) sessionFactory.getCurrentSession().createSQLQuery("SELECT COUNT(*) as count, driverName as driver, SUM(cost) as cost from Booking b join driver d ON b.driver_driverId = d.driverId GROUP BY driver_driverId").list();
	return list;
	}
	

}
