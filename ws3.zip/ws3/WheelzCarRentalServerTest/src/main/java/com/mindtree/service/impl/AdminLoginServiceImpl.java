package com.mindtree.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.AdminLoginDao;
import com.mindtree.entity.Administrator;
import com.mindtree.exceptions.AdministratorNotFoundException;
import com.mindtree.service.AdminLoginService;

@Service
@Transactional
public class AdminLoginServiceImpl implements AdminLoginService {
	
	@Autowired
	private AdminLoginDao adminLogin;

	@Override
	@Transactional
	public List<Administrator> setOperator(Administrator admin) throws AdministratorNotFoundException {
		return adminLogin.setOperator(admin);
		
	}

}
