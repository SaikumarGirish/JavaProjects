package com.mindtree.dao;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.mindtree.dto.Userchart;
import com.mindtree.entity.Booking;

public interface GetBookings {

	List<Booking> getBooking();

	List<Booking> getBook();

	long getEarnings(int dId, Date fromDate, Date endDate) throws ParseException;

	List<Booking> pastTrips(int dId);

	List<Userchart> getchart();
}
