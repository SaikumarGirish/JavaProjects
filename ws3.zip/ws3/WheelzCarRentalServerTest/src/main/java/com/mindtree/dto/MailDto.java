package com.mindtree.dto;

public class MailDto {
	
	String fromLocation;
	String toLocation;
	String payment;
	

}
