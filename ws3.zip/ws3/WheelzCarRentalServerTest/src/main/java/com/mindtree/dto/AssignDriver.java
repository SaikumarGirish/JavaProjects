package com.mindtree.dto;

import java.util.Date;

public class AssignDriver {
	

	private int bookingId;
	private int administratorId;
	private int driverId;
	private Date driverAssignTime;
	
	
	public Date getDriverAssignTime() {
		return driverAssignTime;
	}
	public void setDriverAssignTime(Date driverAssignTime) {
		this.driverAssignTime = driverAssignTime;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getAdministratorId() {
		return administratorId;
	}
	public void setAdministratorId(int administratorId) {
		this.administratorId = administratorId;
	}
	public int getDriverId() {
		return driverId;
	}
	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}
	
	
	
	
	
}
