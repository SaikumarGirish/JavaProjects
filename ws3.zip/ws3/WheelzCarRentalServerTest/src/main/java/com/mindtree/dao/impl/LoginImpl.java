package com.mindtree.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.Login;
import com.mindtree.entity.Administrator;
import com.mindtree.entity.User;
import com.mindtree.exceptions.OperatorNotFoundException;
import com.mindtree.exceptions.UserNotFoundException;


@Repository
public class LoginImpl implements Login

{
	@Autowired
	SessionFactory sessionFactory;


	@Override
	public User check(User u) throws UserNotFoundException
	{
		String checkUser= " ";
		String checkPass = " ";
		User emailId = null ;
		
		try {

			List<User> list  = sessionFactory.getCurrentSession().createQuery("from User where userDeleteStatus=0 AND Email='" + u.getEmail() + "'").list();
			
			for (User o : list) {
				checkUser = o.getEmail();
				checkPass = o.getPassword();
				emailId = o;
			}
			
		} catch (NullPointerException e) {
			throw new UserNotFoundException("User Not Found");
		}
	

			if ((checkUser.equalsIgnoreCase(u.getEmail())) && checkPass.equals(u.getPassword())) {
				return emailId;
			} else {
				return null;
			}

		
	}

	@Override
	public List<Administrator> operatorLogin(Administrator a) throws OperatorNotFoundException {

		String findEmail= " ";
		String findPass = " ";
		Query query=sessionFactory.getCurrentSession().createQuery("from Administrator where Email= ? and administratorDeleteStatus = 0");
		query.setParameter(0,a.getEmail());
		List<Administrator> list=query.list();

 		try {
 			for (Administrator i : list) {
 				findEmail = i.getEmail();
 				findPass = i.getPassword();
 			}
 		} catch (NullPointerException ex) {
 			throw new OperatorNotFoundException();
 		}
 		
 		if (!(list.isEmpty())&&(findEmail.equalsIgnoreCase(a.getEmail())) && findPass.equals(a.getPassword())) {
			return list;
 		} else {
 			return Collections.emptyList();
 		}

	}


}
