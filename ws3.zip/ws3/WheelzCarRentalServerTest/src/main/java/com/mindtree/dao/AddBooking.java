package com.mindtree.dao;

import com.mindtree.entity.Booking;

public interface AddBooking {
	public Booking addNewBooking(Booking booking);
}
