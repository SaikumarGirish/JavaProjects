package com.mindtree.dao.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;

import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.dao.GetBookings;
import com.mindtree.dto.Userchart;
import com.mindtree.entity.Booking;

@Repository
public class GetBookingsImpl implements GetBookings {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Booking> getBooking() {

		try {
			List<Booking> bookingList = sessionFactory.getCurrentSession()
					.createQuery("from Booking b where b.driver.driverId is null").list();

			return bookingList;
		} finally {

		}
	}

	/*
	 * This method is used to get all the bookings done by the driver and
	 * sending to driver to view
	 */

	@Override
	public List<Booking> pastTrips(int dId) {

		System.out.println(dId);

		Query quer1 = sessionFactory.getCurrentSession()
				.createQuery("from Booking B where B.bookingStatus=? and driver_driverId=?");
		 quer1.setParameter(0, 2);
		 quer1.setParameter(1,dId);
		return (List<Booking>) quer1.list();

	}

	/*
	 * This method is used to get the earnings done by the user and sending to
	 * the driver
	 */

	@Override
	public long getEarnings(int dId, Date fromDate, Date endDate) throws ParseException {
		
			DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			
			 String start = inputFormat.format(fromDate); 
			 String end = inputFormat.format(endDate); 
			
			
			 Date from = inputFormat.parse(start);
			 Date to = inputFormat.parse(end);
			 System.out.println(from);
			 System.out.println(to);
			 try{
			Query quer2 = sessionFactory.getCurrentSession().createQuery(
					"select sum(cost) from Booking where bookingStatus=? AND timeOfBooking >=? AND timeOfBooking <=? AND  driver_driverId=?");
			
			quer2.setParameter(0, 2);
			quer2.setParameter(1, to);
			quer2.setParameter(2, from);
			quer2.setParameter(3, dId);
			long earn = (long) quer2.uniqueResult();
			return earn;
			 }
			 catch(NullPointerException e)
			 {
				 return 0;
			 }
		
	}

	@Override
	public List<Booking> getBook() {
		try {
			List<Booking> bookingList = sessionFactory.getCurrentSession()
					.createQuery("from Booking").list();
			 
			return bookingList;
		} finally {

		}
	
	}

	@Override
	public List<Userchart> getchart() {
		 try{
			 List<Userchart> bookingList=sessionFactory.getCurrentSession().createQuery("select timeOfBooking,scheduleTime from Booking").list();
			 System.out.println(bookingList);
			  return bookingList;
			 
		 } finally{
			 
		 }
	}

}
