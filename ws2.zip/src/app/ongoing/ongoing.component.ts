import { Component, OnInit } from '@angular/core';
import { MyrideService } from '../myride.service';

@Component({
  selector: 'app-ongoing',
  templateUrl: './ongoing.component.html',
  styleUrls: ['./ongoing.component.css']
})

export class OngoingComponent implements OnInit {
  load:boolean;
public resultSet;
public userId = 0;
// tslint:disable-next-line:semicolon
public bookId;
public locations;
public ongoingRec;
public n: string;
public date;
public count;
public emptyDiv = false;
public empty = false;
load1 : boolean;
public updateinfo= {
'bookingId': 0 ,
'location': ''
};
  constructor(private service: MyrideService) {
    this.load1 = true;

   }

  ngOnInit() {

    this.getData();
    this.getLocation();
  }

 getData(): void {
 this.userId = JSON.parse(localStorage.getItem('userId'));
   console.log('get ongoing');
    this.service.getOngoing(this.userId).subscribe((data) => {
      this.load1 = false;
      this.resultSet = data;
      this.count = Object.keys(this.resultSet).length;
      if(this.count === 0) {
          this.empty = true;
      }
      else {
        this.emptyDiv = true;
for (const result of this.resultSet) {
          if (result.wayOfPayment === 0) {
            result.wayOfPayment = 'cash';
            console.log(result.wayOfPayment);
          }
          if (result.wayOfPayment === 1) {
            result.wayOfPayment = 'paytm';
            console.log(result.wayOfPayment);
          }
          console.log(result.timeOfBooking);
          this.date = (new Date(result.timeOfBooking)).toString();
          console.log(this.date.substring(0,24));
          result.timeOfBooking = this.date.substring(3,24); 
      }
      }

    }
    ,
        err => {
     this.load1 = false;
     console.log(this.load1);
     alert("Connection problem..Please try again");
     console.log(this.load1);
     
   }
    );


  }

   getLocation(): void {
    this.service.getLocations().subscribe((data2) => {
      this.locations = data2;
      console.log(this.locations);

    });


  }
  changeDestStart() {
     this.load = true;
     this.load1 = false;
    this.updateinfo.bookingId = this.resultSet[0].bookingId;
    this.updateinfo.location = this.n;
    if(this.resultSet[0].route.fromLocation.location === this.n){
      alert("pickup and drop location should be different");
      this.load = false;
    }
    else{
    this.changeDest(this.updateinfo);
    }
    
  }
  changeDest(updateObj) {
    this.service.changeDestination(updateObj).subscribe((data2) => {
       // tslint:disable-next-line:quotemark
       this.load = false;
       this.load1 = false;
      this.resultSet = data2;
      this.count = Object.keys(this.resultSet).length;
      if(this.count === 0) {
          this.empty = true;
      }
      else{
        this.empty = false;
    for (const result of this.resultSet) {
          if (result.wayOfPayment === 0) {
            result.wayOfPayment = 'cash';
            console.log(result.wayOfPayment);
          }
          if (result.wayOfPayment === 1) {
            result.wayOfPayment = 'paytm';
            console.log(result.wayOfPayment);
          }
          console.log(result.timeOfBooking);
          this.date = (new Date(result.timeOfBooking)).toString();
          console.log(this.date.substring(0,24));
          result.timeOfBooking = this.date.substring(3,24); 
      }
      }
    },
        err => {
     this.load = false;
     console.log(this.load);
     alert("connection problem..Please try again");
     console.log(this.load);
     
   }
    );
    
  }

}
