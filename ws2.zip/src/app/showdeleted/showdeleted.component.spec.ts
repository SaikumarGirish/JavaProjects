import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowdeletedComponent } from './showdeleted.component';

describe('ShowdeletedComponent', () => {
  let component: ShowdeletedComponent;
  let fixture: ComponentFixture<ShowdeletedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowdeletedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowdeletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
