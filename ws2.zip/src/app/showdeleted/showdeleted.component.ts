import { Component, OnInit } from '@angular/core';
import { MyrideService } from '../myride.service';

@Component({
  selector: 'app-showdeleted',
  templateUrl: './showdeleted.component.html',
  styleUrls: ['./showdeleted.component.css']
})
export class ShowdeletedComponent implements OnInit {
public resultSet;
public userId= 0;
  constructor(private service: MyrideService) { }

  ngOnInit() {
    this.getData();
  }
 getData(): void {
   this.userId = this.service.usersId;
    this.service.getShowDeleted(this.userId).subscribe((data) => {
      this.resultSet = data;
      console.log(this.resultSet);

    });


}
}
