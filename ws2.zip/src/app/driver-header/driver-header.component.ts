import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-header',
  templateUrl: './driver-header.component.html',
  styleUrls: ['./driver-header.component.css']
})
export class DriverHeaderComponent implements OnInit {

 name: string;

  driverName: string;
  constructor() {
    if (localStorage.getItem('driverId')) {
      this.driverName = (localStorage.getItem('driverName'));
    }
     

  }

  ngOnInit() {
  }
  logout() {
    localStorage.clear();
    
  }
lo(){
  window.location.reload();
}
}
