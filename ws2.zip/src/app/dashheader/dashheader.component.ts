import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashheader',
  templateUrl: './dashheader.component.html',
  styleUrls: ['./dashheader.component.css']
})
export class DashheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
