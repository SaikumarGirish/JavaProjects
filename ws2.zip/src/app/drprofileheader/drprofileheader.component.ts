import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drprofileheader',
  templateUrl: './drprofileheader.component.html',
  styleUrls: ['./drprofileheader.component.css']
})
export class DrprofileheaderComponent implements OnInit {

   driverName: string;
  constructor() { 
     if (localStorage.getItem('driverId')) {
      this.driverName = (localStorage.getItem('driverName'));
     }
  }

  ngOnInit() {
  }
  logout() {
    localStorage.clear(); 
  }

}
