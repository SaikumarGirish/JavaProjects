import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DrprofileheaderComponent } from './drprofileheader.component';

describe('DrprofileheaderComponent', () => {
  let component: DrprofileheaderComponent;
  let fixture: ComponentFixture<DrprofileheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DrprofileheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DrprofileheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
