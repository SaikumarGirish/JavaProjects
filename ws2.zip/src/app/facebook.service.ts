import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { WheelzserviceService } from './wheelzservice.service';
import { Location } from '@angular/common';

declare const FB: any;


@Injectable()


export class FacebookService {
  returnUser: any;

  user = {
    'name': '',
    'email': '',
    'gender': ''
  };

  // tslint:disable-next-line:no-shadowed-variable
  constructor(private httpClient: HttpClient, private router: Router, private wheelsService: WheelzserviceService,private location:Location) { }

  initial() {
    FB.init({
      appId: '514062125633450', // main app
      cookie: false,
      xfbml: true,  // parse social plugins on this page
      version: 'v2.5' // use graph api version 2.5
    });

    FB.getLoginStatus(response => {
      this.statusChangeCallback(response);
    });
  }


  statusChangeCallback(response: any) {
    if (response.status === 'connected') {
    } else {

    }
  }

  login() {
    const self = this;
    FB.login(function (response) {
      if (response.status === 'connected') {
        // Logged into your app and Facebook.
        self.me();
        self.router.navigate(['booking']);
        console.log('successfully logged in');
      }
    });
  }

  logout() {
    console.log('trying to logout');
    FB.logout(function (response) {
    });
  }

  me() {
    const self = this;
    FB.api('/me?fields=name,email,gender',
      function (result) {
        if (result && !result.error) {
          self.user.name = result.name;
          self.user.email = result.email;
          self.user.gender = result.gender;
          localStorage.setItem('email', result.email);
          localStorage.setItem('userName', result.name);
          const returnuser = self.httpClient.post(self.wheelsService.ROOT_URL + '/fblogin', self.user).subscribe(
            returnUser => {
              this.returnUser = returnUser;
              if(this.returnUser!=null){
                  window.location.reload();
              }
              console.log(returnUser);
              localStorage.setItem('userId', JSON.stringify(this.returnUser.userId));
            }
          );

        } else {
          console.log(result.error);
        }
      });
  }

}
