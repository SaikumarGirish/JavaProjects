import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WheelzserviceService } from './wheelzservice.service';

@Injectable()
export class AddDriverService {
  private url = this.wheelService.ROOT_URL;
  constructor(private http: HttpClient, private wheelService: WheelzserviceService) { }

getDriver() {
  return this.http.get(this.url+ '/getDriverList');
}

insertData(driverinfo) {
  console.log("service called");
  console.log(driverinfo);
    return this.http.post( this.url+ '/addNewDriver', driverinfo);
}
}