import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { BookingDetailsService } from '../booking-details.service';
import { OperatorService } from "../operator.service";
import {WheelzserviceService} from "../wheelzservice.service";
@Component({
  selector: 'app-assign',
  templateUrl: './assign.component.html',
  styleUrls: ['./assign.component.css']
})


export class AssignComponent implements OnInit {
  fresh: boolean=false;
  refresh: boolean=true;
  item: any;
  i:any;
 butt:boolean;
    ModelType:any;
    url:any;
    success:boolean;
    date:any;
    AdminNo:any;
     checking:boolean;
    assign:boolean;
    resultSet:any;
    resultSetdriver:any;
    check:boolean;
    error:boolean;
    assignTime;
    ass:boolean;
    filterset:any;
    message:string;
    DriverForBooking = {
      'driverId':0,
      'bookingId':0,
      'administratorId':0,
      'driverAssignTime':'',
    }
    // driveId:any;
    //   bookId:any;
    //   operatorId:any;
    constructor(private http:HttpClient,private wheelservice:WheelzserviceService, private car:BookingDetailsService, private service:OperatorService) { 
      this.ModelType=car.bookingDetails.carType;
      // this.AdminNo=admin.adminDetails.adminNo;
      this.assign=false;
      this.check=false;
      this.checking=true;
      this.url=this.wheelservice.ROOT_URL;
      this.error=false;
      this.success=true;
      this.ass=false;
      this.message="Assigning...";
      this.butt=false;
    }
    ngOnInit() {
      this.checking=true; 
     this.assigndriver();
    }
    
    
assigndriver()
{
  this.i=0;
 const result= this.http.get(this.url+'/getbookings').subscribe(
   
     resultSet =>{
       this.resultSet=null;
       
      this.checking=false; 
       this.check=true;
       this.resultSet=resultSet; 
      while(this.resultSet[this.i])
      { 
      this.date = (new Date(resultSet[this.i].timeOfBooking)).toString();
      this. resultSet[this.i].timeOfBooking = this.date.substring(3,24); 
       (this.i)++;
      }
      console.log(this.resultSet);
     
   },
   err => {
     this.checking=false;
     this.error=true;
   }
 )
 const driverresult= this.http.get(this.url+'/freeDrivers').subscribe(
    resultSetdriver =>{
      
      this.resultSetdriver=resultSetdriver;
    }
 )
}
action(driverId, bookId)
{
  
 let flag = false;
    for(let i=0;i<this.resultSet.length;i++){
       
      if(bookId == this.resultSet[i].bookingId){
        flag = true;
        break;
      }
      if(flag == false){
         this.message="Assign unsucessfull";
 this.butt=true; 
this.ass=true;
        alert("Booking Id does not exist in Pending Booking list");
        
          
           return false;
      }
       
    }




   this.message="Assigning...";
 this.butt=false; 
this.ass=true;
this.assignTime = new Date();
this.DriverForBooking.driverAssignTime = this.assignTime;
this.DriverForBooking.bookingId=bookId;
this.DriverForBooking.driverId=driverId;
this.DriverForBooking.administratorId=JSON.parse(localStorage.getItem('operatorId'));
console.log(this.DriverForBooking);
//sending data to the backend for booking to  assign a driver
const assignNewDriver= this.http.post(this.url+'/assign',this.DriverForBooking).subscribe(
    resultSetdriver =>{
 
      this.butt=true; 
  this.message="Driver Assign Successfully...";
 
       this.ass=false;
       this.success=false;
      this.resultSetdriver=resultSetdriver;
     this.assigndriver();
     
    },
    err => {
      
      this.butt=true; 
  this.message="Driver Assign Unsuccessfully...";
      this.assigndriver();
    }
 )

//Displaying Pending-Booking Table And Free Driver Table Again once again
 

}
searchitem()
{
  
   
  
  if(this.item=="")
  {
    
    this.refresh=true;
    this.fresh=false;
  }
  
  this.i=this.item;
     
  for(let k=0;k<this.resultSet.length;k++)
  {
    
    if(this.i==this.resultSet[k].bookingId)
    {
      this.filterset=this.resultSet[k];
        
 
this.refresh=false;
this.fresh=true;
break;
    }
    
     
  }
   
}
}
