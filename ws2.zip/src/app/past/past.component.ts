import { Component, OnInit } from '@angular/core';
import { MyrideService } from '../myride.service';
import { UserloginService } from '../userlogin.service';

@Component({
  selector: 'app-past',
  templateUrl: './past.component.html',
  styleUrls: ['./past.component.css']
})
export class PastComponent implements OnInit {
public resultSet;
public mop: '';
public userId = 0 ;
public load;
public date:any;
public count;
public empty = false;
public emptyDiv = false;
  constructor(private service: MyrideService) {
    this.load = true;
   }

  ngOnInit() {
    this.getData();
  }
   getData(): void {
     // tslint:disable-next-line:member-ordering   
    this.userId = JSON.parse(localStorage.getItem('userId'));
    console.log(this.userId);
    this.service.getPast(this.userId).subscribe((data) => {
       this.load = false;
      this.resultSet = data;

      this.count = Object.keys(this.resultSet).length;
      console.log("length of json " + this.count);
      console.log(this.resultSet);
      if(this.count === 0) {
          this.empty = true;
      }
      else {
      
      for (const result of this.resultSet) {
          if (result.wayOfPayment === 0) {
            result.wayOfPayment = 'cash';
            console.log(result.wayOfPayment);
          }
          if (result.wayOfPayment === 1) {
            result.wayOfPayment = 'paytm';
            console.log(result.wayOfPayment);
          }
          console.log(result.timeOfBooking);
          this.date = (new Date(result.timeOfBooking)).toString();
          console.log(this.date.substring(0,24));
          result.timeOfBooking = this.date.substring(3,24); 
      }
        this.emptyDiv = true;
      }

    }
    ,
     err => {
     this.load = false;
     console.log(this.load);
     alert("Connection problem..Please try again");
     console.log(this.load);
     
   }
    );


  }

}
