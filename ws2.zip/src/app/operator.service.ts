import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Routes, RouterModule, Router } from '@angular/router';
import { WheelzserviceService } from "./wheelzservice.service";
@Injectable()
export class OperatorService {
  operator={
"email":"",
"password":""
}
email:string='';
password:string='';
url:any;
operatorId:any;
operatorName:any; 
load:boolean;
  constructor(private http:HttpClient, private router:Router,private service: WheelzserviceService) {
    this.url=this.service.ROOT_URL;
   }
  getoperatordata():boolean
  {
    this.operator.email=((document.getElementById("email") as HTMLInputElement).value);  
    console.log(this.operator.email);
    this.operator.password=((document.getElementById("password") as HTMLInputElement).value); 
    console.log(this.operator.password);
    const req = this.http.post(this.url+'/oplogin',this.operator)//https://wheelzcarrentalserver.azurewebsites.net/WheelzCarRental/oplogin
  .subscribe(                                   //http://localhost:8080/WheelzCarRental/oplogin   //this.url+'/oplogin'
    res=> {
      if(res[0]){
            this.router.navigate(['/assign']);
            this.operatorId = res[0].administratorId;
            console.log(this.operatorId+"hi");
            this.operatorName = res[0].administratorName;
            console.log(this.operatorName+"hi");
            localStorage.setItem('operatorId',JSON.stringify(this.operatorId));
            localStorage.setItem('opeartorName', (this.operatorName));
             
      }
      else
      {   
          document.getElementById("demo").innerHTML = "Invalid Username/Password";
      }
    },
    err=>{
      console.log("Error Occurs....");
      alert("Connection Error Occurs, Please Try Again....");
    }
  )
  return false;
} 
}



