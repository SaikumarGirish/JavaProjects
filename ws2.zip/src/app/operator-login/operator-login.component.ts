import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from "@angular/forms";
import { OperatorService  } from "../operator.service";

@Component({
  selector: 'app-operator-login',
  templateUrl: './operator-login.component.html',
  styleUrls: ['./operator-login.component.css']
})
export class OperatorLoginComponent implements OnInit {
    rForm: FormGroup;
     email:string='';
     password:string='';
     emailAlert:string="Invalid Email Id";
     passwordAlert:string="Password should be in-between 6 to 14 characters";
     load:boolean;
     ag:boolean;
  constructor(private fb: FormBuilder, private myservice:OperatorService) { 
    this.rForm=fb.group({
      'email': [null,Validators.compose([Validators.required,Validators.pattern("([a-zA-Z0-9_.]{1,})((@[a-zA-Z]{2,})[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))$")])],
      'password': [null,Validators.compose([Validators.required, Validators.maxLength(14),Validators.minLength(6)])],
      'validate': '',
});

  }

  ngOnInit() {
  }
  login()
  {
    this.load=true;
    console.log(this.myservice.getoperatordata());
    this.ag=this.myservice.getoperatordata();
  }
  keyDownFunction(event) {
  if(event.keyCode == 13) {
    this.load=true;
     console.log(this.myservice.getoperatordata());
    this.ag= this.myservice.getoperatordata();
  }
}
  hide()
  {
     this.load=false;
     document.getElementById("demo").innerHTML = "";
  }

}
