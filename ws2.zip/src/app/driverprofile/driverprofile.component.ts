import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WheelzserviceService } from '../wheelzservice.service';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from "@angular/forms";
@Component({
  selector: 'app-driverprofile',
  templateUrl: './driverprofile.component.html',
  styleUrls: ['./driverprofile.component.css']
})
export class DriverprofileComponent implements OnInit {
  url : any;
  member: any = '';
  id: number;
  rForm: FormGroup;
  address: string;
  phonenumber: string;
  password: string;
  confirm : string;
   addressAlert: string="Address field is mandatory: Use only characters"; 
   phonenumberAlert:string="Phone no should be of ten digits";
    passwordAlert:string="Password should be atleast 6 to 14 ";
    confirmAlert:string="It should be same as Password";
    checkpass:boolean=false;
    confirmPassword:string='';
    phonecheck:boolean;
    checkingAddress:string;
    checkingPhone:string; 
     checkingPassword:string;
     alert:boolean;
      confirmppassword:string='';
      load: boolean=false;
      isEnabled : boolean = false;
  constructor(private fb: FormBuilder, private httpClient: HttpClient, public service: WheelzserviceService) { 
    this.url=this.service.ROOT_URL;
   
  }
  ngOnInit() {
    this.getdata();
    this.rForm=this.fb.group({
      //name should would be maximum of 25 charactor only
'address': [null,Validators.compose([Validators.required,Validators.maxLength(25), Validators.pattern("[A-Za-z ]+$")])],
'phonenumber':  [null,Validators.compose([Validators.required,Validators.pattern("[7 8 9][0-9]{9}$")])],
'password': [null,Validators.compose([Validators.required, Validators.maxLength(14),Validators.minLength(6)])],
'confirm': [null, Validators.compose([Validators.required, Validators.maxLength(14),Validators.minLength(6)])],
'validate':'',
});
  }
getdata()
{
     this.id=JSON.parse(localStorage.getItem('driverId'));
     this.httpClient.get(this.url + `/driverProfile/${this.id}`)
    .subscribe(                                                                           //`http://localhost:8080/WheelzCarRental/driverProfile/${this.id}`
      (data: any[]) => {                                                                  //this.url + `/driverProfile/${this.id}`
        if (data.length !== 0) {
          this.member = data;
          this.checkingPhone= this.member.phoneNumber;
          this.checkingAddress= this.member.address;
          this.checkingPassword= this.member.password;
           this.confirmppassword= this.member.password;
        }
        else
        {
           this.load=false;
        }
        
      },
      err=>{
      console.log("Error Occurs....");
      alert("Connection Error Occurs, Please Try Again....");
    }
    );
  
}

  editDriver={
'address':'',
'phoneNumber':'',
'password':''
}

passwordcheck()
{
  if( ((document.getElementById("password") as HTMLInputElement).value) === ((document.getElementById("confirm") as HTMLInputElement).value) )
  {   
    this.alert=false;
  }
  else{
  this.alert=true;
  }
}
update()
{
     this.checkingPhone= this.member.phoneNumber;
     this.checkingAddress= this.member.address;
     this.checkingPassword= this.member.password;
     this.confirmppassword= this.member.password;
}
save(){

    this.load=true;
    this.member.address=this.checkingAddress;
    this.member.phoneNumber=this.checkingPhone;
     this.member.password=this.confirmppassword;

  const post = this.httpClient.post(this.url+'/editDriver', this.member)
  .subscribe(                                       //'http://localhost:8080/WheelzCarRental/editDriver'
                                                     //this.url+'/editDriver'
    res => {      
         if(res){
           this.load=false;
          alert('Saved Successfully');
        }
        else {
          alert('Not Saved Successfully');
        }
    },
     err=>{
       this.load=false;
      console.log("Error Occurs....");
      alert("Connection Error Occurs, Please Try Again....");
    }
  );
  }


}
