import { Injectable } from '@angular/core';
import { AuthService } from 'angular5-social-login';
import { HttpClient } from '@angular/common/http';
import { GoogleLoginProvider } from 'angular5-social-login';
import { Router } from '@angular/router/';
import { WheelzserviceService } from './wheelzservice.service';

@Injectable()
export class GmailService {
  res:any;
  // readonly ROOT_URL='http://wheelzcarrentalserver.azurewebsites.net/WheelzCarRental';

readonly ROOT_URL='http://localhost:8083/WheelzCarRental/';
gmaildata={
  name:"",
  email:""
}
  constructor( private socialAuthService: AuthService,private http:HttpClient,private router:Router,public URL:WheelzserviceService ) {}
  readonly ROOT=this.URL.ROOT_URL;
  public socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == 'google') {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
         
        // Now sign-in with userData
       const idtoken=userData.idToken;
       this.gmaildata.email=userData.email;
       this.gmaildata.name=userData.name;
       localStorage.setItem('email',JSON.stringify( this.gmaildata.email));
       localStorage.setItem('userName',JSON.stringify( this.gmaildata.name));
        this.http.post( this.ROOT+'/gmail',this.gmaildata).subscribe(res=>console.log(res));
        window.location.reload();
          this.router.navigate(['/booking']);
       }
    );


  }
}
