import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignedRideComponent } from './assigned-ride.component';

describe('AssignedRideComponent', () => {
  let component: AssignedRideComponent;
  let fixture: ComponentFixture<AssignedRideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignedRideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedRideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
