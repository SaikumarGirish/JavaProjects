import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import {WheelzserviceService} from "../wheelzservice.service";
@Component({
  selector: 'app-assigned-ride',
  templateUrl: './assigned-ride.component.html',
  styleUrls: ['./assigned-ride.component.css']
})
export class AssignedRideComponent implements OnInit {
url:string;
resultSet:any;
checking:boolean;
startalert:string;
paymentalert:string;
data:boolean;
i:any;
currentUser={
  'name':'',
  'phone':'',
}
  
start:boolean=true;
end:boolean=false;
pay:boolean=false;
date:string;
AssignDriver={
  bookingId:0,
driverId : 0,
administratorId:0,
'driverAssignTime':'',
}
noRide:string;
  constructor(private http:HttpClient,private service:WheelzserviceService) { 
    this.url=this.service.ROOT_URL;
    this.checking=true;
    this.AssignDriver.driverId=JSON.parse(localStorage.getItem('driverId'));
    this.startalert='Wait...';
    this.paymentalert='Wait...';
    this.data=true;
  }

  ngOnInit() {
 this.getAssignRide()
  }
   
getAssignRide()
{
  this.i=0;
  const result = this.http.post(this.url+'/assignRide',this.AssignDriver).subscribe(
  resultSet=>{
      if((Object.keys(resultSet).length)==0){
               this.data=false;
      }
  this.checking=false;
    
   while(resultSet[this.i]){   
       this.date = (new Date(resultSet[this.i].timeOfBooking)).toString();
      resultSet[this.i].timeOfBooking = this.date.substring(3,24); 
       (this.i)++;
      }
  this.resultSet=resultSet;
  console.log(this.resultSet);
 
},
err => {
  
  console.log("No data");
  this.noRide="No Data Found";
  this.checking=false;
  
}
  )
}
startRide()
{
  this.end=true;
  
const result = this.http.post(this.url+'/startRide',this.AssignDriver).subscribe(
  resultSet=>{
   this.startalert="Have a safe journey..."
   this.start=false;
   
},
err => {
  console.log("No data");
  this.noRide="No Data Found";
  this.checking=false;
  
}
  )
}
endRide(){
  this.pay=true;
  
const result = this.http.post(this.url+'/endRide',this.AssignDriver).subscribe(
  resultSet=>{
    this.end=false;
},
err => {
  console.log("No data");
  this.noRide="No Data Found";
  this.checking=false;
}
  )
}
 
payment(){
  console.log(this.resultSet[0].bookingId);
  this.AssignDriver.bookingId=this.resultSet[0].bookingId;
  const result = this.http.post(this.url+'/costRide',this.AssignDriver).subscribe(
  resultSet=>{
  this.paymentalert="Payment successfully updated";
  window.location.reload();
  this.end=false;
  this.getAssignRide();
},
err => {
  console.log("No data");
  this.noRide="No Data Found";
  this.checking=false;
   
}
  )
}
}

