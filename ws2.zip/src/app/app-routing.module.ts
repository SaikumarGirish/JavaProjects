import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { ErrorDisplayComponent } from '../app/error-display/error-display.component';
import { UserLoginComponent } from '../app/user-login/user-login.component';
import { BookingComponent } from '../app/booking/booking.component';
import { FirstSignupComponent } from './first-signup/first-signup.component';
import { OperatorLoginComponent } from '../app/operator-login/operator-login.component';
import { PastComponent } from './past/past.component';
import { OngoingComponent } from './ongoing/ongoing.component';
import { UpcomingComponent } from './upcoming/upcoming.component';
import { ShowdeletedComponent } from './showdeleted/showdeleted.component';
import { DashbodyComponent } from '../app/dashbody/dashbody.component';
import { OperatorBookingComponent } from './operator-booking/operator-booking.component';
import { OperatorDashboardComponent } from '../app/operator-dashboard/operator-dashboard.component';
import { AssignComponent } from './assign/assign.component';
import { UserfeedbackComponent } from './userfeedback/userfeedback.component';
import { RemoveDriverComponent } from './remove-driver/remove-driver.component';
import { AddnewdriverComponent } from './addnewdriver/addnewdriver.component';
import { DashfooterComponent } from '../app/dashfooter/dashfooter.component'
import { PaymentComponent } from './payment/payment.component';
import { UnassignDriverComponent } from './unassign-driver/unassign-driver.component';
import { PastrideComponent } from "./pastride/pastride.component";
import { AuthGuard } from "./AuthGuard";
import { AssignedRideComponent } from "./assigned-ride/assigned-ride.component";
import { DriverLoginComponent } from './driver-login/driver-login.component';
import { DriverprofileComponent } from './driverprofile/driverprofile.component';
import { DashheaderComponent } from "./dashheader/dashheader.component";


const routes: Routes = [
    { path: '', redirectTo: 'dashBoard', pathMatch: 'full' },
    {
        path: 'dashBoard',
        component: DashbodyComponent
    },
    {
        path: 'driverLogin',
        component: 
        (() => {
            return localStorage.getItem('email') ? AssignedRideComponent : DriverLoginComponent;
        })()
    },
    {
        path: 'driverProfile',
        component: 
        (() => {
            return localStorage.getItem('driverId') ? DriverprofileComponent : DriverLoginComponent;
        })()
    },
    {
        path: 'loginPage',

        component:
        (() => {
            return localStorage.getItem('email') ? BookingComponent : UserLoginComponent;
        })()
    },
    {
        path: 'booking',
        //  canActivate: [AuthGuard],
        component:
        (() => {
            return localStorage.getItem('email') ? BookingComponent : UserLoginComponent;
        })()
    },

    {
        path: 'dashfoot',
        component: DashfooterComponent
    },
    {
        path: 'removeDriver',
        component:
        (() => {
            return localStorage.getItem('operatorId') ? RemoveDriverComponent : OperatorLoginComponent;
        })()

    },


    {
        path: 'pasttrip',
        //  canActivate: [AuthGuard],
        component: (() => {
            return localStorage.getItem('driverId') ? PastrideComponent : DriverLoginComponent;
        })()
    },



    {
        path: 'past',
        // canActivate: [AuthGuard],

        component: (() => {
            return localStorage.getItem('userId') ? PastComponent : UserLoginComponent;
        })()

    },
    {
        path: 'ongoing',
        // canActivate: [AuthGuard],
        component:
        (() => {
            return localStorage.getItem('userId') ? OngoingComponent : UserLoginComponent;
        })()
    },
    {
        path: 'assign',
        // opertaorCanActivate : [AuthGuard],
        component: AssignComponent
        //  (() => {
        //      return localStorage.getItem('opeartorName') ? AssignComponent : OperatorLoginComponent;
        //  })()
    },
    {
        path: 'userfeedback',
        //canActivate: [AuthGuard],
        component:
        (() => {
            return localStorage.getItem('email') ? UserfeedbackComponent : UserLoginComponent;
        })()
    },
    {
        path: 'operatorbooking',
        component:
        (() => {
            return localStorage.getItem('operatorId') ? OperatorBookingComponent : OperatorLoginComponent;
        })()
    },
    {
        path: 'upcoming',
        //canActivate: [AuthGuard],
        component:
        (() => {
            return localStorage.getItem('userId') ? UpcomingComponent : UserLoginComponent;
        })()
    },
    {
        path: 'showdeleted',
        //canActivate: [AuthGuard],
        component: ShowdeletedComponent
    },


    {
        path: 'error',
        component: ErrorDisplayComponent
    },

    {
        path: 'signup',
        component:
        (() => {
            return localStorage.getItem('userId') ? BookingComponent : FirstSignupComponent;
        })()
    },
    {
        path: 'oplogin',
        component:
        (() => {
            return localStorage.getItem('opeartorName') ? AssignComponent : OperatorLoginComponent;
        })()
    },
    {
        path: 'opdash',
        component: OperatorDashboardComponent
    },


     {
        path: 'dashheader',
        component: DashheaderComponent
    },

    {
        path: 'payment',
        //canActivate: [AuthGuard],
        component:
        (() => {
            return localStorage.getItem('email') ? PaymentComponent : UserLoginComponent;
        })()
    },
    {
        path: 'unassign',
        component: UnassignDriverComponent
    },

    {
        path: 'addnewdriver',
        component:
        (() => {
            return localStorage.getItem('operatorId') ? AddnewdriverComponent : OperatorLoginComponent;
        })()
    },

    {
        path: 'assignRide',
 
        component: AssignedRideComponent

 
    },

    { path: '**', redirectTo: 'error', pathMatch: 'full' }

];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})
export class FeatureRoutingModule { }
