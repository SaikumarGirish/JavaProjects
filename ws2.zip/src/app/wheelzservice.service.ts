import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Routes, RouterModule, Router } from '@angular/router';

import { UserloginService } from './userlogin.service';

@Injectable()
export class WheelzserviceService {


  signupdata: any;
  emailcheck: boolean;
  postal: any;

  readonly ROOT_URL = 'http://wheelzcarrentalserver.azurewebsites.net/WheelzCarRental';

  user = {
    'userName': '',
    'gender': 0,
    'phoneNumber': '',
    'email': '',
    'password': ''
  }

  upperName: string;

  userdetails = {
    'userName': '',
    'gender': 0,
    'phoneNumber': '',
    'email': '',
  }

  load: boolean;
  constructor(private http: HttpClient, private router: Router) {
  }

  adduser(obj): any {
    this.user = obj;
    this.bookUser();
    // Sending Object Through Api To Save in DataBase
    const post = this.http.post(this.ROOT_URL + '/addUser', this.user)
      .subscribe(
      postal => {
        this.postal = postal;

        this.upperName = (this.postal.userName).charAt(0).toUpperCase() + (this.postal.userName).slice(1);

        //saving userid in local storage
        localStorage.setItem('userId', JSON.stringify(this.postal.userId));
        localStorage.setItem('userName', (this.upperName));
        //can take value from local storage
        // console.log(JSON.parse(localStorage.getItem('userId')));
        if (this.postal) {
          window.location.reload();
          this.router.navigate(['/booking']);

        }
        else {
          this.router.navigate(['/signup']);
        }
      }
      );
  }
  // Assigning Current Value In an Object For Another's Use
  bookUser() {
    this.userdetails.email = this.user.email;
    this.userdetails.userName = this.user.userName;
    this.userdetails.gender = this.user.gender;
    this.userdetails.phoneNumber = this.user.phoneNumber;
    localStorage.setItem('email', this.userdetails.email);
  }
}