import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WheelzserviceService } from '../wheelzservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-driver-login',
  templateUrl: './driver-login.component.html',
  styleUrls: ['./driver-login.component.css']
})
export class DriverLoginComponent implements OnInit {
  public resultSet;
  public load = false;
  public checkingPassword;
  public checkingEmail;
  rForm: FormGroup;
     email: '';
     password: '';
     // tslint:disable-next-line:no-inferrable-types
     emailAlert: string = 'Invalid Email Id';
     // tslint:disable-next-line:no-inferrable-types
     passwordAlert: string='Password should be in-between 6 to 14 characters';

     public driverinfo = {
        'email': '',
        'password': ''
     };

  constructor(private fb: FormBuilder, private http: HttpClient, private wheelService: WheelzserviceService, 
  private router: Router) {
    this.rForm = fb.group({
      // tslint:disable-next-line:max-line-length
      'email': [null, Validators.compose([Validators.required, Validators.pattern("([a-zA-Z0-9_.]{1,})((@[a-zA-Z]{2,})[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))$")])],
      'password': [null,Validators.compose([Validators.required, Validators.maxLength(14),Validators.minLength(6)])],
});
   }

  ngOnInit() {
  }

login(){
    this.load = true;
    this.driverinfo.email = this.checkingEmail;
    this.driverinfo.password = this.checkingPassword;
    console.log(this.driverinfo);
    this.http.post(this.wheelService.ROOT_URL + '/driverLogin' , this.driverinfo)
    .subscribe(
      (data) => {
         this.load=false;
        this.resultSet = data;
        console.log(this.resultSet);
        if (this.resultSet.email === null) {
          alert('You entered a wrong email or password');
        }
         else {
          
           localStorage.setItem('driverEmail',this.driverinfo.email);
           localStorage.setItem('driverId',this.resultSet.driverId);
            localStorage.setItem('driverName',this.resultSet.driverName);
             this.router.navigate(['/assignRide']);
           //to remove from local storage
           //  localStorage.removeItem('driverEmail');
         }
      },
       err => {
     this.load = false;
     alert('connection problem..Please try again');
     console.log(this.load);
   }
    );

  }

}
