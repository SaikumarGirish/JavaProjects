import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule ,HttpTestingController} from '@angular/common/http/testing';
 
import { WheelzserviceService } from './wheelzservice.service';

describe('WheelzserviceService', () => {
  let service: WheelzserviceService;
  let httpMock : HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientTestingModule
      ],
      providers: [WheelzserviceService]
    });
    service = TestBed.get(WheelzserviceService);
    httpMock = TestBed.get(HttpTestingController);
  });
   
it('should retrive posts from the API',() => {

  const testPosts =
    {'userName':'vishal','gender': 0,'phoneNumber':'9988776678','email':'vishalkalinga@gmail.com','password':'123456'}
    // {'userName':'sonali','gender': 1,'phoneNumber':'8788886678','email':'kalinga@gmail.com','password':'Myhsh1'},
    ;
    service.adduser(testPosts).subscribe(posts => {
        
       expect(posts.userName).toEqual('vishal');
    });
 
});
   
});
