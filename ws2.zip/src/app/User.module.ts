export class User {
  name: number;
  email: string;
  gender: string;
}
