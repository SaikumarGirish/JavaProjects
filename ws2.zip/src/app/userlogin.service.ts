import { Injectable } from '@angular/core';
import { MyrideService } from './myride.service';

@Injectable()
export class UserloginService {


userdetails={
    'userName':'',
'gender':0,
'phoneNumber':'',
'email':'',
}


    constructor(private service: MyrideService)
    { }

    sendObj(obj) {


        this.userdetails = obj;
        console.log(this.userdetails);
        console.log(obj.email);
        console.log(obj.userId);
        localStorage.setItem('email', obj.email);
        localStorage.setItem('userId', obj.userId);
        localStorage.setItem('userName', obj.userName);
        this.service.usersId = obj.userId;

    }

    sendObjFromSignUp(obj)
    {  
        
        this.userdetails = obj;
       
    }
}
