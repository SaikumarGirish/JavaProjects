// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { FirstSignupComponent } from './first-signup.component';
// describe('FirstSignupComponent', () => {
//   let component: FirstSignupComponent;
//   let fixture: ComponentFixture<FirstSignupComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ FirstSignupComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(FirstSignupComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
