import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from "@angular/forms";
import { WheelzserviceService } from '../wheelzservice.service';
import { HttpClient } from "@angular/common/http";
 
@Component({
  selector: 'app-first-signup',
  templateUrl: './first-signup.component.html',
  styleUrls: ['./first-signup.component.css']
})
export class FirstSignupComponent implements OnInit {
load:boolean;
url:any;
rForm: FormGroup;
 check:boolean;
 error:boolean;
  name:string='';
  gender:string='';
   email:string='';
    phone:string='';
    password:string='';
    confirm:string=''; 
    nameAlert: string="Name field is mandatory: Use only characters"; 
    genderAlert:string="Please write male or female";
    phoneAlert:string="Phone no should be 10 digit";
    emailAlert:string="email shold be valid";
    passwordAlert:string="password should be atleast 6 to 14 ";
confirmAlert:string="should be equal as password";
    checkpass:boolean=false;
  confirmppassword:string='';
  duplicateemailAlert:string="email address already exist";
  duplicatephoneAlert:string="Phone_no already exist";
  emailcheck:boolean;
  phonecheck:boolean;
  genderss:string;
  getemail:any;
  getphone:any;
  checkingname:string;
  checkingemail:string='';
  confirmpemail:string='';
  checkingphone:string=''; 
  checkinggender:string;
  genders:string[] = [
     'Male',
    'Female',
    'Other',
  ]
  checkingpassword:string;
  constructor(private fb: FormBuilder, private myservice:WheelzserviceService, private http:HttpClient) { 
     this.load=false;
     this.emailcheck=false;
  this.phonecheck=false;
    this.check=false;
    
    this.url=this.myservice.ROOT_URL;
    this.rForm=fb.group({
      //name should would be maximum of 25 charactor only
'name': [null,Validators.compose([Validators.required,Validators.maxLength(25), Validators.pattern("[A-Za-z ]+$")])],
'gender':[null,Validators.compose([Validators.required, Validators.maxLength(6)])],
'email': [null,Validators.compose([Validators.required,Validators.pattern("([a-zA-Z0-9_.]{1,})((@[a-z]{2,})[\\\.]([a-z]{2}|[a-z]{3}))$")])],
'phone':  [null,Validators.compose([Validators.required,Validators.pattern("[7 8 9][0-9]{9}$")])],
'password': [null,Validators.compose([Validators.required, Validators.maxLength(14),Validators.minLength(6)])],
'confirm': [null, Validators.compose([Validators.required, Validators.maxLength(14),Validators.minLength(6)])],
'validate':'',
});
  }
signupUser={
'userName':'',
'gender':0,
'phoneNumber':'',
'email':'',
'password':''
}
  ngOnInit() {
  }
 passwordcheck()
{
  if( ((document.getElementById("password") as HTMLInputElement).value) === ((document.getElementById("confirm") as HTMLInputElement).value) )
  {   
    return true;  
  }
  else{
  this.confirm=null;
    //this.confirmppassword=""; 
  }
}
  register(){
    this.load=true;
    this.signupUser.email=this.checkingemail;
    this.signupUser.password=this.confirmppassword;
    this.signupUser.phoneNumber=this.checkingphone;
    this.signupUser.userName=this.checkingname;
     if(this.checkinggender == 'Male')
     {
this.signupUser.gender=0;
     }
   else  if(this.checkinggender == 'Female')
     {
this.signupUser.gender=1;
     }
     else{
       this.signupUser.gender=2;
     }
    this.myservice.adduser(this.signupUser);
  }
  checkemail()
  {
     
    const res=this.http.get(this.url+'/allEmail').subscribe(
      ressave =>{
         
        this.getemail=ressave;
           
         for(let entry of this.getemail)
         {
            if(entry == this.checkingemail)
            {
               this.checkingemail= "";
               this.load = false;
               alert('Email already exist');
            }
         }
        
      },
      err => {
        console.log("");
      }
    )
  }
 
}

