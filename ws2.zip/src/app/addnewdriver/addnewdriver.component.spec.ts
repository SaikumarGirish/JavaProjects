import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddnewdriverComponent } from './addnewdriver.component';

describe('AddnewdriverComponent', () => {
  let component: AddnewdriverComponent;
  let fixture: ComponentFixture<AddnewdriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddnewdriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddnewdriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
