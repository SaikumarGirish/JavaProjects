import { Component, OnInit } from '@angular/core';
import { AddDriverService } from '../add-driver.service';
import { FormGroup, FormControl, Validator, FormBuilder, Validators } from "@angular/forms";
import { validateDropDown } from './dropDownValidator';
import { Router } from '@angular/router';
@Component({
  selector: 'app-addnewdriver',
  templateUrl: './addnewdriver.component.html',
  styleUrls: ['./addnewdriver.component.css']
})
export class AddnewdriverComponent implements OnInit {

  public submited = false;
  //loader
  load: boolean;

  rForm: FormGroup;
  //to store driver detail from service
  public driverDetail;
  public driverAdded = false;
  public emailDup = 0;
  //for validation
  name: string = '';
  age: number;
  gender: number;
  email: string;
  phone: string = '';
  password: string = '';
  confirm: string = '';
  address: string = '';
  licenseNumber: string = '';
  carNumber: string = '';
  carModel: string = '';

  //alert var
  nameAlert: string = 'Enter a name of less than 35 characters';
  ageAlert: string = 'Enter a valid age';
  genderAlert: string = 'Gender field is mandatory';
  emailAlert: string = "email shold be valid";
  phoneAlert: string = "valid phone is requied";
  addressAlert: string = "address field is mandatory";
  licenseAlert: string = "enter a valid licence number";
  carNumberAlert: string = "enter a valid car number";
  carModelAlert: string = "enter car model as 0 or 1";
  passwordAlert: string = "password should be atleast 6 digit and atmost 14";
  confirmAlert: string = "should be equal as password";
  message: string;

  public driver;
  public checkingName = '';
  public checkingGender;
  public checkingAge;
  public checkingEmail;
  public checkingPhone;
  public checkingAddress;
  public checkingLicenseNumber;
  public checkingCarNumber;
  public checkingCarModel;
  public checkingPassword;
  public confirmPassword;
  public driverinfo = {
    'driverName': '',
    'email': '',
    'carNumber': '',
    'modelType': 0,
    'gender': 0,
    'phoneNumber': '',
    'licenceNumber': '',
    'password': '',
    'address': '',
    'age': 0,
    'driverRidingStatus': 0,
    'driverDeleteStatus': 0,
    'dateOfRegistration': '',
    'administratorId': 1
  };
  constructor(private fb: FormBuilder, private service: AddDriverService, private router: Router) {
    this.load = false;
    this.rForm = fb.group({
      'name': [null, Validators.compose([Validators.required, Validators.pattern("[a-zA-Z]{1}[A-Za-z\\s]{1,34}")])],
      'age': [null, Validators.compose([Validators.required, Validators.pattern("[2-5]{1}[0-9]{1}")])],
      'gender': [validateDropDown],
      'email': [null, Validators.compose([Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern("[7 8 9][0-9]{9}$")])],
      'password': [null, Validators.compose([Validators.required, Validators.maxLength(14), Validators.minLength(6)])],
      'confirm': [null, Validators.compose([Validators.required])],
      'address': [null, Validators.compose([Validators.required, Validators.pattern("[A-Za-z ]+$")])],
      'licenseNumber': [null, Validators.compose([Validators.required, Validators.pattern("[A-Z]{2}[-][0-9]{13}")])],
      'carNumber': [null, Validators.compose([Validators.required, Validators.pattern("[A-Z]{2}[0-9]{2}[N][0-9]{4}")])],
      'carModel': [null, Validators.compose([Validators.required, Validators.pattern("[0,1]{1}")])]
    });
  }
  ngOnInit() {
    // this.confirmPassword = '';
    this.getData();
  }

  // checking existing email
  checkEmail() {
    for (let driver of this.driverDetail) {
      if (driver.email == this.checkingEmail) {
        console.log(this.rForm.controls['name']);
        //this.emailDup =1;
        alert("email already exists");


      }
    }
  }

  checkPhone() {
    for (let driver of this.driverDetail) {
      if (driver.phoneNumber == this.checkingPhone) {
        console.log("checkPhone called");
        //this.emailDup =1;
        alert("phone number already exists");


      }
    }
  }


  checkLicenceNumber() {
    for (const driver of this.driverDetail) {
      if (driver.licenceNumber == this.checkLicenceNumber) {
        console.log(this.rForm.controls['name']);
        // this.emailDup =1;
        alert('licence number already exists');


      }
    }
  }


  checkCarNumber() {
    for (const driver of this.driverDetail) {
      if (driver.carNumber == this.checkingCarNumber) {
        console.log('car called');
        // this.emailDup =1;
        alert('car number already exists');


      }
    }
  }

  //storing driver details for validation
  getData(): void {
    this.service.getDriver().subscribe((data) => {
      this.driverDetail = data;
      console.log("all driver list  " + this.driverDetail);
      console.log(this.driverDetail);
      console.log("default gender " + this.checkingGender);

    });


  }
  passwordcheck() {
    if (((document.getElementById('password') as HTMLInputElement).value) ===
      ((document.getElementById('confirm') as HTMLInputElement).value)) {

    } else {
      this.confirmPassword = '';
    }
  }

  register() {
    console.log('registered called');
    this.load = true;
    this.driverinfo.administratorId = JSON.parse(localStorage.getItem('operatorId'));
    this.driverinfo.driverName = this.checkingName;
    this.driverinfo.email = this.checkingEmail;
    this.driverinfo.carNumber = this.checkingCarNumber;
    this.driverinfo.modelType = this.checkingCarModel;
    this.driverinfo.gender = this.checkingGender;
    this.driverinfo.phoneNumber = this.checkingPhone;
    this.driverinfo.licenceNumber = this.checkingLicenseNumber;
    this.driverinfo.password = this.checkingPassword;
    this.driverinfo.address = this.checkingAddress;
    this.driverinfo.age = this.checkingAge;
    this.driverinfo.dateOfRegistration = (new Date()).toString();
    this.service.insertData(this.driverinfo).subscribe((data2) => {
      this.load = false;
      this.driverAdded = true;
      this.submited = true;
      this.message = 'Driver is added';
      // this.checkingName = '';
      // this.checkingGender = '';
      // this.checkingAge = '';
      // this.checkingEmail = '';
      // this.checkingPhone = '';
      // this.checkingAddress = '';
      // this.checkingLicenseNumber = '';
      // this.checkingCarNumber = '';
      // this.checkingCarModel = '';
      // this.checkingPassword = '';
      // this.confirmPassword = '';
      this.checkingPhone = '';
      this.driver = data2;
      console.log(this.driver);
      // window.location.reload();
    },
      err => {
        this.load = false;
        console.log(this.load);
        alert("connection problem..Please try again");
        console.log(this.load);
      });
  }
  clear() {
    window.location.reload();
  }
}
