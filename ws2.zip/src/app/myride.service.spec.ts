import { TestBed, inject } from '@angular/core/testing';

import { MyrideService } from './myride.service';

describe('MyrideService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyrideService]
    });
  });

  it('should be created', inject([MyrideService], (service: MyrideService) => {
    expect(service).toBeTruthy();
  }));
});
