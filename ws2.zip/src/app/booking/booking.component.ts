import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BookingDetailsService } from '../booking-details.service';
import { UserloginService } from '../userlogin.service';
import { WheelzserviceService } from '../wheelzservice.service';
import { Routes, RouterModule, Router } from '@angular/router';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  message: boolean;
   constructor(private httpClient:HttpClient, public service:BookingDetailsService, public userService:UserloginService, public URL:WheelzserviceService,public route:Router) { 
     
   }
readonly ROOT_URL= this.URL.ROOT_URL;
locations: any;
bookingDataToFront:any;
timeStamp;
email:string='';
pickUpLocation:number=0;
dropLocation:number=0;
carType:number=0;
bookingType:boolean=true;
bookingStatus:number;
userDetails:any;
timeOfBooking:String;
scheduleTime:any;
appendtime;
res:any;
time:string;
time1:number;
min:number;
advance:String[];
payType:number;
locationSame:boolean = false;
buttonCheck:boolean = true;
 splited:any;
 add:any[]=[2];
 cost:number;
 distance:number;
flag:boolean=false;
load:boolean=false; 

  ngOnInit() {
    
    this.locations = this.httpClient.get(this.ROOT_URL+'/allLocations');
          this.email = this.userService.userdetails.email;
       
  }
  pickUp(event:any){
this.pickUpLocation=event.target.value;
this.locationCheck();
  }
  payTypeF(event:any){
this.payType=event.target.value;

  }
   drop(event:any){
this.dropLocation=event.target.value;
this.locationCheck();
  }
  carTypeF(event:any){
    this.carType=event.target.value;
   
  }
  scheduletim(event:any)
  {
     
    this.scheduleTime=event.target.value;
       
   
    this.splited=this.scheduleTime.split(":");

for(let entry of this.splited)
{
this.add.push(entry);
}
this.appendtime=new Date();  
this.appendtime.setHours(this.add[1]);
this.appendtime.setMinutes(this.add[2]);

this.service.bookingDetails.scheduleTime=this.appendtime;
  }
  form(){
   this.load = true; 
if(this.pickUpLocation == 0 || this.dropLocation == 0){
   alert("pick up or drop location is not selected");
   return false;
}
else if(this.pickUpLocation == this.dropLocation)
{
  alert("pick up location and drop location should not be same");
  return false;
}
  if(this.bookingStatus==0)
  {
    this.service.bookingDetails.scheduleTime=null;

  }
  
 
      this.timeStamp = new Date() ;

 
       this.time = this.timeStamp;
      //  this.email = this.userService.userdetails.email;
       this.email = localStorage.getItem('email');
      // this.email = 'surajdoddangadi@gmail.com';
this.service.bookingDetails.dropLocation=this.dropLocation;
this.service.bookingDetails.pickUpLocation= this.pickUpLocation;
this.service.bookingDetails.carType=this.carType;
this.service.bookingDetails.email=this.email;
this.service.bookingDetails.timeStamp=this.time;
this.service.bookingDetails.bookingStatus=this.bookingStatus;
this.service.bookingDetails.payType= this.payType;
 
// console.log(this.service.bookingDetails.timeStamp);
//change this down
    this.bookingDataToFront = this.httpClient.post(this.ROOT_URL+'/addBooking', this.service.bookingDetails).subscribe(
    res=> {
      this.res = res;
      this.service.postBookingDetails.bookingId = this.res.bookingId;
      localStorage.setItem('bookingId',JSON.stringify(this.res.bookingId));
      this.service.postBookingDetails.cost=this.res.cost;
      this.cost = this.res.cost;
      this.service.postBookingDetails.distance= this.res.distance;
      this.distance = this.res.distance;
      this.load = false;
      this.flag= true;
      //  this.route.navigate(['/userfeedback']);
    });
   
  }

  locationCheck(){
    if(this.pickUpLocation == this.dropLocation){
      this.locationSame = true;
      this.buttonCheckF();
        }
    else{
      this.locationSame=false;
  this.buttonCheckF();
    }
  }
   buttonCheckF(){
  if(this.pickUpLocation == this.dropLocation){
      this.buttonCheck = true;
      
    }
    else{
      this.buttonCheck=false;

    }
   }
 instant(event:any){
this.bookingType = event.target.value;
this.scheduleTime = '';
this.appendtime ='';
this.bookingStatus=0;
this.advance=new Array();
this.advance.push("choose schedule");
 

  }
  
   options = { hour:'numeric' };
   options1 = { minute:'numeric' };
   schedule(event:any){
    this.bookingStatus=1;
this.bookingType = event.target.value;
this.advance=new Array();
this.timeStamp = new Date() ;
 
 this.min=this.timeStamp.toLocaleString('en-GB',this.options1);
 this.time1=this.timeStamp.toLocaleString('en-GB',this.options);


 
if(this.min%30!=0){
  
if(this.min<30){
   
  
  if(this.min>15){
    this.min=0;
    this.time1=Number(this.time1)+Number(1);
  }
  else{
    this.min=30;
  }
}
else if(this.min>30)
{
  if(this.min>45)
  {
    this.min=30;
    this.time1=Number(this.time1)+Number(1);
  }
  else{
  this.time1=Number(this.time1)+Number(1);
  this.min=0;
  }
}

 
}
else if(this.min==30){
this.time1=Number(this.time1)+Number(1);
}
else if(this.min==0)
{
  this.min=Number(this.min)+Number(30);
}
for(let a=this.time1;Number(a)<(Number(this.time1)+Number(5));Number(a++))
{
  if(this.time1>=22||this.time1<6)
  {
    this.message=false;
    this.advance.push("no further booking ");
    break;
  }
  if(this.min==30)
  {
    this.advance.push(Number(this.time1)+":"+this.min);
    this.min=Number("0");
    
     
  
  }
    else{
      this.time1=Number(this.time1)+Number(1);

      this.advance.push(Number(this.time1)+":"+this.min+'0');
      this.min=this.min+Number(30);
      
    }
   
}

  }
  
  
}
