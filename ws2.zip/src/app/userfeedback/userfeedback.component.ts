import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BookingDetailsService } from "../booking-details.service";
import {WheelzserviceService} from "../wheelzservice.service";
import { Routes, RouterModule, Router } from '@angular/router';
@Component({
  selector: 'app-userfeedback',
  templateUrl: './userfeedback.component.html',
  styleUrls: ['./userfeedback.component.css']
})
export class UserfeedbackComponent implements OnInit {
userfeedback={
  'bookingId' : 0,
  'rating' : 0,
  'commnet' : '',
}
cmnt:string;
url:any;
Color=["white","white","white","white","white"];
checkrate:number=0;
  constructor(private http : HttpClient,private wheelServive :WheelzserviceService, private service : BookingDetailsService,private router:Router) {
    this.url=this.wheelServive.ROOT_URL;
   }
  ngOnInit() {
  }
prev=0;
  flag=0;
  clicked=0;
  sub;
  user;
  liColor(val){
    return this.Color[val];
  }
changeColor(num){
  this.flag=1;
 console.log(num);
    let stars=document.querySelectorAll("li");
    if(num==this.prev)
    num--;
    for(let i=0;i<5;i++)
      this.Color[i]="white";
    for(let i=0;i<num;i++)
      this.Color[i] = "gold";
      console.log(num);
      console.log(this.sub);
      console.log(this.user);
      this.checkrate=num;
      this.prev=num;
  }
  showUpTo(n)
  {
    if(this.flag === 1)
    return;
    console.log("hovered");
    let stars=document.querySelectorAll("li");
    for(let i=0;i<n;i++)
      this.Color[i]="gold";
  }
  hideAll(){
    if(this.flag==1)
    return;
    let stars=document.querySelectorAll("li");
    for(let i=0;i<5;i++)
      this.Color[i]="white";
  }
  feedback(){
   
this.userfeedback.bookingId = JSON.parse(localStorage.getItem('bookingId'));
this.userfeedback.rating =this.checkrate;
this.userfeedback.commnet = this.cmnt;
 
const result=this.http.post(this.url+'/addFeedback', this.userfeedback).subscribe(
  feed => {
      
  },
  err =>{
     
  }
)

}
}


  