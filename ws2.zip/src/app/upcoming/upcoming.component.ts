import { Component, OnInit } from '@angular/core';
import { MyrideService } from '../myride.service';

@Component({
  selector: 'app-upcoming',
  templateUrl: './upcoming.component.html',
  styleUrls: ['./upcoming.component.css']
})
export class UpcomingComponent implements OnInit {
  public resultSet1;
  OnResultSet: Object;
  onDropLoc: any;
  onPickupLoc: any;
  onLocations: Object;
  public resultSet;
  public userId = 0;
  public load;
  public load1;
  public date;
  public empty = false;
  public count=0;
  public emptyDiv = false;
  constructor(private service: MyrideService) {
    this.load = true;
    this.getData();
  }

  ngOnInit() {
    this.getData();
    this.getLocation();
  }

  getData(): void {
    this.emptyDiv = false;
     this.userId = JSON.parse(localStorage.getItem('userId'));
    this.service.getUpcoming(this.userId).subscribe((data) => {
      this.load = false;
      
      this.resultSet = data;
     
       this.count = Object.keys(this.resultSet).length; 
      console.log(this.resultSet);
      if(this.count === 0) {
          this.empty = true;
      }
      else{
        for (const result of this.resultSet) {
          if (result.wayOfPayment === 0) {
            result.wayOfPayment = 'cash';
            console.log(result.wayOfPayment);
          }
          if (result.wayOfPayment === 1) {
            result.wayOfPayment = 'paytm';
            console.log(result.wayOfPayment);
          }
          console.log(result.timeOfBooking);
          this.date = (new Date(result.timeOfBooking)).toString();
          console.log(this.date.substring(0,24));
          result.timeOfBooking = this.date.substring(3,24); 
      }
    }
    this.load1 = false;
     this.emptyDiv = true;
    },
        err => {
     this.load = false;
     console.log(this.load);
     alert("connection problem..Please try again");
     console.log(this.load);
     
   });


  }

  del(delId) {
    this.emptyDiv = false;
    this.load1 = true;
    console.log(delId);
    this.service.deleteRec(delId).subscribe((data) => {
      this.resultSet = data;
      this.getData();
    // window.location.reload();
    },
        err => {
     this.load = false;
     console.log(this.load);
     alert("connection problem..Please try again");
     console.log(this.load);
     
   }
    );


  }

  changeLoc(bookId) {
    console.log('clickedId=' + bookId);
    this.service.updatelocInfo.bookingId = bookId;
    console.log('service bokid' + this.service.updatelocInfo.bookingId);
  }

  getLocation(): void {
    this.service.getLocations().subscribe((data2) => {
      this.onLocations = data2;
      console.log(this.onLocations);
    });
  }

  updateLoc() {
    this.emptyDiv = false;
    this.load1 = true;
    this.service.sendPickUp = this.onPickupLoc;
    this.service.updatelocInfo.location = this.onDropLoc;
    if(this.onPickupLoc === this.onDropLoc) {
      alert("pickup and drop location should be different");
      this.load1 = false;
      this.emptyDiv = true;
    }
    else {
    this.service.changing(this.service.updatelocInfo).subscribe((data) => {
      this.resultSet1 = data;
     // this.load1 = false;
      this.getData();
      // window.location.reload();
    });
    }
  }
 
}
