import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorBookingComponent } from './operator-booking.component';

describe('OperatorBookingComponent', () => {
  let component: OperatorBookingComponent;
  let fixture: ComponentFixture<OperatorBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OperatorBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OperatorBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
