import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { validateDropDown } from './dropDownValidator';
import { BookingDetailsService } from '../booking-details.service';
import { OperatorService } from '../operator.service';
import { WheelzserviceService } from '../wheelzservice.service';
@Component({
  selector: 'app-operator-booking',
  templateUrl: './operator-booking.component.html',
  styleUrls: ['./operator-booking.component.css']
})
export class OperatorBookingComponent implements OnInit {
  constructor(private httpClient:HttpClient,private fBuilder:FormBuilder,public service:BookingDetailsService,public loginService:OperatorService,public URL:WheelzserviceService) {
     this.rForm= fBuilder.group(
       {
          'name': [null, Validators.compose([Validators.required, Validators.pattern('[A-Za-z.]+$')])],
          'phone':  [null, Validators.compose([Validators.required, Validators.pattern('[7 8 9][0-9]{9}$')])],
          'email': [null, Validators.compose([Validators.required, Validators.pattern("([a-zA-Z0-9_.]{1,})((@[a-zA-Z]{2,})[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))$")])],
          'pickUp': [0, validateDropDown],
          'dropIn': [0, validateDropDown],
          'driverIdVal': [null]
       }
     )

     }
readonly ROOT_URL=this.URL.ROOT_URL;
rForm:FormGroup;
locations: any;
drivers:any;
userName:string;
userNameValidator:string="Enter a valid name";
phoneNumber:string;
phoneNumberValidator:string="Enter a valid phone number";
email:string;
emailValidator:string="Enter a valid email address";
pickUpLocation:number=0;
pickUpLocationValidator:string="Select pick up location";
dropLocation:number=0;
dropLocationValidator:string="Select drop location";
carType:number=0;
driverId:number;
driverIdValidator:string= "Enter valid driver Id";
timeStamp;
time:string;
time1: number;
operatorId;
bookingDataToFront;
res:any;
bookingType: boolean = true;
advance: String[];
min: number;
options = { hour: 'numeric' };
options1 = { minute: 'numeric' };
cost: number = 0;
distance: number;
scheduleTime: any;
splited: any;
appendtime;
add: any[] = [2];
bookingstatus:number=0;
equal:boolean=true;



  ngOnInit() {
     this.locations = this.httpClient.get(this.ROOT_URL + '/allLocations');
     this.httpClient.get(this.ROOT_URL + '/freeDrivers').subscribe(
  driver => {
    this.drivers = driver;
  }
);
  }
getFreeDrivers() {
this.httpClient.get(this.ROOT_URL + '/freeDrivers').subscribe(
  driver => {
    this.drivers = driver;
  }
);
}
submitDetails(detail) {
this.rForm.reset();
}
nameF(event: any) {
this.userName = event.target.value;
}
phoneNameF(event: any) {
this.phoneNumber = event.target.value;
}
emailF(event: any) {
  this.email = event.target.value;
}
pickUp(event: any) {
this.pickUpLocation = event.target.value;
this.check();
  }
   drop(event: any) {
this.dropLocation = event.target.value;
this.check();
  }
  carTypeF(event: any) {
    this.carType = event.target.value;
  }
  driverIdF(event: any) {
this.driverId = event.target.value;
  }
   scheduletim(event: any) {
    this.scheduleTime = event.target.value;
    this.splited = this.scheduleTime.split(':');
for (let entry of this.splited)
{
this.add.push(entry);
}
this.appendtime = new Date();
this.appendtime.setHours(this.add[1]);
this.appendtime.setMinutes(this.add[2]);
this.service.operatorBookingDetails.scheduleTime = this.appendtime;
  }

  submit() {
    let flag = false;
    for(let i=0;i<this.drivers.length;i++){
      if(this.driverId == this.drivers[i].driverId){
        flag = true;
        break;
      }
      if(flag == false){
        alert("Driver Id does not exist in free driver list");
        return false;
      }
      console.log(this.driverId);
       console.log(this.drivers[i].driverId);
    }
    this.timeStamp = new Date();
    this.time = this.timeStamp;
    this.service.operatorBookingDetails.userName=this.userName;
    this.service.operatorBookingDetails.phoneNumber= this.phoneNumber;
    this.service.operatorBookingDetails.email=this.email;
    this.service.operatorBookingDetails.pickUpLocation=this.pickUpLocation;
    this.service.operatorBookingDetails.dropLocation=this.dropLocation;
    this.service.operatorBookingDetails.carType = this.carType;
    this.service.operatorBookingDetails.driverId=this.driverId;
    this.service.operatorBookingDetails.timeI = this.time;
    this.service.operatorBookingDetails.bookingStatus = this.bookingstatus;
    // this.service.operatorBookingDetails.operatorId = this.loginService.operatorId;
    // change this .....infact delete this upcoming line and replace with the above line
 
   this.service.operatorBookingDetails.operatorId = JSON.parse(localStorage.getItem('operatorId'));
     this.bookingDataToFront = this.httpClient.post(this.ROOT_URL+'/operatorbooking', this.service.operatorBookingDetails).subscribe(
    res=> {
      this.res = res;
      this.service.postBookingDetails.bookingId = this.res.bookingId;
      this.service.postBookingDetails.cost=this.res.cost;
      this.cost =  this.service.postBookingDetails.cost;
      this.service.postBookingDetails.distance= this.res.distance;
      this.distance =  this.service.postBookingDetails.distance;
      console.log(this.service.postBookingDetails);
       this.getFreeDrivers();
    });
return true;

  }

 instant(event: any) {
this.bookingType = event.target.value;
this.advance = new Array();
this.advance.push('select schedule');

  }
  check(){
    if(this.pickUpLocation != this.dropLocation){
      this.equal = true;
    }
    else{
      this.equal = false;
    }
  }


 schedule(event: any) {
    this.bookingstatus = 1;
this.bookingType = event.target.value;
this.advance = new Array();
this.timeStamp = new Date() ;
 this.min = this.timeStamp.toLocaleString('en-GB', this.options1);
 this.time1 = this.timeStamp.toLocaleString('en-GB', this.options);
if ( this.min % 30 !== 0 ) {
if (this.min < 30) {
  if (this.min > 15) {
    this.min = 0;
    this.time1 = Number(this.time1) + Number(1);
  } else {
    this.min = 30;
  }
}else if (this.min > 30) {
  if (this.min > 45) {
    this.min = 30;
    this.time1 = Number(this.time1) + Number(1);
  }else {
  this.time1 = Number(this.time1) + Number(1);
  this.min = 0;
  }
}
}else if (this.min === 30) {
this.time1 = Number(this.time1) + Number(1);
}else if (this.min === 0) {
  this.min = Number(this.min) + Number(30);
}
for (let a = this.time1; Number(a) < (Number(this.time1) + Number(5)); Number(a++)) {
  if (this.time1 >= 22 || this.time1 < 6) {
    this.advance.push('no further booking');
    break;
  }
  if (this.min === 30) {
    this.advance.push(Number(this.time1) + ':' + this.min);
    this.min = Number('0');
  }else {
      this.time1 = Number(this.time1) + Number(1);

      this.advance.push(Number(this.time1) + ':' + this.min + '0');
      this.min = this.min + Number(30);

    }

}


  }

}
