import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyheaderComponent } from './emptyheader.component';

describe('EmptyheaderComponent', () => {
  let component: EmptyheaderComponent;
  let fixture: ComponentFixture<EmptyheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmptyheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
