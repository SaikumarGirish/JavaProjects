import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emptyheader',
  templateUrl: './emptyheader.component.html',
  styleUrls: ['./emptyheader.component.css']
})
export class EmptyheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
