import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WheelzserviceService } from '../wheelzservice.service';

@Component({
  selector: 'app-unassign-driver',
  templateUrl: './unassign-driver.component.html',
  styleUrls: ['./unassign-driver.component.css']
})
export class UnassignDriverComponent implements OnInit {
  list: Array<number> = [];
  name: string;
  member: any = '';
  found: boolean = true;
  inl: number;
  readonly ROOT_URL = this.URL.ROOT_URL;

  constructor(private httpClient: HttpClient, public URL: WheelzserviceService) {
    this.found = false;
    this.httpClient.get(this.ROOT_URL + '/assignedDrivers')
      .subscribe(
      (data: any[]) => {

        if (data.length !== 0) {
          this.member = data;
          this.found = true;
        }
      }
      );
  }

  ngOnInit() {
  }

  change(val) {
    if (!this.list.includes(val)) {
      this.list.push(val);
    }
    // tslint:disable-next-line:one-line
    else {
      this.list.splice(this.list.indexOf(val), 1);
    }

  }

  send() {
    this.httpClient.post(this.ROOT_URL + '/unassignDrivers', this.list)
      .subscribe(
      (data: any[]) => {
        if (data.length !== 0) {
          this.member = data;
          this.found = true;
        }
      }
      );
    this.list = [];
  }

  set(val) {
    console.log('checking set');
    this.inl = val;
  }

  unassign() {
    console.log('checking unassign');
    this.found = false;
    this.httpClient.get(this.ROOT_URL + `/unassignDriver/${this.inl}`)

      .subscribe(
      (data: any[]) => {
        if (data.length !== 0) {
          this.member = data;
          this.found = true;
        }
      }
      );
  }

// tslint:disable-next-line:member-ordering

setDiv() {
  if (this.list.length === 0) {
    document.getElementById('positive').style.display = 'none';
    document.getElementById('negative').style.display = 'block';
  }
  else{
    document.getElementById('positive').style.display = 'block';
    document.getElementById('negative').style.display = 'none';
  }
}

}
