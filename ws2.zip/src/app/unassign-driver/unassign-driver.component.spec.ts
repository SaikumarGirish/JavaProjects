import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnassignDriverComponent } from './unassign-driver.component';

describe('UnassignDriverComponent', () => {
  let component: UnassignDriverComponent;
  let fixture: ComponentFixture<UnassignDriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnassignDriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnassignDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
