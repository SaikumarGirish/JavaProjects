import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BookingDetailsService } from '../booking-details.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  payment = {
    bookingId: 0,
    wayOfPayment: 0
  };

  status: any;
  // tslint:disable-next-line:prefer-const
  serverUrl = 'http://wheelzcarrentalserver.azurewebsites.net/WheelzCarRental';
  constructor(private httpClient: HttpClient, private booking: BookingDetailsService) { }

  ngOnInit() {
  }

  direct() {
    this.payment.bookingId = JSON.parse(localStorage.getItem('bookingId'));
    this.payment.wayOfPayment = 1;
    this.status = this.httpClient.post(this.serverUrl + '/payment', this.payment).subscribe();
  }

  bhim() {
    this.payment.bookingId = JSON.parse(localStorage.getItem('bookingId'));
    this.payment.wayOfPayment = 2;
    this.status = this.httpClient.post(this.serverUrl + '/payment', this.payment).subscribe();
  }
  paytm() {
    this.payment.bookingId = JSON.parse(localStorage.getItem('bookingId'));
    this.payment.wayOfPayment = 3;
    this.status = this.httpClient.post(this.serverUrl + '/payment', this.payment).subscribe();
  }
}
