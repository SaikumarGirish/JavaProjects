import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-driver',
  templateUrl: './assign-driver.component.html',
  styleUrls: ['./assign-driver.component.css']
})
export class AssignDriverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
