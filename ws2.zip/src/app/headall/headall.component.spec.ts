import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeadallComponent } from './headall.component';

describe('HeadallComponent', () => {
  let component: HeadallComponent;
  let fixture: ComponentFixture<HeadallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeadallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeadallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
