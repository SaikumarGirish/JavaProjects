import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headall',
  templateUrl: './headall.component.html',
  styleUrls: ['./headall.component.css']
})
export class HeadallComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
