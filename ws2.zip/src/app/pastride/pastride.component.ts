import { Component, OnInit } from '@angular/core';
import { MyrideService } from '../myride.service';
import { UserloginService } from '../userlogin.service';
import { HttpClient } from "@angular/common/http";
import { WheelzserviceService } from "../wheelzservice.service";


@Component({
  selector: 'app-pastride',
  templateUrl: './pastride.component.html',
  styleUrls: ['./pastride.component.css']
})


export class PastrideComponent implements OnInit {


public resultSet;
public earn;
public mop: '';
public driverId = 0 ;
public load;
public date:any;
public count;
public empty = false;
public emptyDiv = false;
  constructor(private service: MyrideService, private http: HttpClient, public URL: WheelzserviceService) {
    this.load = true;
   }
 readonly ROOT_URL = this.URL.ROOT_URL;
loading = false;
  ngOnInit() {
    this.getDetails();
  }


   getDetails(): void {
       
    this.driverId = JSON.parse(localStorage.getItem('driverId')); 
    console.log(this.driverId);
    this.service.getPastdriver(this.driverId).subscribe((data) => {
       this.load = false;
      this.resultSet = data;

      this.count = Object.keys(this.resultSet).length;
      console.log("length of json " + this.count);
      console.log(this.resultSet);
      if(this.count === 0) {
          this.empty = true;
      }
      else {
      
      for (const result of this.resultSet) {
          if (result.wayOfPayment === 0) {
            result.wayOfPayment = 'cash';
            console.log(result.wayOfPayment);
          }
          if (result.wayOfPayment === 1) {
            result.wayOfPayment = 'paytm';
            console.log(result.wayOfPayment);
          }
          console.log(result.timeOfBooking);
          this.date = (new Date(result.timeOfBooking)).toString();
          console.log(this.date.substring(0,24));
          result.timeOfBooking = this.date.substring(3,24); 
      }
       
        this.emptyDiv = true;
      }

    }
    ,
     err => {
     this.load = false;
     console.log(this.load);
     alert("Connection problem..Please try again");
     console.log(this.load);
    
     
   }
    );

   }

  getCost()
  {
     
    console.log(this.driverId);
    this.loading = true;
    this.http.get(this.ROOT_URL + '/earnings/' + this.driverId)
      .subscribe(
      data => {
        this.loading = false;
        this.earn=data;
        console.log(data);
        console.log(this.earn);
        
      })
}
}
