import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PastrideComponent } from './pastride.component';

describe('PastrideComponent', () => {
  let component: PastrideComponent;
  let fixture: ComponentFixture<PastrideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PastrideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PastrideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
