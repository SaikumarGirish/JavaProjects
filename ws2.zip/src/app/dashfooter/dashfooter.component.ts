import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashfooter',
  templateUrl: './dashfooter.component.html',
  styleUrls: ['./dashfooter.component.css']
})
export class DashfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
