import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operator-dashboard',
  templateUrl: './operator-dashboard.component.html',
  styleUrls: ['./operator-dashboard.component.css']
})
export class OperatorDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
