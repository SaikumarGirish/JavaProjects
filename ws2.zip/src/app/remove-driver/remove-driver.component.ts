import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WheelzserviceService } from '../wheelzservice.service';

@Component({
  selector: 'app-remove-driver',
  templateUrl: './remove-driver.component.html',
  styleUrls: ['./remove-driver.component.css']
})
export class RemoveDriverComponent implements OnInit {
  name: string;
  member: any = '';
  found: boolean = true;
  inl: number;
  readonly ROOT_URL = this.URL.ROOT_URL;

  constructor(private httpClient: HttpClient, public URL: WheelzserviceService) {
    this.found = false;
  
   }

  ngOnInit() {
     this.add();
  }
add()
{
   this.httpClient.get(this.ROOT_URL + /listDrivers/)
    .subscribe(
      (data: any[]) => {

        if (data.length !== 0) {
          this.member = data;
          this.found = true;
        }
      }
    );
}
  set(val) {
    this.inl = val;
  }
  Delete() {
      this.found = false;
      this.httpClient.get(this.ROOT_URL + `/deleteDriver/${this.inl}`)

    .subscribe(
      (data: any[]) => {
        if (data.length !== 0) {
          this.member = data;
          this.found = true;
        }
      }
    );
  }
 
}
