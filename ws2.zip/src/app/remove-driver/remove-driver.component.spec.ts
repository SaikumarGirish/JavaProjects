import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveDriverComponent } from './remove-driver.component';

describe('RemoveDriverComponent', () => {
  let component: RemoveDriverComponent;
  let fixture: ComponentFixture<RemoveDriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveDriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
