import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashbody',
  templateUrl: './dashbody.component.html',
  styleUrls: ['./dashbody.component.css']
})
export class DashbodyComponent implements OnInit {
Login:string;
name:string;
  constructor() {
    if(localStorage.getItem('email')){
this.Login=localStorage.getItem('userName');
this.name=localStorage.getItem('email');
    }
    else{
this.Login='Login';
    }
   }

  ngOnInit() {
  }
  logout(){
     localStorage.clear();
  window.location.reload();
  }
  onClick(divId){
    let division = document.querySelector("#"+divId);
    if (division){
    division.scrollIntoView({ behavior: 'smooth' });
    
  }
}
}
