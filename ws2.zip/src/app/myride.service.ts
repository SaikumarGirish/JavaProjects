import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpHandler, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
 
import { WheelzserviceService } from './wheelzservice.service';

@Injectable()
export class MyrideService {


//    private url = 'http://localhost:8080/WheelzCarRental';

   private url = this.wheelService.ROOT_URL;


  public sendPickUp;
public updatelocInfo= {
'bookingId': 0 ,
'location': ''
};
public usersId;
public driverId;
  constructor(private http: HttpClient, private wheelService: WheelzserviceService) { }
getPast(userId) {
      console.log('get past ride for ' + userId);
  return this.http.get(this.url + '/past/' + userId);
     }
 getOngoing(userId) {
        console.log('get ongoing ride for ' + userId);
          return this.http.get(this.url + '/ongoing/' + userId);
     }
getUpcoming(userId) {
       console.log('get upcoming ride for ' + userId);
          return this.http.get(this.url + '/upcoming/' + userId);
     }
getLocations() {
      console.log('get locations');
      return this.http.get(this.url + '/getLocations');
}

changeDestination(updateObj) {
      console.log(updateObj);
      return this.http.put(this.url + '/changeDestination', updateObj);
 }

 deleteRec(delId) {
      return this.http.delete(this.url + '/deleteRecord/' + delId);
}
changing(updateData) {
      // tslint:disable-next-line:quotemark
      console.log("service called");
      console.log(updateData);
      return this.http.put(this.url + '/changeUpcoming/' + this.sendPickUp, updateData);
}
getShowDeleted(userId) {
       console.log('get show deleted ride for ' + userId);
      return this.http.get(this.url + '/showDeleted/' + userId);
}


getPastdriver(driverId) {
      console.log('get past ride for ' + driverId);
  return this.http.get(this.url + '/pastRide/' + driverId);
     }

}
