import { Component, OnInit } from '@angular/core';
import { FacebookService } from '../facebook.service';
import { Routes, RouterModule, Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
name;
  constructor(private facebookService: FacebookService ,private route:Router) { 

    this.name=localStorage.getItem('userName');
  }

  ngOnInit() {
  }

logout() {
  localStorage.clear();
  window.location.reload();
  this.route.navigate(['/dashboard']);
 

  

}

}
