import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FeatureRoutingModule } from '../app/app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { BookingComponent } from './booking/booking.component';
import { RidesComponent } from './rides/rides.component';
import { PaymentComponent } from './payment/payment.component';
import { ErrorDisplayComponent } from './error-display/error-display.component';
import { UserService } from './user.service';
import { UserloginService } from './userlogin.service';
import { WheelzserviceService } from './wheelzservice.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OperatorService } from './operator.service';
import { BookingDetailsService } from './booking-details.service';
import { HttpClientModule } from '@angular/common/http';
import { PastComponent } from './past/past.component';
import { OngoingComponent } from './ongoing/ongoing.component';
import { UpcomingComponent } from './upcoming/upcoming.component';
import { ShowdeletedComponent } from './showdeleted/showdeleted.component';
import { FirstSignupComponent } from './first-signup/first-signup.component';
import { FacebookService } from './facebook.service';
import { MyrideService } from './myride.service';
import { AssignComponent } from './assign/assign.component';
import { DashbodyComponent } from './dashbody/dashbody.component';
import { DashheaderComponent } from './dashheader/dashheader.component';
import { DashfooterComponent } from './dashfooter/dashfooter.component';
import { UserfeedbackComponent } from './userfeedback/userfeedback.component';
import { OperatorLoginComponent } from './operator-login/operator-login.component';
import { OperatorDashboardComponent } from './operator-dashboard/operator-dashboard.component';
import { RemoveDriverComponent } from './remove-driver/remove-driver.component';
import { GmailService } from './gmail.service';
import { HttpModule } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { AddnewdriverComponent } from './addnewdriver/addnewdriver.component';

import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider
} from 'angular5-social-login';

import { EmptyheaderComponent } from './emptyheader/emptyheader.component';
import { AssignedheaderComponent } from './assignedheader/assignedheader.component';


export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
    [
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider('924274330055-ld9v197j9jb1keov0haau8c7faic7lq1.apps.googleusercontent.com')
      }
    ],
  );
  return config;
}
import { OperatorBookingComponent } from './operator-booking/operator-booking.component';

import { HeadallComponent } from './headall/headall.component';
import { AssignDriverComponent } from './assign-driver/assign-driver.component';
import { AddDriverService } from './add-driver.service';
import { UnassignDriverComponent } from './unassign-driver/unassign-driver.component';

import { PastrideComponent } from './pastride/pastride.component';
import { DriverLoginComponent } from './driver-login/driver-login.component';
import { DriverprofileComponent } from './driverprofile/driverprofile.component';
import { AuthServiceService } from "./auth-service.service";
import { AssignedRideComponent } from './assigned-ride/assigned-ride.component';
import { DriverHeaderComponent } from './driver-header/driver-header.component';
import { DrprofileheaderComponent } from './drprofileheader/drprofileheader.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    UserLoginComponent,
    UserDashboardComponent,
    BookingComponent,
    RidesComponent,
    PaymentComponent,
    ErrorDisplayComponent,
    PastComponent,
    OngoingComponent,
    UpcomingComponent,
    ShowdeletedComponent,
    FirstSignupComponent,
    PastComponent,
    OngoingComponent,
    UpcomingComponent,
    ShowdeletedComponent,
    FirstSignupComponent,
    FirstSignupComponent,
    FirstSignupComponent,
    AssignComponent,
    DashbodyComponent,
    DashheaderComponent,
    DashfooterComponent,
  UserfeedbackComponent,
  OperatorLoginComponent,
  OperatorDashboardComponent,
  RemoveDriverComponent,
  
  OperatorBookingComponent,
  AssignDriverComponent,
  HeadallComponent,
  AddnewdriverComponent,
    AddnewdriverComponent,
    EmptyheaderComponent,
    AssignedheaderComponent,
  EmptyheaderComponent,
  AssignedheaderComponent,
  UnassignDriverComponent,

  PastrideComponent,

  AssignedRideComponent,
  DriverHeaderComponent,
  DriverLoginComponent,
  DriverprofileComponent,
  DrprofileheaderComponent,
  ],
  imports: [
    SocialLoginModule,
    BrowserModule,
    FeatureRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    HttpModule,
    
  ],
  // tslint:disable-next-line:max-line-length
  providers: [[UserService, WheelzserviceService, BookingDetailsService, AuthServiceService,OperatorService, UserloginService, MyrideService, FacebookService, GmailService, AddDriverService],
   {
    provide: AuthServiceConfig,
    useFactory: getAuthServiceConfigs,
  },

],
  bootstrap: [AppComponent]
})
export class AppModule { }
