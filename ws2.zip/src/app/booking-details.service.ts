import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable()


export class BookingDetailsService
{

bookingDetails= {
pickUpLocation:0,
dropLocation:0,
carType:0,
timeStamp: '',
email:'',
bookingStatus:0,
payType:0,
scheduleTime:Event
}
postBookingDetails={
  bookingId:0,
  cost:0,
  distance:0
}
operatorBookingDetails={
userName:'',
phoneNumber:'',
email:'',
pickUpLocation:0,
dropLocation:0,
carType:0,
driverId:0,
timeI:'',
operatorId:0,
bookingStatus:0,
scheduleTime:Event
}
  constructor() { }

}
