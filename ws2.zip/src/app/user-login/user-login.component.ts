import { Component, OnInit } from '@angular/core';
import { FacebookService } from '../facebook.service';
import { HttpClient } from '@angular/common/http';
import { UserloginService } from '../userlogin.service';

import { FormGroup, FormControl, Validator, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from 'angular5-social-login';
import { GmailService } from '../gmail.service';
import { HttpModule, JsonpModule } from '@angular/http';
import { DOCUMENT } from '@angular/common';
import { WheelzserviceService } from '../wheelzservice.service';
let obj: any;


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})


export class UserLoginComponent implements OnInit {

  constructor(private http: HttpClient, private fb: FormBuilder, private route: ActivatedRoute,
    private router: Router, private userlogin: UserloginService, private facebookService: FacebookService,
    private socialAuthService: AuthService, private gmail: GmailService, public URL: WheelzserviceService) {
    this.userlogService = userlogin;

    this.check = false;
    this.rForm = fb.group({
      'email': [null, Validators.compose([Validators.required, Validators.
        pattern('([a-zA-Z0-9_.]{1,})((@[a-zA-Z]{2,})[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))$')])],
      'password': [null, Validators.compose([Validators.required, Validators.maxLength(14), Validators.minLength(6)])],

      'validate': '',


    });
  }
  readonly ROOT_URL = this.URL.ROOT_URL;
  user1: any;
  model: any = {};
  loading = false;
  returnUrl: string;


  userlogService: any;

  rForm: FormGroup;
  check: boolean;
  email: string = '';
  password: string = '';

  emailAlert: string = "Invalid Email Id";
  passwordAlert: string = "Password should be between 6-14 digits";





  socialSignIn(user: String) {
    this.user1 = user;
    this.gmail.socialSignIn(this.user1);
  }

  // tslint:disable-next-line:member-ordering
  userdetail = {
    email: '',
    password: ''
  };


  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['/booking'] || '/booking';
  }

  loginuser(e) {
    e.preventDefault();
    console.log(e);

    this.check = true;
    this.loading = true;
    this.userdetail.email = e.target.elements[0].value;
    this.userdetail.password = e.target.elements[1].value;

    this.http.post(this.ROOT_URL + '/logindata', this.userdetail)
      .subscribe(
      data => {
        obj = data;
        console.log(data);
        if (obj == null) {
          alert("Incorrect UserName or Password");
          this.loading = false;
        }
        // tslint:disable-next-line:one-line
        else {
          obj = data;
          console.log(obj);
          this.router.navigate([this.returnUrl]);
          this.userlogService.sendObj(obj);
          window.location.reload();
        }


        this.check = false;

      });


  }

  login() {
    this.facebookService.initial();
    this.facebookService.login();
  }

  logout() {
    this.facebookService.logout();
  }

}
