import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLoginComponent } from './user-login.component';
import { HttpModule } from "@angular/http/http";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { UserloginService } from "../userlogin.service";
import { WheelzserviceService } from "../wheelzservice.service";
import { HeadallComponent } from "../headall/headall.component";
import { MyrideService } from "../myride.service";
import { FacebookService } from "../facebook.service";
import { GmailService } from "../gmail.service";
import { AuthService, AuthServiceConfig } from "angular5-social-login";


fdescribe('UserLoginComponent', () => {
  let component: UserLoginComponent;
  let fixture: ComponentFixture<UserLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserLoginComponent,HeadallComponent],
      imports:[HttpClientModule,FormsModule,RouterModule,RouterTestingModule,ReactiveFormsModule],
      providers:[UserloginService,MyrideService,WheelzserviceService,FacebookService,GmailService,AuthService,AuthServiceConfig]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
