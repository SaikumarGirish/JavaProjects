import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignedheader',
  templateUrl: './assignedheader.component.html',
  styleUrls: ['./assignedheader.component.css']
})
export class AssignedheaderComponent implements OnInit {
  operatorName: string;
  constructor() {
    if (localStorage.getItem('operatorId')) {
      this.operatorName = (localStorage.getItem('opeartorName'));
    }

  }

  ngOnInit() {
  }
  logout() {
    localStorage.clear();
    
  }
  lo(){
  window.location.reload();
}
}
