import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignedheaderComponent } from './assignedheader.component';

describe('AssignedheaderComponent', () => {
  let component: AssignedheaderComponent;
  let fixture: ComponentFixture<AssignedheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignedheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
