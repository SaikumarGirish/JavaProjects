package com.ibm.student.service;

import java.util.List;
import java.util.Optional;

import com.ibm.student.model.Student;

public interface StudentService{
	
	public List<Student> getStudentData();
	public Student updateStudent(Student student);
	public Student saveStudentData(Student student);
	public String deleteStudent(Long id);
	public Optional<Student> getStudentById(Long id);

}
