package com.ibm.student.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import com.ibm.student.exception.ResourceNotFoundException;
import com.ibm.student.model.Student;
import com.ibm.student.service.StudentService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/student-ui/v1.0")
public class StudentController {

	@Autowired
	private StudentService studentService;

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

	@GetMapping("/getstudentdata")
	public List<Student> getStudentData() {
		logger.info("##API CALL## -- GET -- /getstudentdata");
		return studentService.getStudentData();
	}

	@PostMapping("/addstudent")
	@ResponseStatus(HttpStatus.CREATED)
	public Long addStudent(@RequestBody Student student) {
		logger.info("##API CALL## -- POST -- /addstudent");
		return studentService.saveStudentData(student).getId();
	}

	@PutMapping("/editstudent")
	@ResponseStatus(HttpStatus.OK)
	public Student editStudent(@RequestBody Student student) throws ResourceNotFoundException {
		logger.info("##API CALL## -- PUT -- /editstudent");

		/*
		 * checking the requested student id is present or not if not throwing
		 * 404
		 */
		if (studentService.getStudentById(student.getId()).equals(Optional.empty())) {
			logger.error("Student controller :: Requested Student Data Not Found :: Student Id: " + student.getId());
			throw new ResourceNotFoundException("Requested Student Data Not Found");
		}
		return studentService.updateStudent(student);
	}

	@DeleteMapping("/deletestudent/{id}")
	@ResponseStatus(HttpStatus.OK)
	public String deleteStudent(@PathVariable("id") Long id) throws ResourceNotFoundException {
		logger.info("Student controller :: ##API CALL## -- DELETE -- /deletestudent/" + id);

		/*
		 * checking the requested student id is present or not if not throwing
		 * 404
		 */

		if (studentService.getStudentById(id).equals(Optional.empty())) {
			logger.error("Requested Student Id Not Found :: Student Id: " + id);
			throw new ResourceNotFoundException("Requested Student Id Not Found");
		}
		return studentService.deleteStudent(id);
	}

}
