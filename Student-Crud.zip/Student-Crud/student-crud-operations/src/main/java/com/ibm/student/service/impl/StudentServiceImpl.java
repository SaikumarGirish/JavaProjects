package com.ibm.student.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;


import com.ibm.student.controller.StudentController;
import com.ibm.student.model.Student;
import com.ibm.student.repository.StudentRepository;
import com.ibm.student.service.StudentService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	StudentRepository studentRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
	
	@Override
	public List<Student> getStudentData() {
		logger.debug("StudentServiceImpl :: getting student data");
		return studentRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	@Override
	public Student saveStudentData(Student student) {
		logger.debug("StudentServiceImpl :: saving student data");
		return studentRepository.save(student);
	}

	@Override
	public Student updateStudent(Student student) {
		logger.debug("StudentServiceImpl :: updating student data :: StudentId: "+ student.getId());
		return studentRepository.save(student);
	}

	@Override
	public String deleteStudent(Long id) {
		logger.debug("StudentServiceImpl :: deleting student data :: StudentId: "+ id);
		studentRepository.deleteById(id);
		return "Student Data Deleted Successfully";
	}

	@Override
	public Optional<Student> getStudentById(Long id) {
		logger.debug("StudentServiceImpl :: getting student data by id:: StudentId: "+ id);
		return studentRepository.findById(id);
	}

}
