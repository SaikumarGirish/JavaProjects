package com.ibm.student;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ibm.student.model.Student;
import com.ibm.student.repository.StudentRepository;
import com.ibm.student.service.StudentService;

@SpringBootTest
public class StudentServiceTest {
	
	@Mock
    StudentRepository studentRepository;
	
	@Autowired
	StudentService studentService;
	
	@Test
	public void testSaveStudentData() {
		Student student = new Student();
		student.setAge(2);
		student.setName("name");
		student.setStandard(4);
		when(studentRepository.save(student)).thenReturn(student);
		assertTrue(studentService.saveStudentData(student).getName().equals("name"));
	}
	
	@Test
	public void testGetStudentData() {
		Student student1 = new Student();
		student1.setAge(2);
		student1.setName("name");
		student1.setStandard(4);
		Student student2 = new Student();
		student2.setAge(4);
		student2.setName("name1");
		student2.setStandard(5);
		List<Student> students = List.of(student1,student2);
		when(studentRepository.findAll()).thenReturn(students);
		assertNotNull(studentService.getStudentData());
	}

}
