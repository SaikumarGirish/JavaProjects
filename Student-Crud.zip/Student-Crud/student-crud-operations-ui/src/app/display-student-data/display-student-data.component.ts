import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../services/student.service';

@Component({
  selector: 'app-display-student-data',
  templateUrl: './display-student-data.component.html',
  styleUrls: ['./display-student-data.component.css'],
})
export class DisplayStudentDataComponent implements OnInit {

  constructor(private studentService: StudentService, public router: Router) { 
  }

  studentList: any;
  display = "none";
  ngOnInit(): void {
    this.studentService.getStudentsList().then( studentList => {
        this.studentList = studentList.data;
    });
  }

  deleteData(id: number): void{
    this.studentService.deleteStudent(id).then( message => {
        alert(message.data);
        location.reload();
    });
  }

  student = {
    id:0,
    name:'',
    age:0,
    standard:0,
  }

  name: string = '';
  age: string = '';
  class: string = '';
  id: string ='';

  editStudent(student: any) : void {
    this.display = "block";
    this.name = student.name;
    this.age = student.age;
    this.class = student.standard;
    this.id = student.id;
  }
  onCloseHandled() {
    this.display = "none";
  }

  saveEditedStudent(): void {
    this.student.id = parseInt(this.id);
    this.student.name= this.name;
    this.student.age = parseInt(this.age);
    this.student.standard = parseInt(this.class);
    this.studentService.editStudent(this.student).then( result => {
      alert("Student Data Updated Successfully");
      location.reload()
    });
  }
}
