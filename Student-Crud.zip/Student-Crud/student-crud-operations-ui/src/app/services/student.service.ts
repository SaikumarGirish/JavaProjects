  import { Injectable } from '@angular/core';
  import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  public readonly URL = "http://localhost:8080/student-ui/v1.0";

  constructor() { }

  public getStudentsList() {
    return axios.get(this.URL+"/getstudentdata");
  }

  public deleteStudent(id: number) {
    return axios.delete(this.URL+"/deletestudent/"+id);
  }

  public saveStudent(student:any) {
    return axios.post(this.URL+"/addstudent",student);
  }

  public editStudent(student: any) {
    return axios.put(this.URL+"/editstudent",student);
  }
}
