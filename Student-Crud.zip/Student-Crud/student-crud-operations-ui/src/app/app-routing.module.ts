import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import {AddStudentComponent} from './add-student/add-student.component';
import {ErrorDisplayComponent} from './error-display/error-display.component';
import {DisplayStudentDataComponent} from './display-student-data/display-student-data.component';

const routes: Routes = [
  { path: '', redirectTo: 'homePage', pathMatch: 'full' },
  {
    path: 'homePage',
    component: HomeComponent
  },
  {
    path:'display-data',
    component:DisplayStudentDataComponent
  },
  {
    path: 'add-student',
    component: AddStudentComponent
  },
  {
    path: 'error',
    component: ErrorDisplayComponent
  },
  { path: '**', redirectTo: 'error', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
