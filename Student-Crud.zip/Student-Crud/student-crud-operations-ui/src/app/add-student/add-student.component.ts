import { Component, OnInit } from '@angular/core';
import { StudentService } from '../services/student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {

  constructor(private studentService: StudentService, public router: Router) { }

  ngOnInit(): void {
  }

  student = {
    name:'',
    age:0,
    standard:0,
  }

  name: string = '';
  age: string = '';
  class: string = '';


  saveStudent() : void{
    this.student.name = this.name;
    this.student.age = parseInt(this.age);
    this.student.standard = parseInt(this.class);
    this.studentService.saveStudent(this.student).then((result) =>{
      alert("Student Data Saved Successfully with Id: "+result.data); 
      this.router.navigate(['/homePage']);
    });
  }
  

}
